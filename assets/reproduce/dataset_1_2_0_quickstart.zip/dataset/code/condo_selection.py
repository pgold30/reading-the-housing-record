"""Descriptive selection diagnostics using only deposited tables; no network."""
import argparse,collections,json,math,statistics,hashlib
from pathlib import Path
from recorded_mortgage_example import eligible_condos,annual,write

def quantile(values,p):
 v=sorted(values);i=(len(v)-1)*p;j=int(i);return v[j]+(v[min(j+1,len(v)-1)]-v[j])*(i-j)

def band(price):
 if price<100000:return '<100k'
 if price<500000:return '100k–<500k'
 if price<1000000:return '500k–<1m'
 if price<2000000:return '1m–<2m'
 if price<6000000:return '2m–<6m'
 return '>=6m'

def main():
 p=argparse.ArgumentParser();p.add_argument('build',type=Path);p.add_argument('--output',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args();a.output.mkdir(exist_ok=True,parents=True)
 rows,excluded=eligible_condos(a.build);annualrows=annual(rows);write(a.output/'annual_condo_coverage.csv',annualrows)
 groups={'all_eligible':rows,'unique':[s for s in rows if s['deed_match']=='unique'],'none':[s for s in rows if s['deed_match']=='none'],'ambiguous':[s for s in rows if s['deed_match']=='ambiguous'],'all_unlinked':[s for s in rows if s['deed_match']!='unique']};summary=[]
 for name,ss in groups.items():
  prices=[float(s['sale_price']) for s in ss];logs=[math.log(x) for x in prices];summary.append({'group':name,'n':len(ss),'mean_price':statistics.mean(prices),'p25_price':quantile(prices,.25),'median_price':statistics.median(prices),'p75_price':quantile(prices,.75),'mean_log_price':statistics.mean(logs),'sd_log_price':statistics.stdev(logs),'manhattan_pct':100*sum(s['borough']=='1' for s in ss)/len(ss),'price_below_100k_pct':100*sum(x<100000 for x in prices)/len(ss),'price_ge_2m_pct':100*sum(x>=2000000 for x in prices)/len(ss)})
 write(a.output/'condo_group_summary.csv',summary)
 tables=[]
 for dim,key in [('borough',lambda s:s['borough']),('year',lambda s:s['sale_date'][:4]),('price_band',lambda s:band(float(s['sale_price']))),('borough_year',lambda s:s['borough']+'|'+s['sale_date'][:4])]:
  by=collections.defaultdict(list)
  for s in rows:by[key(s)].append(s)
  for group,ss in sorted(by.items()):
   c=collections.Counter(s['deed_match'] for s in ss);tables.append({'dimension':dim,'group':group,'eligible':len(ss),'unique':c['unique'],'none':c['none'],'ambiguous':c['ambiguous'],'unique_pct':100*c['unique']/len(ss),'none_pct':100*c['none']/len(ss),'ambiguous_pct':100*c['ambiguous']/len(ss)})
 write(a.output/'condo_coverage_by_group.csv',tables)
 missing=[]
 for name,ss in groups.items():
  for field,rule in [('gross_square_feet','blank_or_nonpositive'),('year_built','blank_or_nonpositive'),('zip_code','blank_or_zero'),('latitude','blank_or_zero')]:
   def absent(s):
    v=s.get(field,'').strip()
    if not v:return True
    try:return float(v)<=0 if rule=='blank_or_nonpositive' else float(v)==0
    except ValueError:return True
   count=sum(absent(s) for s in ss);missing.append({'group':name,'field':field,'missing_rule':rule,'n':len(ss),'missing':count,'missing_pct':100*count/len(ss)})
 write(a.output/'condo_source_missingness.csv',missing)
 u=next(x for x in summary if x['group']=='unique');v=next(x for x in summary if x['group']=='all_unlinked');smd=(u['mean_log_price']-v['mean_log_price'])/math.sqrt((u['sd_log_price']**2+v['sd_log_price']**2)/2)
 result={'eligible_n':len(rows),'exclusions':excluded,'groups':summary,'standardized_log_price_difference_unique_minus_unlinked':smd,'smd_definition':'difference in mean log(price) divided by sqrt((sd_unique^2 + sd_unlinked^2)/2); descriptive, no sampling inference','input_sha256':{f:hashlib.file_digest(open(a.build/f,'rb'),'sha256').hexdigest() for f in ['sales.csv.gz','links.csv.gz']},'notes':['Denominator is condo sales with positive price in boroughs 1–4 during 2016–2025. Low positive/nominal amounts are retained, matching linkage eligibility.','Unique vs unlinked distributions describe coverage selection, not accuracy or a causal mechanism.','Unlinked mortgage outcomes are unknown, not zero. Only one released snapshot is described.','Gross area and year built zero values treated as unavailable; no imputation.']}
 assert len(rows)==126251 and len(groups['unique'])==121263 and len(groups['none'])==4910 and len(groups['ambiguous'])==78
 assert sum(x['eligible_condo_sales'] for x in annualrows)==len(rows)
 (a.output/'dataset_results.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
