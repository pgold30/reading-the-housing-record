"""Reproduce condominium coverage and linked/unlinked selection from release 1.2.0."""
from pathlib import Path
import argparse,hashlib,json,sys
ROOT=Path(__file__).resolve().parent
def start():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--output',type=Path,default=ROOT/'results')
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
 expected=json.loads((ROOT/'INPUT_SHA256.json').read_text())
 for rel,wanted in expected.items():
  with (ROOT/rel).open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
  if actual!=wanted:raise ValueError('Input hash mismatch: '+rel)
 return a.output

import subprocess,csv,math
out=start()
run=subprocess.run([sys.executable,str(ROOT/'code/condo_selection.py'),str(ROOT/'build'),'--output',str(out)],capture_output=True,text=True)
(out/'run.log').write_text(run.stdout+run.stderr)
if run.returncode:raise RuntimeError('Example failed; see '+str(out/'run.log'))
j=json.loads((out/'dataset_results.json').read_text());expected=json.loads((ROOT/'expected_full_release_results.json').read_text())
if j['eligible_n']!=expected['eligible_n']:raise ValueError('Eligible count differs')
for actual,wanted in zip(j['groups'],expected['groups']):
 for k,v in wanted.items():
  if isinstance(v,(int,float)):
   if not math.isclose(actual[k],v,rel_tol=1e-12,abs_tol=1e-10):raise ValueError('Selection output differs: '+k)
  elif actual[k]!=v:raise ValueError('Selection group differs')
groups={g['group']:g for g in j['groups']}
with (out/'annual_condo_coverage.csv').open() as f:annual=list(csv.DictReader(f))
result={'release':'dataset 1.2.0','eligible_condos':j['eligible_n'],'linked_condos':groups['unique']['n'],'unlinked_condos':groups['all_unlinked']['n'],'coverage_pct':100*groups['unique']['n']/j['eligible_n'],'annual_rows':len(annual),'financing_unmeasured':sum(int(r['financing_unmeasured']) for r in annual),'linked_unlinked_descriptive_statistics_match_full_release':True,'scope':'Eligible condominium extract only. Exclusion counts outside this extract are not the full-release counts. Mortgage shares concern linked sales; unlinked financing remains unknown.'}
(out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
