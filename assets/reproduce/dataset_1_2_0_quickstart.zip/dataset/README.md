# Dataset 1.2.0: one runnable example

Requires Python 3.11+ and its standard library. No account, API, network or extra package is needed after download. Unzip this folder, open a terminal here and run:

    python3 run.py

Expected: 126,251 eligible condominium sales, 121,263 deed links (96.049%), 4,988 unlinked sales and ten annual rows. `results/annual_condo_coverage.csv` reports yearly mortgage matches and the denominator; `results/condo_group_summary.csv` compares linked and unlinked prices. `results/RESULTS.json` records successful checks.

The small extract contains only the eligible condominium rows and fields used in the examples. It is derived from dataset 1.2.0, https://doi.org/10.5281/zenodo.23557585. It omits street addresses, party names, individual document numbers and the rest of the sales universe. Exclusion counts in this subset are therefore not full-release exclusion counts. Source-file hashes and extraction rules are in PROVENANCE.json. Derived tables and code: CC BY 4.0, credit Pablo Loschi; original source records retain their terms.

This refits descriptive aggregates from frozen inputs. It does not rerun the linker, verify deed matches or establish purchase financing. A missing mortgage match is not proof of a cash purchase.
