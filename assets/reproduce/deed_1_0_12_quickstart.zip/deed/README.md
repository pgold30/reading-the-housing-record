# Deed 1.0.12: a small index refit

Requires Python 3.11+, numpy and pandas. Install with `python3 -m pip install -r requirements.txt` if needed. From this folder run:

    python3 run.py

Expected: 140,119 repeat-sale pairs; raw-minus-screened differences of 3.69 log points in 2010Q3 (D0), 2.63 under narrow D4 and −2.28 on average in 2011–12. The peak-to-trough contrast is about −0.64. The bridge path is 7.59 in 2010Q3 and reaches 8.09 in 2010Q1. All 92 refitted quarters are saved in `results/index_paths.csv` and the summary in `results/RESULTS.json`.

The frozen pair inputs were derived from the public baseline deed input using the original Stage 03 screen/pairing and Stage 07 definitions. PROVENANCE.json records the raw-input hash and exact scope. Names, addresses, parcel and document identifiers are omitted from these reduced inputs. The baseline data and complete code remain at https://doi.org/10.5281/zenodo.23414919; the current manuscript/evidence update is https://doi.org/10.5281/zenodo.23638576. Derived inputs and code: CC BY 4.0, credit Pablo Loschi.

This is a fresh refit from frozen pairs, not merely a lookup of saved coefficients. It is also not a full reproduction of classification-rate uncertainty, human review, the classifier, sale-date/horizon alternatives or all manuscript tables. Those remain in the full archives and require their documented inputs. Fixed-label paths should not be presented as a verified market-price correction. The included uncertainty summary is contextual saved output and is not re-estimated by this command.


## Optional rebuild from the original deed input

Install `pyarrow` in addition to the quick-start requirements. Obtain `deeds.parquet` from the baseline data archive linked above, then run:

    python3 derive_inputs.py /path/to/deeds.parquet

This checks the frozen raw-file SHA-256, runs the original screen, pairing and narrow definitions, writes `rebuilt_inputs/`, and compares both rebuilt pair tables with the bundled input rows. It reads no human workbook or analyst key and does not change classifier labels.

