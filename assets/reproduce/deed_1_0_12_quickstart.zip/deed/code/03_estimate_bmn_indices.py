"""Stage 03: Bailey-Muth-Nourse quarterly repeat-sales indices, raw vs clean.

Screen (fixed in notes/GO_NO_GO.md before results were seen):
  deed: doc_type DEED; consideration >= $10,000; not a partial interest;
        one BBL; no easement/air/subterranean/partial-lot legal; one of the
        four residential classes; four boroughs.
  pair: adjacent screened sales of one BBL; holding >= 180 days;
        |annualised log change| <= 1.

Variants
  raw     every screened deed.
  drop    raw pairs, minus any pair with a non-market-amount endpoint.
  bridge  non-market deeds removed from the sale sequence BEFORE pairing, so
          the sales on either side of one become a new, longer pair.
  no_AL   raw minus pairs whose SECOND sale is non-market (A -> L).
  no_LB   raw minus pairs whose FIRST sale is non-market (L -> B).
The last two split the drop correction into its two legs, which push the
index in opposite directions.

Placebo: the max over 92 quarters of a noisy difference is inflated by
construction. For each primary series we flag random ORDINARY screened deeds,
matched to the non-market deeds on borough x quarter counts, apply the drop
correction, and record max|diff|. The observed value is compared with that
distribution.

Uncertainty: property-clustered bootstrap with Poisson(1) weights per BBL,
the same draws for every variant, so differences are paired.
"""
import json
import os

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DER, TAB = os.path.join(ROOT, "data", "derived"), os.path.join(ROOT, "output", "tables")
NONMARKET = {"LENDER_ACQ_REFEREE", "LENDER_ACQ_OTHER", "LENDER_TO_LENDER"}
Q0, NQ = 2003, 92          # 2003Q1 .. 2025Q4
B = 300
rng = np.random.default_rng(20260923)


def quarter(d):
    return (d.dt.year - Q0) * 4 + (d.dt.month - 1) // 3


def screen(deeds):
    d = deeds
    m = ((d["doc_type"] == "DEED") & (d["amount"] >= 10_000)
         & ~((d["pct"] > 0) & (d["pct"] < 100)) & (d["n_bbl"] == 1) & ~d["odd"]
         & d["pclass"].isin(["1-3 family", "condo unit", "4-6 family", "apartment bldg"])
         & d["date"].between("2003-01-01", "2025-12-31"))
    s = d[m].copy()
    # one sale per parcel-day: keep the last-recorded document
    s = s.sort_values(["bbl", "date", "rec_date", "document_id"])
    s = s.drop_duplicates(["bbl", "date"], keep="last")
    s["nm"] = s["event"].isin(NONMARKET)
    s["q"] = quarter(s["date"])
    return s


def pairs(s):
    s = s.sort_values(["bbl", "date"])
    a, z = s.iloc[:-1].reset_index(drop=True), s.iloc[1:].reset_index(drop=True)
    same = (a["bbl"].to_numpy() == z["bbl"].to_numpy())
    a, z = a[same].reset_index(drop=True), z[same].reset_index(drop=True)
    days = (z["date"] - a["date"]).dt.days.to_numpy()
    y = np.log(z["amount"].to_numpy()) - np.log(a["amount"].to_numpy())
    P = pd.DataFrame({"bbl": a["bbl"], "borough": a["borough"], "pclass": a["pclass"],
                      "qa": a["q"].to_numpy(), "qz": z["q"].to_numpy(), "days": days,
                      "y": y, "p1": a["amount"].to_numpy(), "p2": z["amount"].to_numpy(),
                      "doc1": a["document_id"].to_numpy(), "doc2": z["document_id"].to_numpy(),
                      "ev1": a["event"].to_numpy(), "ev2": z["event"].to_numpy(),
                      "nm1": a["nm"].to_numpy(), "nm2": z["nm"].to_numpy(),
                      "fin1": a["financed"].to_numpy(), "fin2": z["financed"].to_numpy(),
                      "cents1": a["cents"].to_numpy(), "d1": a["date"].to_numpy(),
                      "d2": z["date"].to_numpy()})
    keep = (P["days"] >= 180) & (np.abs(P["y"]) / (P["days"] / 365.25) <= 1.0)
    return P[keep].reset_index(drop=True)


def bmn(qa, qz, y, w=None):
    """OLS of y on time dummies (-1 at first sale, +1 at second), delta_0 = 0."""
    w = np.ones(len(y)) if w is None else w
    k = NQ * NQ
    XtX = (np.bincount(qa * NQ + qa, w, k) + np.bincount(qz * NQ + qz, w, k)
           - np.bincount(qa * NQ + qz, w, k) - np.bincount(qz * NQ + qa, w, k)).reshape(NQ, NQ)
    Xty = np.bincount(qz, w * y, NQ) - np.bincount(qa, w * y, NQ)
    A, b = XtX[1:, 1:], Xty[1:]
    ok = np.diag(A) > 0
    d = np.full(NQ, np.nan)
    d[0] = 0.0
    sol = np.linalg.lstsq(A[np.ix_(ok, ok)], b[ok], rcond=None)[0]
    d[1:][ok] = sol
    return d


def variants(P):
    nm1, nm2 = P["nm1"].to_numpy(), P["nm2"].to_numpy()
    return {"raw": P.index.to_numpy(),
            "drop": np.where(~nm1 & ~nm2)[0],
            "no_AL": np.where(~nm2)[0],
            "no_LB": np.where(~nm1)[0]}


def peak_trough(d):
    q = np.arange(NQ)
    pk = np.nanmax(np.where((q >= 8) & (q < 24), d, np.nan))     # 2005-2008
    tr = np.nanmin(np.where((q >= 20) & (q < 44), d, np.nan))    # 2008-2013
    return pk - tr


def trough(d):
    """Quarter of the index minimum, 2008Q1-2013Q4."""
    return 20 + int(np.nanargmin(d[20:44]))


def qlab(t):
    return f"{Q0 + t // 4}Q{t % 4 + 1}"


def run_series(P, Pb, label):
    idx = variants(P)
    bbls = pd.Index(np.union1d(P["bbl"].unique(), Pb["bbl"].unique()))
    ia, ib = bbls.get_indexer(P["bbl"]), bbls.get_indexer(Pb["bbl"])
    est = {}
    for v, ix in idx.items():
        est[v] = bmn(P["qa"].to_numpy()[ix], P["qz"].to_numpy()[ix], P["y"].to_numpy()[ix])
    est["bridge"] = bmn(Pb["qa"].to_numpy(), Pb["qz"].to_numpy(), Pb["y"].to_numpy())
    boots = {v: [] for v in ("drop", "bridge", "no_AL", "no_LB")}
    bpt = {v: [] for v in boots}
    btr = {"raw": [], "drop": [], "bridge": []}
    for _ in range(B):
        wb = rng.poisson(1.0, len(bbls)).astype(float)
        wa, wbb = wb[ia], wb[ib]
        r = bmn(P["qa"].to_numpy(), P["qz"].to_numpy(), P["y"].to_numpy(), wa)
        btr["raw"].append(trough(r))
        for v in ("drop", "no_AL", "no_LB"):
            ix = idx[v]
            c = bmn(P["qa"].to_numpy()[ix], P["qz"].to_numpy()[ix], P["y"].to_numpy()[ix], wa[ix])
            boots[v].append(r - c)
            bpt[v].append(peak_trough(r) - peak_trough(c))
            if v == "drop":
                btr["drop"].append(trough(c))
        c = bmn(Pb["qa"].to_numpy(), Pb["qz"].to_numpy(), Pb["y"].to_numpy(), wbb)
        btr["bridge"].append(trough(c))
        boots["bridge"].append(r - c)
        bpt["bridge"].append(peak_trough(r) - peak_trough(c))
    rows, summ = [], {}
    for v in ("drop", "bridge", "no_AL", "no_LB"):
        dd = 100 * (est["raw"] - est[v])
        lo, hi = np.nanpercentile(100 * np.array(boots[v]), [2.5, 97.5], axis=0)
        for t in range(NQ):
            rows.append(dict(series=label, variant=v, q=t,
                             year=Q0 + t // 4, qtr=t % 4 + 1,
                             delta_raw=100 * est["raw"][t], delta_clean=100 * est[v][t],
                             diff=dd[t], diff_lo=lo[t], diff_hi=hi[t]))
        t_max = int(np.nanargmax(np.abs(dd)))
        ptd = 100 * (peak_trough(est["raw"]) - peak_trough(est[v]))
        plo, phi = np.nanpercentile(100 * np.array(bpt[v]), [2.5, 97.5])
        summ[v] = dict(max_abs_diff=float(np.abs(dd[t_max])), at=f"{Q0 + t_max // 4}Q{t_max % 4 + 1}",
                       diff_at_max=float(dd[t_max]), ci_at_max=[float(lo[t_max]), float(hi[t_max])],
                       peak_trough_raw=float(100 * peak_trough(est["raw"])),
                       peak_trough_clean=float(100 * peak_trough(est[v])),
                       peak_trough_diff=float(ptd), peak_trough_ci=[float(plo), float(phi)])
    summ["trough"] = {}
    for v in ("raw", "drop", "bridge"):
        t = np.array(btr[v])
        lo_, hi_ = np.percentile(t, [5, 95]).astype(int)
        summ["trough"][v] = dict(point=qlab(trough(est[v])), boot_p05=qlab(lo_), boot_p95=qlab(hi_),
                                 boot_mode=qlab(int(np.bincount(t).argmax())))
    lag = np.array(btr["raw"]) - np.array(btr["drop"])
    summ["trough"]["raw_minus_drop_quarters"] = dict(
        point=trough(est["raw"]) - trough(est["drop"]), median=float(np.median(lag)),
        p05=float(np.percentile(lag, 5)), p95=float(np.percentile(lag, 95)),
        share_positive=float(np.mean(lag > 0)))
    n = len(P)
    summ["pairs"] = int(n)
    summ["pairs_per_quarter"] = round(n / NQ, 1)
    summ["pairs_nonmarket_first"] = int(P["nm1"].sum())
    summ["pairs_nonmarket_second"] = int(P["nm2"].sum())
    summ["pairs_bridge"] = int(len(Pb))
    return rows, summ


def placebo(S, P, draws=200, seed=7):
    """max|raw - drop| when random ordinary deeds (same borough x quarter
    counts as the non-market ones) are flagged instead."""
    r = np.random.default_rng(seed)
    raw = bmn(P["qa"].to_numpy(), P["qz"].to_numpy(), P["y"].to_numpy())
    need = S[S["nm"]].groupby(["borough", "q"]).size()
    ords = S[S["event"] == "ORDINARY"]
    grp, ids = ords.groupby(["borough", "q"]).indices, ords["document_id"].to_numpy()
    d1, d2 = P["doc1"].to_numpy(), P["doc2"].to_numpy()
    out = []
    for _ in range(draws):
        fake = set(np.concatenate([ids[r.choice(grp[k], min(n, len(grp[k])), replace=False)]
                                   for k, n in need.items() if k in grp]))
        k = ~np.fromiter((x in fake for x in d1), bool, len(d1)) & \
            ~np.fromiter((x in fake for x in d2), bool, len(d2))
        c = bmn(P["qa"].to_numpy()[k], P["qz"].to_numpy()[k], P["y"].to_numpy()[k])
        out.append(100 * np.nanmax(np.abs(raw - c)))
    return np.array(out)


def main():
    deeds = pd.read_parquet(os.path.join(DER, "deeds.parquet"))
    S = screen(deeds)
    P = pairs(S)
    Pb = pairs(S[~S["nm"]])
    P.to_parquet(os.path.join(DER, "pairs_raw.parquet"), index=False)
    Pb.to_parquet(os.path.join(DER, "pairs_bridge.parquet"), index=False)
    print(f"screened sales {len(S):,}  raw pairs {len(P):,}  bridge pairs {len(Pb):,}  "
          f"non-market endpoints: first {int(P['nm1'].sum()):,} second {int(P['nm2'].sum()):,}",
          flush=True)
    specs = [("city | all residential", None, None)]
    for c in ("1-3 family", "condo unit", "4-6 family", "apartment bldg"):
        specs.append((f"city | {c}", None, c))
    for b, bn in (("1", "Manhattan"), ("2", "Bronx"), ("3", "Brooklyn"), ("4", "Queens")):
        for c in ("1-3 family", "condo unit", "4-6 family"):
            specs.append((f"{bn} | {c}", b, c))
    all_rows, summary = [], {}
    for label, b, c in specs:
        mP = np.ones(len(P), bool) if b is None else (P["borough"] == b).to_numpy().copy()
        mB = np.ones(len(Pb), bool) if b is None else (Pb["borough"] == b).to_numpy().copy()
        if c is not None:
            mP &= (P["pclass"] == c).to_numpy()
            mB &= (Pb["pclass"] == c).to_numpy()
        if mP.sum() < 2000:
            print(f"  {label:<28} {int(mP.sum()):>7,} pairs: skipped (<2,000)")
            continue
        rows, s = run_series(P[mP].reset_index(drop=True), Pb[mB].reset_index(drop=True), label)
        all_rows += rows
        summary[label] = s
        print(f"  {label:<28} {s['pairs']:>7,} pairs  nm-first {s['pairs_nonmarket_first']:>5,} "
              f"nm-second {s['pairs_nonmarket_second']:>5,} | drop max|d| {s['drop']['max_abs_diff']:5.2f} "
              f"@{s['drop']['at']}  bridge {s['bridge']['max_abs_diff']:5.2f}  "
              f"PTdiff drop {s['drop']['peak_trough_diff']:+5.2f} bridge {s['bridge']['peak_trough_diff']:+5.2f}",
              flush=True)
    for label, c in (("city | 1-3 family", "1-3 family"), ("city | condo unit", "condo unit")):
        pl = placebo(S[S["pclass"] == c], P[P["pclass"] == c].reset_index(drop=True))
        obs = summary[label]["drop"]["max_abs_diff"]
        summary[label]["placebo"] = dict(draws=len(pl), median=float(np.median(pl)),
                                         p95=float(np.percentile(pl, 95)), max=float(pl.max()),
                                         share_ge_observed=float(np.mean(pl >= obs)))
        print(f"  placebo {label:<20} observed {obs:5.2f}  placebo median {np.median(pl):4.2f} "
              f"p95 {np.percentile(pl, 95):4.2f} max {pl.max():4.2f}  P(>=obs) {np.mean(pl >= obs):.3f}",
              flush=True)
    pd.DataFrame(all_rows).to_csv(os.path.join(TAB, "bmn_index_differences.csv"), index=False)
    json.dump(summary, open(os.path.join(DER, "stage03_summary.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
