"""Optionally rebuild the reduced pair inputs from the frozen public deeds.parquet."""
from pathlib import Path
import argparse,csv,gzip,hashlib,importlib.util,io,json
import pandas as pd

ROOT=Path(__file__).resolve().parent
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def write(path,fields,rows):
 with path.open('wb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
   with io.TextIOWrapper(gz,newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('deeds',type=Path);p.add_argument('--output',type=Path,default=ROOT/'rebuilt_inputs');a=p.parse_args()
 expected=json.loads((ROOT/'PROVENANCE.json').read_text())
 with a.deeds.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 if digest!=expected['deeds_parquet_sha256']:raise ValueError('Wrong source snapshot; input hash differs')
 a.output.mkdir(parents=True,exist_ok=True)
 s03=load('s03',ROOT/'code/03_estimate_bmn_indices.py');s07=load('s07',ROOT/'input_derivation/07_narrower_definitions.py')
 S=s03.screen(pd.read_parquet(a.deeds));P=s03.pairs(S);P=P[P.pclass.eq('1-3 family')].reset_index(drop=True)
 definitions=s07.definitions(S);D0=set(S.loc[definitions['D0'],'document_id']);D4=set(S.loc[definitions['D4'],'document_id'])
 write(a.output/'pairs.csv.gz',['qa','qz','y','keep_d0','keep_d4'],({'qa':int(r.qa),'qz':int(r.qz),'y':repr(float(r.y)),'keep_d0':int(r.doc1 not in D0 and r.doc2 not in D0),'keep_d4':int(r.doc1 not in D4 and r.doc2 not in D4)} for r in P.itertuples()))
 bridge=s03.pairs(S[~S.nm]);bridge=bridge[bridge.pclass.eq('1-3 family')]
 write(a.output/'bridge_pairs.csv.gz',['qa','qz','y'],({'qa':int(r.qa),'qz':int(r.qz),'y':repr(float(r.y))} for r in bridge.itertuples()))
 result={}
 for name in ['pairs.csv.gz','bridge_pairs.csv.gz']:
  same=gzip.decompress((a.output/name).read_bytes())==gzip.decompress((ROOT/'inputs'/name).read_bytes())
  if not same:raise ValueError('Rebuilt pair input differs: '+name)
  result[name]={'decompressed_bytes_match':True,'sha256':hashlib.sha256((a.output/name).read_bytes()).hexdigest()}
 (a.output/'REBUILD_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
