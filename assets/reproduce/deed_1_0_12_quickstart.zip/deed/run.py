"""Refit the main fixed-label Deed index and its bridge sensitivity."""
from pathlib import Path
import argparse,hashlib,json,sys
ROOT=Path(__file__).resolve().parent
def start():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--output',type=Path,default=ROOT/'results')
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
 expected=json.loads((ROOT/'INPUT_SHA256.json').read_text())
 for rel,wanted in expected.items():
  with (ROOT/rel).open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
  if actual!=wanted:raise ValueError('Input hash mismatch: '+rel)
 return a.output

import importlib.util,numpy as np,pandas as pd
out=start();spec=importlib.util.spec_from_file_location('bmn',ROOT/'code/03_estimate_bmn_indices.py');bmn=importlib.util.module_from_spec(spec);spec.loader.exec_module(bmn)
p=pd.read_csv(ROOT/'inputs/pairs.csv.gz',float_precision='round_trip');bridge=pd.read_csv(ROOT/'inputs/bridge_pairs.csv.gz',float_precision='round_trip')
def fit(d):return bmn.bmn(d.qa.to_numpy(),d.qz.to_numpy(),d.y.to_numpy())
raw=fit(p);d0=fit(p[p.keep_d0.eq(1)]);d4=fit(p[p.keep_d4.eq(1)]);db=fit(bridge)
paths={'D0':100*(raw-d0),'D4':100*(raw-d4),'bridge':100*(raw-db)}
expected=json.loads((ROOT/'inputs/archived_uncertainty_summary.json').read_text())['baseline_point']
if len(p)!=140119:raise ValueError('Wrong pair count')
if not np.isclose(paths['D0'][30],expected['diff_2010Q3'],atol=1e-10):raise ValueError('D0 differs')
if not np.isclose(paths['D0'][32:40].mean(),expected['mean_2011-12'],atol=1e-10):raise ValueError('Later mean differs')
if round(paths['D4'][30],2)!=2.63:raise ValueError('D4 differs')
if round(paths['bridge'][30],2)!=7.59 or round(paths['bridge'].max(),2)!=8.09 or bmn.qlab(int(paths['bridge'].argmax()))!='2010Q1':raise ValueError('Bridge comparison differs')
table=pd.DataFrame({'quarter':[bmn.qlab(q) for q in range(92)],'raw':100*raw,'screened_D0':100*d0,'screened_D4':100*d4,'bridge':100*db,**{'raw_minus_'+k:v for k,v in paths.items()}});table.to_csv(out/'index_paths.csv',index=False)
result={'release':'Deed 1.0.12','pairs':len(p),'D0_2010Q3':float(paths['D0'][30]),'D4_2010Q3':float(paths['D4'][30]),'D0_mean_2011_12':float(paths['D0'][32:40].mean()),'D0_peak_trough':float(100*(bmn.peak_trough(raw)-bmn.peak_trough(d0))),'bridge_2010Q3':float(paths['bridge'][30]),'bridge_maximum':float(paths['bridge'].max()),'bridge_maximum_quarter':bmn.qlab(int(paths['bridge'].argmax())),'scope':'Fresh fixed-label point estimates from frozen pair inputs. Does not rerun classifier construction, human validation, bootstrap or classification-rate uncertainty. These comparisons do not establish a market-price correction.'}
(out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
