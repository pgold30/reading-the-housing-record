"""Stage 07 (v1.0.4): the 1-3 family drop result under narrower and broader
definitions of the non-market set.

Uses stage 03's functions unmodified (screen, pairs, bmn, peak_trough, qlab).
For each definition, pairs with a flagged endpoint are dropped and the
quarterly index for 1-3 family houses is re-estimated. Reported: the largest
quarterly raw-minus-drop difference, its quarter and a pointwise interval from
a paired Poisson(1) parcel bootstrap (B = 300; stage 03's scheme, but its own
draws, so D0's interval differs from Table 4 in the second decimal); the
peak-to-trough difference; and a placebo that drops random ORDINARY 1-3 family
deeds that the definition does not flag, matched to the flagged 1-3 family
deeds on borough x quarter counts (200 draws, seed 7, as in stage 03, so D0
reproduces Table 4's placebo exactly).

Definitions (all come from the same classifier; none is independently
validated)
  D0 published      referee's deeds to lenders, other transfers to lenders,
                    lender-to-lender transfers
  D1 referee only   referee's deeds to lenders
  D2 no securitization category
                    D0 minus deeds whose grantee category is "securitization".
                    This removes five of the seven ambiguous REO-named cases
                    of the document review; two stay, as bank_servicer.
  D3 nonzero cents  D0 deeds whose recorded amount has nonzero cents
  D4 narrowest      D1 and D2 and D3
  D5 broad          the classifier's broad option

Also counted: flagged endpoints of dropped pairs that are not 1-3 family
deeds. They cause pair deletion but lie outside the placebo's matching set.

Usage: python code/07_narrower_definitions.py [--check manuscript/manuscript.md]
Reads data/derived/deeds.parquet (set DER to use another folder); writes
output/tables/narrower_definitions.json.
"""
import importlib.util
import json
import os
import re
import sys

import numpy as np
import pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location("s03", os.path.join(ROOT, "code", "03_estimate_bmn_indices.py"))
s03 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s03)
DER = os.environ.get("DER", s03.DER)
OUT = os.path.join(ROOT, "output", "tables", "narrower_definitions.json")
B, PLACEBO, SEED_BOOT, SEED_PLACEBO = 300, 200, 20260923, 7
NM = s03.NONMARKET


def definitions(S):
    nm = S["event"].isin(NM)
    nosec = nm & (S["grantee_cat"].fillna("") != "securitization")
    cents = nm & (S["cents"] % 100 != 0)
    ref = S["event"] == "LENDER_ACQ_REFEREE"
    return {"D0": nm, "D1": ref, "D2": nosec, "D3": cents, "D4": ref & nosec & (S["cents"] % 100 != 0),
            "D5": S["event_broad"].isin(NM)}


def main():
    S = s03.screen(pd.read_parquet(os.path.join(DER, "deeds.parquet")))
    P = s03.pairs(S)
    Pf = P[P["pclass"] == "1-3 family"].reset_index(drop=True)
    qa, qz, y = Pf["qa"].to_numpy(), Pf["qz"].to_numpy(), Pf["y"].to_numpy()
    raw = s03.bmn(qa, qz, y)
    bbl = pd.Index(Pf["bbl"].unique()).get_indexer(Pf["bbl"])
    rng = np.random.default_rng(SEED_BOOT)
    W = [rng.poisson(1.0, bbl.max() + 1)[bbl].astype(float) for _ in range(B)]
    raw_b = [s03.bmn(qa, qz, y, w) for w in W]
    Sf = S[S["pclass"] == "1-3 family"]
    fam = set(Sf["document_id"])
    d1, d2 = pd.Series(Pf["doc1"].to_numpy()), pd.Series(Pf["doc2"].to_numpy())
    member = lambda ids: (d1.isin(ids) | d2.isin(ids)).to_numpy()
    out = {"pairs": int(len(Pf)), "bootstrap": {"draws": B, "seed": SEED_BOOT},
           "placebo": {"draws": PLACEBO, "seed": SEED_PLACEBO}, "definitions": {}}
    for name, mask in definitions(S).items():
        flagged = set(S.loc[mask, "document_id"])
        k = ~member(flagged)
        clean = s03.bmn(qa[k], qz[k], y[k])
        diff = 100 * (raw - clean)
        t = int(np.nanargmax(np.abs(diff)))
        bd, bpt = [], []
        for w, rb in zip(W, raw_b):
            cb = s03.bmn(qa[k], qz[k], y[k], w[k])
            bd.append(100 * (rb - cb))
            bpt.append(100 * (s03.peak_trough(rb) - s03.peak_trough(cb)))
        bd = np.array(bd)
        fmask = mask.loc[Sf.index]
        ords = Sf[(Sf["event"] == "ORDINARY") & ~fmask]
        grp, ids = ords.groupby(["borough", "q"]).indices, ords["document_id"].to_numpy()
        need = Sf[fmask].groupby(["borough", "q"]).size()
        short = int(sum(max(0, n - len(grp.get(g, []))) for g, n in need.items()))
        prng = np.random.default_rng(SEED_PLACEBO)
        pl = []
        for _ in range(PLACEBO):
            fake = set(np.concatenate([ids[prng.choice(grp[g], min(n, len(grp[g])), replace=False)]
                                       for g, n in need.items() if g in grp]))
            kk = ~member(fake)
            pl.append(100 * np.nanmax(np.abs(raw - s03.bmn(qa[kk], qz[kk], y[kk]))))
        pl = np.array(pl)
        hit = set(d1[~k]) | set(d2[~k])
        out["definitions"][name] = {
            "flagged_1_3_family": int(fmask.sum()), "pairs_dropped": int((~k).sum()),
            "max_abs_diff": float(abs(diff[t])), "at": s03.qlab(t), "diff_at_max": float(diff[t]),
            "ci_at_max_pointwise": [float(np.nanpercentile(bd[:, t], 2.5)), float(np.nanpercentile(bd[:, t], 97.5))],
            "diff_2010Q3": float(diff[(2010 - s03.Q0) * 4 + 2]),
            "peak_trough_diff": float(100 * (s03.peak_trough(raw) - s03.peak_trough(clean))),
            "peak_trough_ci": [float(np.percentile(bpt, 2.5)), float(np.percentile(bpt, 97.5))],
            "placebo_pool": int(len(ords)), "placebo_shortfall": short,
            "placebo_median": float(np.median(pl)), "placebo_p95": float(np.percentile(pl, 95)),
            "placebo_max": float(pl.max()), "placebo_share_ge_observed": float(np.mean(pl >= abs(diff[t]))),
            "flagged_endpoints_other_class": len((hit & flagged) - fam)}
        o = out["definitions"][name]
        print(f"{name}: flagged {o['flagged_1_3_family']:6,} dropped {o['pairs_dropped']:6,} | max {o['max_abs_diff']:.2f} "
              f"@{o['at']} [{o['ci_at_max_pointwise'][0]:.2f}, {o['ci_at_max_pointwise'][1]:.2f}] | PT {o['peak_trough_diff']:+.2f} "
              f"[{o['peak_trough_ci'][0]:+.2f}, {o['peak_trough_ci'][1]:+.2f}] | placebo max {o['placebo_max']:.2f} "
              f"| other-class endpoints {o['flagged_endpoints_other_class']}", flush=True)
    d0 = out["definitions"]["D0"]
    assert d0["pairs_dropped"] == 12_483 and round(d0["max_abs_diff"], 2) == 3.69 and d0["at"] == "2010Q3"
    assert round(d0["placebo_max"], 2) == 1.94, "D0 should reproduce Table 4's placebo"
    json.dump(out, open(OUT, "w"), indent=1)
    print("wrote", os.path.relpath(OUT, ROOT))


def check(md_path):
    """Confirm the numbers Section 4.5 quotes against the saved output."""
    R = json.load(open(OUT))["definitions"]
    text = re.sub(r"\s+", " ", open(md_path).read())
    ok = []
    s = lambda v: f"{v:+.2f}".replace("-", "−")
    for name, o in R.items():
        lo, hi = o["ci_at_max_pointwise"]
        plo, phi = o["peak_trough_ci"]
        row = (f"| {o['flagged_1_3_family']:,} | {o['pairs_dropped']:,} | {s(o['diff_at_max'])} [{s(lo)}, {s(hi)}] | {o['at']} | "
               f"{o['placebo_max']:.2f} | {s(o['peak_trough_diff'])} [{s(plo)}, {s(phi)}] |")
        good = row in text and o["placebo_share_ge_observed"] == 0 and o["placebo_shortfall"] == 0
        ok.append(good)
        print("PASS" if good else "FAIL", name, row)
    oc = [R[k]["flagged_endpoints_other_class"] for k in ("D0", "D4")]
    good = f"{oc[0]} under D0 and {oc[1]} under D4" in text
    ok.append(good)
    print("PASS" if good else "FAIL", "other-class endpoints", oc)
    print(f"{sum(ok)} of {len(ok)} checks pass")
    sys.exit(0 if all(ok) else 1)


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "--check":
        check(sys.argv[2])
    else:
        main()
