# Table-note wording for the v3.9 replication package

The house paper's table notes come from the replication scripts in the frozen v3.8 package (`paper_improvements_2026-10-14/.../house_v3.8/.../replication/code/`). That package carries published hashes, so it is left untouched.

For v3.9 I reworded the "X, not Y" phrasings in the notes, in `../generated/*.tex`. The same wording changes are applied here to copies of the five scripts that write those notes. `table_note_wording.patch` shows the diff against v3.8. Only note strings change; no computation changes.

When building the v3.9 replication deposit, replace the five scripts in `replication/code/` with the versions in `code/`. Then copy `../generated/probability_sample.tex` over the deposit's file of the same name: in v3.8 that table's notes are not written by any script.
