# Company-cash split without buyer-type controls

This check answers the second-opinion referee's objection to Table 6, Panel B. `company_split.py` imports the v3.8 replication code (`data_external/house_replication/code/`) and its data. It reproduces the published Panel B point estimates exactly (1.53 and 13.77; 1.55 and 7.11 without same-surname pairs), then refits Panel B with three nuisance designs:
- the published buyer- and seller-type controls;
- without the buyer-company control;
- with no party controls.

Intervals are parcel-bootstrap percentiles from the first 199 of the paper's common draws (seed 20260909). On the published row they match the paper's 999-draw interval to within 0.01. Output: `company_split_b199.json`. Section 4.2 of the paper reports the results.
