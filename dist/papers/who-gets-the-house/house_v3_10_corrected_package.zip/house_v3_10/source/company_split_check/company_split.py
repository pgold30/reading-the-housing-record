import sys, json, numpy as np, pandas as pd
from scipy import sparse
sys.path.insert(0, '/home/user/papers-vault/data_external/house_replication/code')
import analyze_repeat_sales as ars
from analyze_repeat_sales import DATA, time_design
from robust_estimators import wls, switches, multinomials
from related_party import flags
d = pd.read_csv(DATA / 'house_pairs_enriched.csv.gz', dtype={'bbl': str, 'borough': str, 'zipcode': str, 'cd': str, 'deed_a': str, 'deed_z': str})
G = int(d.cluster.max() + 1)
d = d[d.permit_free & ~d.lender_high & d.geo_linked].copy().reset_index(drop=True)
for s in 'az': d['date_' + s] = pd.to_datetime(d['date_' + s]).dt.date
d, _ = flags(d)
y = d.y.to_numpy(); Q = switches(d); cl = d.cluster.to_numpy()
cf, fc = Q[:, 0] == 1, Q[:, 1] == 1
rel = (d.related_a + d.related_z).to_numpy() > 0
cash_company = np.where(cf, d.buyer_entity_a.astype(bool), np.where(fc, d.buyer_entity_z.astype(bool), False))
T = time_design(d, 'zipcode')
def X_for(cols):
    if not cols: return T
    C = np.array([(d[c + '_z'] - d[c + '_a']).to_numpy() for c in cols]).T
    return sparse.hstack([T, sparse.csr_matrix(C)], format='csr')
ALL = [f'{r}_{k}' for r in ['buyer', 'seller'] for k in ['entity', 'trust', 'unknown']]
specs = {'published (buyer and seller types)': ALL,
         'without buyer company control': [c for c in ALL if c != 'buyer_entity'],
         'seller types only': [c for c in ALL if c.startswith('seller')],
         'no party controls': []}
def split(X, m, w):
    mm = m & (w > 0); gg = cash_company[mm]; c1, c2 = cf[mm], fc[mm]
    QQ = np.column_stack([c1 & gg, c1 & ~gg, c2 & gg, c2 & ~gg]).astype(float)
    b, _ = wls(X[mm], QQ, y[mm], w[mm])
    return 100 * .5 * (b[0] - b[2]), 100 * .5 * (b[1] - b[3])
B = int(sys.argv[1]) if len(sys.argv) > 1 else 0
W = [w[cl].astype(float) for w in multinomials(G, ars.SEED)][:B] if B else []
out = {}
for name, cols in specs.items():
    X = X_for(cols)
    for samp, m in [('all', np.ones(len(d), bool)), ('no_same_surname', ~rel)]:
        co, ot = split(X, m, np.ones(len(d)))
        r = {'company': round(co, 2), 'other': round(ot, 2), 'other_minus_company': round(ot - co, 2)}
        if B:
            dr = np.array([split(X, m, w) for w in W])
            r['ci_company'] = np.round(np.percentile(dr[:, 0], [2.5, 97.5]), 2).tolist()
            r['ci_other'] = np.round(np.percentile(dr[:, 1], [2.5, 97.5]), 2).tolist()
            r['ci_difference'] = np.round(np.percentile(dr[:, 1] - dr[:, 0], [2.5, 97.5]), 2).tolist()
        out[f'{name} | {samp}'] = r
print(json.dumps(out, indent=1))
