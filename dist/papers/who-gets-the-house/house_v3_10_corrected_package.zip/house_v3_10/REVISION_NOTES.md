# House correction, prepared 22 October 2026

The condominium unit-lot search now includes lots 1001–6999. The common-control condo comparison, robust estimates, surname-screen comparisons and illustrative relisting-loss calculations are updated. Analytic and bootstrap intervals remain distinct. The house sample, primary coefficients and 60 transfer-report readings are unchanged. Earlier source and PDFs are preserved. This package has not been uploaded or submitted.

Cold read, 22 October: corrected remaining data-section counts and replication boundaries; removed unreproduced peripheral cash-tax-base arithmetic and unsupported transfer of companion AI-agreement rates. Core estimates unchanged.
