# House 3.10 condominium correction patch

This supplements the existing House replication package. It leaves the house sample and house estimates unchanged. The corrected common borough-quarter condominium comparison uses 6,836 pairs. The analytical interval is [0.06, 1.61] log points; the separate percentile bootstrap interval is [0.05, 1.63].

## Reproduce offline

With Python 3.10+, numpy, pandas and scipy installed, run:

    python3 run_condo_correction.py

This refits the condominium OLS, Huber, growth-trimmed and surname-screened point estimates, calculates the analytic interval and checks all saved bootstrap intervals against the saved 999 draws. Add --bootstrap to refit those 999 draws in serial, which takes several minutes. The estimators in code/ are preserved copies from the existing replication package. No network or private party cache is needed for these estimates.

panel2.csv.gz is the corrected comparative input panel. condo_pairs_with_flags.csv.gz contains the derived pair-level analysis and fixed surname indicators. Neither absence nor presence of a surname flag establishes kinship. These flags are metadata screens, with unmeasured accuracy against operative documents. The patch reproduces estimates conditional on these flags; it does not independently recreate them from private names.

The expanded unit search follows the documented 1001–6999 range. Earlier panel inclusion rules and the house rows are preserved. New condominium endpoints use the same mortgage windows. Endpoint deeds require a unique document on the unit within 45 days and 0.5% of consideration: 33 ambiguous endpoints retain missing deed IDs. Earlier party extracts are retained, supplemented for newly required deeds. The correction report records the retrieval and reconstruction checks.

results/ and paper/generated/ supply corrected exhibit inputs. The unmodified house rows in comparison outputs are carried from the previous replication results. Source files for the corrected paper are in the sibling source/ directory. This corrected package accompanies the website working paper. It has not replaced any journal submission or Zenodo paper deposit.
