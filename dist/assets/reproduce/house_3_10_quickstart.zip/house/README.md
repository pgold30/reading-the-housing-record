# House 3.10: corrected condominium comparison

Requires Python 3.11+, numpy, pandas and scipy. Install the listed dependencies if needed with `python3 -m pip install -r requirements.txt`. From this folder run:

    python3 run.py

Expected: 6,836 condominium pairs and an OLS financed-minus-cash contrast near 0.83 log points; the analytic interval is about 0.06–1.61. `results/RESULTS.json` also reports the robust and surname-screened estimates. The original estimator and frozen pair input come from https://doi.org/10.5281/zenodo.23638520.

This actually refits condominium point estimates. It checks saved bootstrap quantiles without refitting 999 draws. It does not refit the primary house estimate, recreate private party-name flags, or resolve the 18 outstanding financing cases. The original complete archives and their input requirements remain linked in the release. Derived data and code: CC BY 4.0; credit Pablo Loschi.
