"""Refit the corrected condominium comparison accompanying House 3.10."""
from pathlib import Path
import argparse,hashlib,json,sys
ROOT=Path(__file__).resolve().parent
def start():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--output',type=Path,default=ROOT/'results')
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
 expected=json.loads((ROOT/'INPUT_SHA256.json').read_text())
 for rel,wanted in expected.items():
  with (ROOT/rel).open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
  if actual!=wanted:raise ValueError('Input hash mismatch: '+rel)
 return a.output

import subprocess,shutil
out=start()
run=subprocess.run([sys.executable,str(ROOT/'analysis/run_condo_correction.py')],capture_output=True,text=True)
(out/'run.log').write_text(run.stdout+run.stderr)
if run.returncode:raise RuntimeError('Estimator failed; see '+str(out/'run.log'))
result=json.loads((ROOT/'analysis/REPRODUCED.json').read_text())
result['point_log_points']={k:100*v for k,v in result['point'].items() if k!='huber_iterations'}
result['analytic_ci_log_points']=[100*v for v in result['analytic_joint_ci']]
result['units']='point and analytic_joint_ci are log units; *_log_points fields multiply them by 100.'
result['scope']='Fresh corrected-condominium point estimates and analytic interval; saved bootstrap quantiles checked, not refitted. No house headline refit or new financing validation.'
(out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
