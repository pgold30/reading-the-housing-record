"""Offline recomputation from corrected condominium pairs and fixed metadata flags."""
from pathlib import Path
import argparse,json,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))
from analyze_repeat_sales import design,estimate,SEED
from robust_estimators import fit_all,switches,years,multinomials
from related_party_extensions import contrast

def main():
 p=argparse.ArgumentParser();p.add_argument('--bootstrap',action='store_true',help='Refit all 999 parcel bootstrap draws, in serial.');a=p.parse_args()
 d=pd.read_csv(ROOT/'condo_pairs_with_flags.csv.gz',dtype={'bbl':str,'borough':str})
 for side in 'az':d['date_'+side]=pd.to_datetime(d['date_'+side]).dt.date
 for col in ['related_pair','related_strict_pair']:d[col]=d[col].astype(str).str.lower().eq('true').to_numpy()
 X=design(d);Q=switches(d);y=d.y.to_numpy();g=y/years(d);cl=d.cluster.to_numpy();G=int(cl.max()+1)
 rel=d.related_pair.to_numpy();strict=d.related_strict_pair.to_numpy()
 def fit(w):
  ans=fit_all(X,Q,y,g,w)
  ans['no_related']=contrast(X,Q,y,w,~rel)
  ans['no_related_strict']=contrast(X,Q,y,w,~strict)
  return ans
 point=fit(np.ones(len(d)));analytic=estimate(d,X,G)[0]
 expected=json.loads((ROOT/'results/HOUSE_CONDO_CORRECTION.json').read_text())
 assert len(d)==expected['pairs'] and int(rel.sum())==expected['flagged_pairs']
 for key,value in expected['point'].items():assert np.isclose(point[key],value,atol=1e-8),(key,point[key],value)
 saved=pd.read_csv(ROOT/'condo_bootstrap_corrected.csv.gz')
 for key,ci in expected['ci'].items():assert np.allclose(np.percentile(saved[key],[2.5,97.5]),ci)
 ans={'pairs':len(d),'point':point,'analytic_joint_ci':analytic['ci_joint'],'saved_bootstrap_ci_verified':True}
 if a.bootstrap:
  out=pd.DataFrame([fit(w[cl].astype(float)) for w in multinomials(G,SEED)])
  for key in expected['ci']:assert np.allclose(np.percentile(out[key],[2.5,97.5]),expected['ci'][key],atol=1e-7),key
  out.to_csv(ROOT/'bootstrap_rerun.csv.gz',index=False,compression='gzip');ans['fresh_bootstrap_verified']=999
 (ROOT/'REPRODUCED.json').write_text(json.dumps(ans,indent=2)+'\n');print(json.dumps(ans,indent=2))
if __name__=='__main__':main()
