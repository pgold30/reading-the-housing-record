"""Recompute the NJ comparison and block ranges from archived count inputs."""
from pathlib import Path
import argparse,hashlib,json,sys
ROOT=Path(__file__).resolve().parent
def start():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--output',type=Path,default=ROOT/'results')
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
 expected=json.loads((ROOT/'INPUT_SHA256.json').read_text())
 for rel,wanted in expected.items():
  with (ROOT/rel).open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
  if actual!=wanted:raise ValueError('Input hash mismatch: '+rel)
 return a.output

import importlib.util,numpy as np,pandas as pd
out=start()
spec=importlib.util.spec_from_file_location('nj',ROOT/'code/nj_bounded_checks.py');nj=importlib.util.module_from_spec(spec);spec.loader.exec_module(nj)
county=pd.read_csv(ROOT/'inputs/county_counts.csv');monthly=pd.read_csv(ROOT/'inputs/monthly_counts.csv')
expected=json.loads((ROOT/'inputs/RESULTS.json').read_text())['results'];old_draws=np.load(ROOT/'inputs/block_draws.npz');results={}
for label in expected:
 c=county[county.comparison.eq(label)];m=monthly[monthly.comparison.eq(label)]
 n0,k0,n1,k1=[int(c[x].sum()) for x in ['pre_n','pre_k','post_n','post_k']]
 raw=nj.decline(n0,k0,n1,k1)
 std=1-((c.pre_n/n0)*(c.post_k/c.post_n)).sum()/(k0/n0)
 loo=[nj.decline(n0-int(r.pre_n),k0-int(r.pre_k),n1-int(r.post_n),k1-int(r.post_k)) for r in c.itertuples()]
 rng=np.random.default_rng(nj.SEED);ranges={}
 months=[m[m.period.eq(period)].sort_values('month')[['n','exact']].to_numpy(dtype=np.int64) for period in ['pre','post']]
 for L in nj.LENGTHS:
  pre,post=[nj.blocks(a,L,rng) for a in months]
  valid=(pre[:,0]>0)&(pre[:,1]>0)&(post[:,0]>0)
  values=np.full(nj.B,np.nan);values[valid]=1-(post[valid,1]/post[valid,0])/(pre[valid,1]/pre[valid,0])
  if not np.allclose(values,old_draws[label+'_'+str(L)],equal_nan=True,rtol=0,atol=1e-14):raise ValueError('Block draws differ')
  ranges[str(L)]=np.quantile(values[np.isfinite(values)],[.025,.975]).tolist()
 if not np.isclose(raw,expected[label]['decline'],atol=1e-14):raise ValueError('Decline differs')
 if not np.isclose(std,expected[label]['county_standardized_decline'],atol=1e-14):raise ValueError('County standardization differs')
 if not np.allclose([min(loo),max(loo)],expected[label]['leave_one_county_out_range'],atol=1e-14):raise ValueError('Leave-one-county-out range differs')
 results[label]={'pre_window':n0,'pre_exact':k0,'post_window':n1,'post_exact':k1,'decline':raw,'county_standardized_decline':float(std),'leave_one_county_out_range':[min(loo),max(loo)],'block_range95':ranges}
result={'release':'Tax 3.3','results':results,'block_draws_recomputed':True,'draws_per_block_length':nj.B,'scope':'Refit from archived sufficient counts. No raw-sale re-extraction, New York estimator refit, fee-payment verification or causal interpretation.'}
(out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
