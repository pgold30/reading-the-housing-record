"""Pre-specified descriptive NJ composition and temporal-dependence checks.
No filing/payment, behavioral-mechanism or causal policy-effect validation.
"""
from pathlib import Path
import argparse,hashlib,json
import numpy as np
import pandas as pd
HERE=Path(__file__).resolve().parent
X=1_000_000; B=2999; SEED=20261023; LENGTHS=[3,6]

def fraction(n,k):
    return float(k/n) if n else None

def decline(n0,k0,n1,k1):
    return float(1-(k1/n1)/(k0/n0)) if n0>0 and k0>0 and n1>0 else None

def blocks(a,L,rng,B=B):
    n=len(a);starts=rng.integers(n,size=(B,(n+L-1)//L))
    ids=((starts[:,:,None]+np.arange(L))%n).reshape(B,-1)[:,:n]
    totals=a[ids].sum(axis=1)
    # Check vectorized aggregation against direct concatenation on the first draws.
    for b in range(min(5,B)):
        direct=np.concatenate([np.arange(s,s+L)%n for s in starts[b]])[:n]
        assert np.array_equal(direct,ids[b])
        assert np.array_equal(a[direct].sum(axis=0),totals[b])
    return totals

def main():
    parser=argparse.ArgumentParser();parser.add_argument('data',type=Path)
    parser.add_argument('--output',type=Path,default=HERE/'nj');a=parser.parse_args()
    out=a.output;out.mkdir(parents=True,exist_ok=True)
    d=pd.read_csv(a.data,usecols=['county','property_class','deed_date','sale_price'],dtype={'property_class':str},low_memory=False)
    d['dt']=pd.to_datetime(d.deed_date,errors='coerce')
    d=d[d.property_class.str.strip().eq('2')&d.sale_price.ge(100000)].copy()
    d['county']=d.county.str.strip().str.upper()
    assert d.county.notna().all()
    d['exact']=d.sale_price.eq(X).astype(int)
    pre_dates=('1999-01-01','2003-12-31')
    pm=d.dt.between(*pre_dates)
    wm=d.sale_price.ge(.9*X)&d.sale_price.lt(1.1*X)
    results={};county_rows=[];loo_rows=[];month_rows=[];draw_results={}
    for label,start in [('original_aug2004','2004-08-01'),('after_feb2005_amendment','2005-02-01')]:
        post_dates=(start,'2009-07-31');qm=d.dt.between(*post_dates)
        cc=sorted(d.loc[pm|qm,'county'].unique());assert len(cc)==21,cc
        pre=d.loc[pm&wm];post=d.loc[qm&wm]
        n0,k0=len(pre),int(pre.exact.sum());n1,k1=len(post),int(post.exact.sum())
        assert (n0,k0)==(4512,431)
        assert (n1,k1)==((11566,97) if label=='original_aug2004' else (10466,84))
        raw=decline(n0,k0,n1,k1)
        tab=pd.DataFrame(index=cc)
        for prefix,z in [('pre',pre),('post',post)]:
            tab[prefix+'_n']=z.groupby('county').size().reindex(cc,fill_value=0)
            tab[prefix+'_k']=z.groupby('county').exact.sum().reindex(cc,fill_value=0)
            tab[prefix+'_share']=tab[prefix+'_k']/tab[prefix+'_n'].replace(0,np.nan)
        tab['pre_weight']=tab.pre_n/n0
        fails=tab.index[(tab.pre_n>0)&(tab.post_n==0)].tolist()
        std=None if fails else float((tab.pre_weight*tab.post_share).sum())
        std_decline=None if std is None else float(1-std/(k0/n0))
        for c,row in tab.iterrows():
            county_rows.append({'comparison':label,'county':c,**row.to_dict()})
            loo_rows.append({'comparison':label,'excluded_county':c,'pre_n':n0-int(row.pre_n),'pre_exact':k0-int(row.pre_k),'post_n':n1-int(row.post_n),'post_exact':k1-int(row.post_k),'decline':decline(n0-int(row.pre_n),k0-int(row.pre_k),n1-int(row.post_n),k1-int(row.post_k))})
        months=[]
        for period,z,dates in [('pre',pre,pre_dates),('post',post,post_dates)]:
            calendar=pd.period_range(dates[0],dates[1],freq='M')
            g=z.groupby(z.dt.dt.to_period('M')).agg(n=('exact','size'),k=('exact','sum')).reindex(calendar,fill_value=0)
            assert int(g.n.sum())==len(z) and int(g.k.sum())==int(z.exact.sum())
            for dt,row in g.iterrows():month_rows.append({'comparison':label,'period':period,'month':str(dt),'n':int(row.n),'exact':int(row.k)})
            months.append(g[['n','k']].to_numpy(dtype=np.int64))
        rng=np.random.default_rng(SEED);bs={}
        for L in LENGTHS:
            pre_b,post_b=[blocks(z,L,rng) for z in months]
            valid=(pre_b[:,0]>0)&(pre_b[:,1]>0)&(post_b[:,0]>0)
            vals=np.full(B,np.nan)
            vals[valid]=1-(post_b[valid,1]/post_b[valid,0])/(pre_b[valid,1]/pre_b[valid,0])
            finite=vals[np.isfinite(vals)]
            bs[str(L)]={'block_length_months':L,'draws':B,'invalid_draws':int(B-len(finite)),'median':float(np.median(finite)) if len(finite) else None,'range95':np.quantile(finite,[.025,.975]).tolist() if len(finite) else None,'scope':'Descriptive circular monthly block-resampling range; not a causal policy-effect confidence interval.'}
            draw_results[label+'_'+str(L)]=vals
        lo=[x['decline'] for x in loo_rows if x['comparison']==label]
        results[label]={'pre_dates':pre_dates,'post_dates':post_dates,'pre_window':n0,'pre_exact':k0,'post_window':n1,'post_exact':k1,'pre_share':k0/n0,'post_share':k1/n1,'decline':raw,'county_count':len(cc),'county_standardized_post_share':std,'county_standardized_decline':std_decline,'post_share_raw_minus_standardized_pp':None if std is None else float(100*((k1/n1)-std)),'decline_raw_minus_standardized_pp':None if std is None else float(100*(raw-std_decline)),'unsupported_post_counties':fails,'leave_one_county_out_range':[min(lo),max(lo)],'calendar_months':[len(x) for x in months],'monthly_block_resampling':bs}
    pd.DataFrame(county_rows).to_csv(out/'county_counts.csv',index=False)
    pd.DataFrame(loo_rows).to_csv(out/'leave_one_county_out.csv',index=False)
    pd.DataFrame(month_rows).to_csv(out/'monthly_counts.csv',index=False)
    np.savez_compressed(out/'block_draws.npz',**draw_results)
    result={'parameters':{'threshold':X,'window':'[0.9X,1.1X)','property_class':'2','minimum_sale_price':100000,'seed_per_comparison':SEED,'draws_per_block_length':B,'block_lengths_months':LENGTHS},'input_path':str(a.data.resolve()),'input_sha256':hashlib.sha256(a.data.read_bytes()).hexdigest(),'executed_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'results':results,'limitations':['County weighting adjusts only the observed county mix, not composition within counties.','Resampling months together retains common county movements and dependence within selected blocks.','Circular blocks assume comparable dependence within each period; long trends, regime changes and common historical shocks are not identified away.','Distant repeat-parcel dependence is not fully modeled.','No filed deeds, affidavits or fee payments are verified; no individual transaction shifting or tax understanding is observed.']}
    (out/'RESULTS.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps(results,indent=2))
if __name__=='__main__':main()
