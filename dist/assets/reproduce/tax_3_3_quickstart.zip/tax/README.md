# Tax 3.3: New Jersey robustness example

Requires Python 3.11+, numpy and pandas. Install with `python3 -m pip install -r requirements.txt` if needed. From this folder run:

    python3 run.py

Expected for the period starting February 2005: an exact-million share decline of about 91.6%, 91.2% after county standardization, and 90.6–92.2% when one county is omitted. The three-/six-month block ranges are about 88.1–94.4% and 88.2–94.5%. Results go to `results/RESULTS.json`.

The monthly and county counts, original resampling function and saved draw reference are from https://doi.org/10.5281/zenodo.23638571. The command recomputes the estimates and all 2,999 draws per block length, and checks the draw arrays. It does not re-extract the underlying sales or refit the NYC threshold analysis. These are descriptive dependence/composition sensitivities, not causal confidence intervals or verification of actual fee payments. Data and code: CC BY 4.0, credit Pablo Loschi; underlying source records retain their terms.
