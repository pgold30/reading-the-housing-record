# Tax 3.3 corrected replication package

This tree supplies the corrected comparative panel and the analysis inputs, scripts and outputs used to build the two corrected PDFs. It supplements the existing full replication deposit. The raw price sample and core reform estimates are unchanged.

The comparative panel in 2_tables/panel2.csv.gz uses the original house rows and the corrected single-parcel condominium unit search through lot 6999. Existing financing flags are retained on unchanged sale keys. data/linked_fields.csv.gz and data/condo_loans.csv.gz in 4_full_2019_schedule use the published dataset 1.2.0 (https://doi.org/10.5281/zenodo.23557585). The latter allows guarded condominium links for loan lookup; this broader lookup does not expand the comparative panel beyond its documented single-parcel sample. The main price estimators use the raw sales file rather than this panel.

Python dependencies: numpy, pandas, scipy; matplotlib for figures. Run from 4_full_2019_schedule/code:

    python3 revenue_neutral.py
    python3 cost_and_sponsors.py
    python3 market_splits.py
    python3 loan_notch.py
    python3 ltv_charm.py
    python3 loan_notch_grid.py
    python3 loan_notch_checks.py
    python3 moved_share_checks.py
    python3 did_round_placebos.py
    python3 benchmarks_v29.py
    python3 check_text_against_outputs.py ../../../manuscript_aejpol.tex ../../../supplemental_appendix.tex

The check reads saved analysis outputs and verifies 118 numeric/text gates. Running the scripts overwrites their output files; retain the saved snapshot if comparing results.

The whole-source lot correction was checked before the downstream rerun. Dataset flags remain screens, not verified kinship or beneficial ownership. No operative instrument accuracy rate is claimed. The 33 strict-surname changes from recomputing the common-name list are recorded in the dataset correction notes. The records with conflicting block fields are not automatically relinked.

The gross annual mortgage recording charge rises from $244.3 million to $247.8 million. Observed condominium loans rise from 47,702 to 49,709; the rounded mean condo charge remains 1.28% of recorded price. Table/figure labels and the distinction between gross costing and revenue remain as in the edited manuscript.

This package accompanies the website working paper. No journal replacement or new Zenodo paper deposit has been made.
