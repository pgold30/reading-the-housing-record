# Fixed before calculation, 9 October 2026

Compare 2016–2018, 2020–2022 and 2023–2025; omit 2019. Count sales above $300,000 in symmetric 5% and 10% windows at $1m, $1.5m, $2m, $2.5m, $3m and $5m. Retain below, exact and above separately. Standardize property type and company seller separately to pre-period weights, retaining missing categories. No causal counterfactual, density fit or inferential p-value is constructed.

From the package root run:

```sh
python 5_transaction_accounting/transaction_accounting.py --data 4_full_2019_schedule/data/linked_fields.csv.gz
```

Outputs are written beside the script. The script needs Python 3.10 or later, standard library only.
