# Equal-period transaction counts and composition

The new accounting strengthens the descriptive threshold-shifting result. It adds no identified estimate of transactions prevented by the tax. It compares 2016–2018, 2020–2022 and 2023–2025, each three years, omitting 2019. Counts cover the same all-residential NYC price universe as the existing threshold analysis, including co-operatives and Staten Island. The mortgage-charge application has its separate four-borough universe.

Within fixed windows from 95% to 105% of each threshold, the below-threshold share changes as follows:

| Threshold | 2016–18 sales | 2020–22 sales | 2023–25 sales | Below share 2016–18 | Below share 2020–22 | Below share 2023–25 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| $1m unchanged tax | 6,694 | 8,943 | 8,231 | 86.5% | 89.1% | 87.8% |
| $1.5m untaxed reference | 3,257 | 4,457 | 3,992 | 49.0% | 50.1% | 47.6% |
| $2m new notch | 1,846 | 2,588 | 2,553 | 55.2% | 67.7% | 69.1% |
| $2.5m untaxed reference | 1,582 | 1,965 | 2,032 | 50.2% | 48.2% | 48.6% |
| $3m new notch | 1,164 | 1,458 | 1,454 | 52.7% | 63.4% | 68.0% |
| $5m new notch | 537 | 794 | 686 | 50.1% | 61.2% | 66.5% |

The increases at the new notches are 10.8–16.4 percentage points. Standardizing the post-period shares to the pre-period property-type weights gives 10.8–16.1 points; the largest property-composition component is 0.81 points in absolute value. Standardizing separately by company-seller status, retaining missing flags as a category, gives 10.8–16.5 points. This does not adjust for unobserved composition within these categories. Company flags are absent for roughly 35–49% of observations in these new-notch windows, depending on period and threshold. Their missingness includes transactions for which no deed linkage is attempted, so missing is not a non-company seller.

In the wider 90%–110% windows, raw below-share changes at the new notches are 4.5–12.1 points, and those standardized by property type are 4.4–11.4. The main-window result is therefore partly sensitive to how local the accounting is, as expected when concentration is close to the threshold. Every pre-period category has support in each compared post period in both standardizations.

## What this adds

The existing density and mass-balance tests already compare missing and excess mass, while the event study dates the changes and grouped tests compare houses, condos and company sellers. The additional contribution is transparent raw-count accounting over equal periods and a numerical decomposition of the below-share change. It shows that the broad observed property mix does not account for that shift. It also prevents an incorrect volume claim: total counts in the threshold windows rise after reform, as do counts around the untaxed references. Counts across all prices above $300,000 are 133,844, 144,720 and 120,713 over the three periods. Window shares of that total also rise at the untaxed references. Neither raw volume nor this normalization supplies a credible no-reform counterfactual.

Pandemic conditions, price growth and changing market composition remain possible influences. No new causal effect, incidence estimate, optimal-tax result or estimate of foregone sales is claimed. The existing headline estimates remain unchanged.

## Reproduction

Run `transaction_accounting.py --data <linked_fields.csv.gz>`. `counts.csv` records all 36 threshold-period-window cells; `composition.csv` preserves category denominators and missingness; `standardized.csv` records the two standardizations; `manifest.json` fixes the input hash and accounting checks. All thresholds and both window widths specified in the plan are reported.
