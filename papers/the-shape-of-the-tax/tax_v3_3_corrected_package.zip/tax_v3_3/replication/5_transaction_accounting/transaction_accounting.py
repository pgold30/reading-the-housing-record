"""Descriptive fixed-window accounting, specified in ../PLAN.md before execution.

Run with --data path/to/linked_fields.csv.gz; outputs beside this script.
No density fit, causal counterfactual or inferential p-value is constructed.
"""
from pathlib import Path
import argparse, csv, gzip, hashlib, json
from collections import Counter

p = argparse.ArgumentParser()
p.add_argument('--data', type=Path, required=True)
a = p.parse_args()
out = Path(__file__).resolve().parent
periods = [('2016–2018', 2016, 2018), ('2020–2022', 2020, 2022), ('2023–2025', 2023, 2025)]
thresholds = [1000000, 1500000, 2000000, 2500000, 3000000, 5000000]
cells = {(w,x,t): [] for w in [.05,.10] for x in thresholds for t,_,_ in periods}
totals = Counter()
with gzip.open(a.data, 'rt') as f:
    for r in csv.DictReader(f):
        price = float(r['sale_price'] or 0)
        if price <= 300000: continue  # same lower cutoff as threshold_extension.py
        year = int(r['sale_date'][:4])
        for t, lo, hi in periods:
            if not lo <= year <= hi: continue
            totals[t] += 1
            for w in [.05,.10]:
                for x in thresholds:
                    if x*(1-w) <= price < x*(1+w):
                        cells[w,x,t].append((price,r))
rows = []
composition = []
for (w,x,t), rr in cells.items():
    n = len(rr)
    below = sum(price < x for price,r in rr)
    exact = sum(price == x for price,r in rr)
    above = n-below-exact
    rows.append(dict(window_fraction=w,threshold=x,period=t,n=n,below=below,exact=exact,above=above,
                     below_share=below/n if n else None,exact_share=exact/n if n else None,
                     above_share=above/n if n else None,all_sales_above_300k=totals[t],
                     window_share_all_sales=n/totals[t]))
    for side in ['all','below','exact','above']:
        subset = [r for price,r in rr if side=='all' or (side=='below' and price<x) or (side=='exact' and price==x) or (side=='above' and price>x)]
        for field in ['property_group','borough','grantor_company','grantee_company','deed_event','legal_rule_amount']:
            c = Counter(r[field] if r[field] != '' else 'MISSING' for r in subset)
            for v,k in sorted(c.items()):
                composition.append(dict(window_fraction=w,threshold=x,period=t,side=side,field=field,
                                        category=v,count=k,denominator=len(subset),share=k/len(subset)))
for name, records in [('counts.csv',rows),('composition.csv',composition)]:
    with (out/name).open('w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(records[0]));wr.writeheader();wr.writerows(records)
# Standardize to pre-period composition separately for property group and seller category.
# Missing seller flags remain a category. These are descriptive standardizations.
standardized = []
for w in [.05,.10]:
    for x in thresholds:
        pre = cells[w,x,periods[0][0]]
        for field in ['property_group','grantor_company']:
            cats = sorted({r[field] or 'MISSING' for _,r in pre})
            pre_count = Counter(r[field] or 'MISSING' for _,r in pre)
            pre_below = sum(price<x for price,_ in pre)/len(pre)
            for t,_,_ in periods[1:]:
                post = cells[w,x,t]
                rates = {}
                for cat in cats:
                    sub = [(price,r) for price,r in post if (r[field] or 'MISSING')==cat]
                    rates[cat] = sum(price<x for price,r in sub)/len(sub) if sub else None
                unsupported = sum(pre_count[k] for k in cats if rates[k] is None)/len(pre)
                std = sum(pre_count[k]/len(pre)*rates[k] for k in cats) if unsupported==0 else None
                raw = sum(price<x for price,_ in post)/len(post)
                standardized.append(dict(window_fraction=w,threshold=x,period=t,standardization=field,
                    pre_below_share=pre_below,post_below_share=raw,standardized_post_below_share=std,
                    raw_change_pp=100*(raw-pre_below),within_category_change_pp=100*(std-pre_below) if std is not None else None,
                    composition_component_pp=100*(raw-std) if std is not None else None,unsupported_pre_weight=unsupported))
with (out/'standardized.csv').open('w',newline='') as f:
    wr=csv.DictWriter(f,fieldnames=list(standardized[0]));wr.writeheader();wr.writerows(standardized)
checks = dict(nonnegative_counts=all(r['n']==r['below']+r['exact']+r['above'] for r in rows),
              equal_period_length=all(hi-lo+1==3 for _,lo,hi in periods),number_cells=len(rows),
              main_windows_nested=all(len(cells[.05,x,t])<=len(cells[.10,x,t]) for x in thresholds for t,_,_ in periods))
assert all(checks[k] for k in ['nonnegative_counts','equal_period_length','main_windows_nested'])
(out/'manifest.json').write_text(json.dumps(dict(input=str(a.data),sha256=hashlib.sha256(a.data.read_bytes()).hexdigest(),
    thresholds=thresholds,periods=periods,windows=[.05,.10],totals=dict(totals),checks=checks),indent=2)+'\n')
print(json.dumps(dict(totals=dict(totals),checks=checks)))
