"""Build the v1.1 manuscript tables and Figure 6 from the analysis JSON outputs."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]; OUT = ROOT / "output"
E = json.loads((OUT / "threshold_extension.json").read_text())
V = json.loads((OUT / "revenue_neutral.json").read_text())


def num(n):
    return f"{n:,.0f}".replace(",", "{,}")


def money(x):
    return r"\$" + num(x)


def sgn(v, d=3):
    return (f"$+{v:.{d}f}$" if v >= 0 else f"$-{abs(v):.{d}f}$")


def ci(lo, hi, d=3):
    return f"[{sgn(lo, d)}, {sgn(hi, d)}]"


TREAT = [2_000_000, 3_000_000, 5_000_000, 10_000_000, 15_000_000, 20_000_000, 25_000_000]
PLAC = [4_000_000, 7_000_000, 8_000_000]  # v1.12: $6M and $12M dropped; their +/-0.2X windows contain the $5M and $10M thresholds
rows = []
for X in TREAT + PLAC:
    e = E[str(X)]
    thin = e["KW_window_n"][0] < 1000
    if X in PLAC:
        jump = "none"
    else:
        jump = f"{e['buyer_pp']:.2f} pt / {money(e['buyer_dollars'])}" + (r"$^{a}$" if e["seller_pp"] else "")
    kw = f"{sgn(e['KW_diff'])} {ci(*e['KW_ci'])}"
    R = f"{sgn(e['R_logdiff'])} {ci(e['R_logdiff'] - 1.96 * e['R_se'], e['R_logdiff'] + 1.96 * e['R_se'])}"
    ch = e["charm_counts_pre_post"]
    lab = money(X) + (r"$^{b}$" if thin else "")
    rows.append((X, thin, f"{lab} & {jump} & {num(e['KW_window_n'][0])}/{num(e['KW_window_n'][1])} & {kw} & {R} & {ch[0]} $\\to$ {ch[2]} \\\\"))
body = [r"\multicolumn{6}{l}{\textit{Panel A. Thresholds created by the 2019 reform}}\\ \midrule"]
for X, thin, line in rows:
    if X == 10_000_000:
        body.append(r"\addlinespace")
    if X == 4_000_000:
        body.append(r"\midrule \multicolumn{6}{l}{\textit{Panel B. Round-number placebos, never taxed}}\\ \midrule")
    body.append(line)
table = r"""\begin{table}[htbp]
\centering
\caption{The full 2019 schedule: every threshold, before and after the reform}
\label{tab:fullschedule}
\singlespacing\footnotesize
\setlength{\tabcolsep}{3pt}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lccccc}
\toprule
Threshold & Buyer's jump & Sales in window & Bunching, post $-$ pre & $\Delta\log R$, no counterfactual & Sales at $X-1$ \\
 & (rate / dollars) & pre/post & [95\% CI] & [95\% CI] & pre $\to$ post \\
\midrule
""" + "\n".join(body) + r"""
\bottomrule
\end{tabular}}
\notes{\textit{Notes.} Pre is January 2016 to March 2019; post is January 2020 to December 2025. Windows scale with the threshold so one design applies across the schedule, and at \$2{,}000{,}000 every window equals the one used in Table~\ref{tab:bunching}. Bunching is the Kleven--Waseem share of counterfactual mass missing above $X$ (window $\pm0.2X$, bins of $0.005X$ rounded down to \$10{,}000, \$25{,}000, \$50{,}000 or \$100{,}000, exclusion band $(-0.025X, +0.05X)$, degree-five polynomial with round-number indicators), post minus pre, with bootstrap percentile intervals. $R$ is sales in $[X, 1.05X)$ over sales in $[0.925X, 0.975X)$; its log change has a Poisson interval. $^{a}$At \$3{,}000{,}000 the seller's base rate also rises 0.25 points. $^{b}$Fewer than 1{,}000 pre-reform sales in the estimation window. On samples this small the estimator returns large, individually significant values of both signs at treated thresholds (\$15{,}000{,}000 and \$20{,}000{,}000), so no conclusion is drawn from these rows. The price sample extends above the \$6{,}000{,}000 cap of Table~\ref{tab:bunching}; its \$300{,}000--\$6{,}000{,}000 slice reproduces that table's 431{,}471 sales exactly.}
\end{table}
"""
(OUT / "tab_fullschedule.tex").write_text(table)

# Revenue table
r = V["revenue_per_year"]; s = V["sample"]; S = V["schedules"]
M = lambda x: f"{x/1e6:,.1f}"
house_obs = r["borrower_mrt_observed_house_loans_only"]; condo_obs = r["borrower_mrt_observed_condo_loans"]
house_imp = r["borrower_mrt_imputed_houses"]; condo_imp = r["borrower_mrt_imputed_condos"]; tot = r["borrower_mrt_with_imputation"]
rev = r"""\begin{table}[htbp]
\centering
\caption{The residential purchase-money carve-out, costed, and three revenue-neutral replacements}
\label{tab:revenue}
\singlespacing\footnotesize
\setlength{\tabcolsep}{3.5pt}
\begin{tabular}{lrrrr}
\toprule
\multicolumn{5}{l}{\textit{Panel A. Borrower-borne tax on purchase money, \$ million a year}}\\
\midrule
Houses, loan amount observed (""" + f"{s['financed_house_loan_observed']:,}".replace(",", "{,}") + r""" loans) & """ + M(house_obs) + r""" &&& \\
Houses, loan amount imputed (""" + f"{s['financed_house_imputed']:,}".replace(",", "{,}") + r""") & """ + M(house_imp) + r""" &&& \\
Condominiums, loan amount observed (""" + f"{s['financed_condo_loan_observed']:,}".replace(",", "{,}") + r""" loans) & """ + M(condo_obs) + r""" &&& \\
Condominiums, loan amount imputed (""" + f"{s['financed_condo_imputed']:,}".replace(",", "{,}") + r""") & """ + M(condo_imp) + r""" &&& \\
\textbf{Total} & \textbf{""" + M(tot) + r"""} &&& \\
\quad of which the \S253(2) MTA component & """ + M(r["mta_253_2_component_with_imputation"]) + r""" &&& \\
\midrule
\multicolumn{5}{l}{\textit{Panel B. Smooth schedules on every purchase that raise the same revenue}}\\
\midrule
Schedule & Rate & Financed buyers & \multicolumn{2}{c}{Mean change per purchase} \\
 & & paying less & Financed & Cash \\
\midrule
"""
names = {"A_flat": r"Flat, on the whole price", "B_above_500k": r"On price above \$500{,}000",
         "C_two_bracket": r"Two brackets, doubling at \$2{,}000{,}000"}
for k, lab in names.items():
    x = S[k]
    rev += f"{lab} & {x['tau_percent']:.2f}\\% & {100*x['financed_share_paying_less']:.1f}\\% & $-${money(abs(x['mean_net_change']['financed']))} & $+${money(x['mean_net_change']['cash'])} \\\\\n"
rev += r"""\bottomrule
\end{tabular}
\notes{\textit{Notes.} Merged house and condominium panel: """ + f"{s['purchases']:,}".replace(",", "{,}") + r""" purchases between \$300{,}000 and \$6{,}000{,}000 in the four boroughs ACRIS covers, of which """ + f"{s['financed']:,}".replace(",", "{,}") + r""" financed. Staten Island sales, whose deeds and mortgages ACRIS does not record, are excluded. The recording tax is computed on each observed loan at its own size (1.80\% below \$500{,}000, 1.925\% at or above). Condominium loan amounts come from the linked dataset, matched to the panel on unit lot, sale date and price; financed purchases without a usable loan amount carry the observed mean for their property type and price band. The two-bracket schedule charges the stated rate on price between \$500{,}000 and \$2{,}000{,}000 and twice it above. Replacement rates are solved so that each schedule raises Panel~A's total from the same purchases. All three are continuous in price: marginal rates change at the breakpoints, and total liability does not jump. Figures are static: they hold transactions fixed and assign statutory incidence, so they are the size of the swap, not a forecast of its revenue.}
\end{table}
"""
(OUT / "tab_revenue.tex").write_text(rev)

# Figure 6
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
fig, ax = plt.subplots(figsize=(7.2, 3.4))
for X in TREAT + PLAC:
    e = E[str(X)]; thin = e["KW_window_n"][0] < 1000; placebo = X in PLAC
    lo, hi = e["KW_ci"]; y = e["KW_diff"]; x = X / 1e6
    color = "#8a8a8a" if placebo else "#1e5a78"
    ax.errorbar([x], [y], yerr=[[y - lo], [hi - y]], fmt="s" if placebo else "o", ms=5, capsize=2, color=color,
                mfc="white" if thin else color, alpha=0.45 if thin else 1)
    if not placebo and not thin:
        ax.annotate(f"buyer +{e['buyer_pp']:.2f} pt\n(${e['buyer_dollars']:,.0f})", (x, hi), textcoords="offset points", xytext=(0, 5), ha="center", fontsize=7)
ax.axhline(0, color="k", lw=0.6); ax.set_xscale("log")
ax.set_xticks([2, 3, 4, 5, 6, 7, 8, 10, 12, 15, 20, 25]); ax.set_xticklabels(["2", "3", "4", "5", "6", "7", "8", "10", "12", "15", "20", "25"])
ax.set_xlabel("Threshold ($ million, log scale)"); ax.set_ylabel("Bunching, post minus pre")
ax.plot([], [], "o", color="#1e5a78", label="2019 threshold"); ax.plot([], [], "s", color="#8a8a8a", label="never-taxed placebo")
ax.plot([], [], "o", mfc="white", color="#1e5a78", alpha=.5, label="too few sales (<1,000 pre)")
ax.legend(frameon=False, fontsize=7, loc="lower left"); fig.tight_layout()
fig.savefig(OUT / "Figure_6.pdf"); fig.savefig(OUT / "Figure_6.png", dpi=160)
print("built tab_fullschedule.tex, tab_revenue.tex, Figure_6")
