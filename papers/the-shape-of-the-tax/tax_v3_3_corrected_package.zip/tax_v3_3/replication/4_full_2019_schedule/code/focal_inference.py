"""v2.0: inference for the round-price margin, a bin-count difference-in-differences,
an awareness estimate, avoided-tax variants and a loan-amount check.

All on one row per deed (deeds.py); every row of the sales file as robustness.

1. Share of round-price sales that moved, m(X) = 1 - s_post/s_pre, where s is
   the share of sales in [0.9X, 1.1X) recorded at exactly X, for X = $2M, $3M,
   $5M; bootstrap intervals and a Wald test of equality. A placebo-adjusted
   version divides s_post/s_pre by the same ratio averaged over the never-taxed
   $100,000 multiples whose [0.9X, 1.1X) window holds no threshold.
2. Awareness beyond the round price. A buyer who noticed the notch never
   records a price in the dominated range (X, X + D], D = T/(1+t). The share of
   such sales that disappeared, 1 - s_post/s_pre for sales in (X, X + D]
   (excluding X), is a second estimate of the share of transactions that
   responded; compared with m(X).
3. Bin-count difference-in-differences. Counts in six zones around each price
   point ([0.9X, 0.95X), [0.95X, X-5,000), [X-5,000, X), exactly X, (X, 1.05X),
   [1.05X, 1.1X)) for the three new thresholds, the always-taxed $1M threshold
   and the never-taxed $100,000 multiples above. Poisson with price point x
   period, price point x zone and zone x period effects and treated x post
   effects for the four inner zones (outer zones the reference). 95% intervals
   from a block bootstrap over calendar months. Variants: by threshold, control
   only, placebos only, all rows.
4. Placebo permutation. Each never-taxed $100,000 multiple in turn is treated as
   if it had been taxed, against the control and the other placebos; the
   treated estimates are ranked within the 24 placebo estimates.
5. Year by year. The same model with year effects and treated x year effects,
   each year reported relative to the 2016-2018 mean; 2019, the transition
   year, is shown but not used.
6. Avoided tax under alternative counts: (a) the excess in (0.975X, X) of
   cost_and_sponsors.json; (b) the sales lost at and above X counted directly
   (focal_robustness.json); (c) (a) net of the control's excess; (d) (a) on
   every row.
7. Loan amounts of financed purchases recorded just below a threshold: the share
   whose loan is a round fraction (50%, 55%, ..., 95%) of X, against the share
   whose loan is such a fraction of the recorded price only.
Writes output/focal_inference.json.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd
import statsmodels.api as sm
import importlib.util as _ilu

ROOT = Path(__file__).resolve().parents[1]
_spec = _ilu.spec_from_file_location("deeds", Path(__file__).resolve().parent / "deeds.py")
deeds = _ilu.module_from_spec(_spec); _spec.loader.exec_module(deeds)
rng = np.random.default_rng(20261013)
R = 1000
POST_YEARS = 6.0
NEW = [2_000_000, 3_000_000, 5_000_000]
THRESHOLDS = [500_000, 1_000_000, 2_000_000, 3_000_000, 5_000_000, 10_000_000]
PLACEBO100 = [x for x in range(1_200_000, 4_900_001, 100_000)
              if x not in THRESHOLDS and not any(0.9 * x <= t < 1.1 * x for t in THRESHOLDS)]
TAXES = {2_000_000: (5_000, 0.03075), 3_000_000: (15_000, 0.03575), 5_000_000: (37_500, 0.04325)}  # jump, total rate just above X


def load(all_rows):
    rows = deeds.linked_rows(all_rows=all_rows)
    p = np.array([float(r["sale_price"] or 0) for r in rows]); d = np.array([r["sale_date"][:10] for r in rows])
    k = p > 300_000
    return p[k], d[k]


price, date = load(False)
aprice, adate = load(True)
PRE, POST = date < "2019-04-01", date >= "2020-01-01"
out = {"placebos_100k": PLACEBO100}
win = lambda p, X: p[(p >= 0.9 * X) & (p < 1.1 * X)]
ci = lambda v: np.percentile(v, [2.5, 97.5]).tolist()


# 1-2. Moved share at X, and the disappearing share in the dominated range
def ratio_at(a, b, X, lo=None, hi=None):
    if lo is None:
        return (b == X).mean() / (a == X).mean()
    return ((b > lo) & (b <= hi)).mean() / ((a > lo) & (a <= hi)).mean()


def shares(Wd):
    """Wd: price point -> (pre window, post window)."""
    res = {}
    for X in NEW:
        T_, t = TAXES[X]; Dr = T_ / (1 + t)
        res[X] = (1 - ratio_at(*Wd[X], X), 1 - ratio_at(*Wd[X], X, X, X + Dr))
    # placebo benchmark: post/pre ratio of the pooled share across all placebo windows
    pa = sum((Wd[Y][0] == Y).sum() for Y in PLACEBO100) / sum(len(Wd[Y][0]) for Y in PLACEBO100)
    pb = sum((Wd[Y][1] == Y).sum() for Y in PLACEBO100) / sum(len(Wd[Y][1]) for Y in PLACEBO100)
    pl = pb / pa
    pld = {}
    for X in NEW:
        f = TAXES[X][0] / (1 + TAXES[X][1]) / X
        ca = sum(((Wd[Y][0] > Y) & (Wd[Y][0] <= Y * (1 + f))).sum() for Y in PLACEBO100) / sum(len(Wd[Y][0]) for Y in PLACEBO100)
        cb = sum(((Wd[Y][1] > Y) & (Wd[Y][1] <= Y * (1 + f))).sum() for Y in PLACEBO100) / sum(len(Wd[Y][1]) for Y in PLACEBO100)
        pld[X] = cb / ca
    return res, pl, pld


pre, post = price[PRE], price[POST]
W = {X: (win(pre, X), win(post, X)) for X in NEW + PLACEBO100}
pt, pl, pld = shares(W)
D = []
for _ in range(R):
    Wb = {X: (rng.choice(a, len(a)), rng.choice(b, len(b))) for X, (a, b) in W.items()}
    r_, pl_, pld_ = shares(Wb)
    D.append([r_[X][0] for X in NEW] + [1 - (1 - r_[X][0]) / pl_ for X in NEW] + [r_[X][1] for X in NEW] + [1 - (1 - r_[X][1]) / pld_[X] for X in NEW])
D = np.array(D)
ms = {"placebo_spike_ratio_post_over_pre": float(pl)}
for i, X in enumerate(NEW):
    ms[str(X)] = {"moved": pt[X][0], "moved_ci": ci(D[:, i]), "moved_placebo_adjusted": 1 - (1 - pt[X][0]) / pl, "moved_placebo_adjusted_ci": ci(D[:, 3 + i]),
                  "dominated_range_dollars": TAXES[X][0] / (1 + TAXES[X][1]),
                  "dominated_gone": pt[X][1], "dominated_gone_ci": ci(D[:, 6 + i]),
                  "dominated_gone_placebo_adjusted": 1 - (1 - pt[X][1]) / pld[X], "dominated_gone_placebo_adjusted_ci": ci(D[:, 9 + i])}
v = np.array([pt[X][0] for X in NEW]); Cm = np.array([[1, -1, 0], [0, 1, -1]])
V = Cm @ np.cov(D[:, :3].T) @ Cm.T; Wd = float((Cm @ v) @ np.linalg.solve(V, Cm @ v))
ms["equal_moved_shares"] = {"W": Wd, "df": 2, "p": float(np.exp(-Wd / 2))}
pooled = np.array([pt[X][0] for X in NEW]).mean(); pooled_d = np.array([pt[X][1] for X in NEW]).mean()
ms["pooled"] = {"moved": float(pooled), "moved_ci": ci(D[:, :3].mean(1)), "dominated_gone": float(pooled_d), "dominated_gone_ci": ci(D[:, 6:9].mean(1)),
                "difference": float(pooled - pooled_d), "difference_ci": ci(D[:, :3].mean(1) - D[:, 6:9].mean(1))}
out["moved_share"] = ms
print(json.dumps(ms, indent=1)[:1500])

# 3-5. Bin-count difference-in-differences
ZONES = ["z1_far_below", "z2_below", "z3_just_below", "z4_at_X", "z5_above", "z6_far_above"]
PTS = NEW + [1_000_000] + PLACEBO100


def zone(p, X):
    z = np.full(len(p), -1)
    z[(p >= 0.9 * X) & (p < 0.95 * X)] = 0
    z[(p >= 0.95 * X) & (p < X - 5_000)] = 1
    z[(p >= X - 5_000) & (p < X)] = 2
    z[p == X] = 3
    z[(p > X) & (p < 1.05 * X)] = 4
    z[(p >= 1.05 * X) & (p < 1.1 * X)] = 5
    return z


def monthly_counts(p, d):
    month = pd.Series(d).str[:7].to_numpy()
    months = np.array(sorted(set(month)))
    idx = {m_: i_ for i_, m_ in enumerate(months)}
    A = np.zeros((len(PTS), len(months), 6))
    mi = np.array([idx[m_] for m_ in month])
    for a_, X in enumerate(PTS):
        z = zone(p, X); sel = z >= 0
        np.add.at(A, (a_, mi[sel], z[sel]), 1)
    return A, months


def fit(T, pts_used, treated, ref_period, per_threshold=False):
    """Poisson on cells T[point, period, zone]; treated x period effects for periods != ref_period."""
    n_per = T.shape[1]
    rows_ = [(a_, per, z, T[a_, per, z]) for a_ in pts_used for per in range(n_per) for z in range(6)]
    d = pd.DataFrame(rows_, columns=["pt", "per", "z", "n"])
    # full rank: point x period effects; point x zone and zone x period effects for zones 1-5 only
    # (zone 0 is the reference), zone x period dropped in the reference period
    X_ = [pd.get_dummies(d.pt.astype(str) + "_" + d.per.astype(str)).astype(float)]
    for z in range(1, 6):
        X_.append(pd.get_dummies(d.pt.astype(str) + f"_z{z}").astype(float).mul((d.z == z).astype(float), axis=0).add_prefix("g"))
        for per in range(n_per):
            if per != ref_period:
                X_.append(pd.DataFrame({f"zp{z}_{per}": ((d.z == z) & (d.per == per)).astype(float)}))
    names = []
    tr = d.pt.map(lambda a_: PTS[a_] in treated)
    for per in range(n_per):
        if per == ref_period:
            continue
        for z in (1, 2, 3, 4):
            if per_threshold:
                for a_ in pts_used:
                    if PTS[a_] in treated:
                        col = f"b_{ZONES[z]}_{PTS[a_] // 1_000_000}M_p{per}"
                        X_.append(pd.DataFrame({col: ((d.z == z) & (d.pt == a_) & (d.per == per)).astype(float)})); names.append(col)
            else:
                col = f"b_{ZONES[z]}_p{per}"
                X_.append(pd.DataFrame({col: ((d.z == z) & tr & (d.per == per)).astype(float)})); names.append(col)
    Xm = pd.concat(X_, axis=1)
    Xm = Xm.loc[:, Xm.sum() > 0]
    fit_ = sm.GLM(d.n, Xm, family=sm.families.Poisson()).fit()
    return {n_: float(fit_.params[n_]) for n_ in names}


def periods(months, yearly):
    if yearly:
        yrs = np.array([int(m_[:4]) for m_ in months]); labels = sorted(set(yrs))
        return np.array([labels.index(y) for y in yrs]), labels, labels.index(2018)
    pm = (months >= "2020-01").astype(int); pm[(months >= "2019-04") & (months < "2020-01")] = -1
    return pm, ["pre", "post"], 0


def did(A, months, pts_used, treated, per_threshold=False, yearly=False, B=500):
    per, labels, ref = periods(months, yearly)
    def cells(Ab, perb):
        return np.stack([Ab[:, perb == k].sum(1) for k in range(len(labels))], axis=1)
    point = fit(cells(A, per), pts_used, treated, ref, per_threshold)
    groups = [np.where(per == k)[0] for k in range(len(labels))]
    dr = []
    for _ in range(B):
        bi = np.concatenate([rng.choice(g, len(g)) for g in groups])
        dr.append(fit(cells(A[:, bi], per[bi]), pts_used, treated, ref, per_threshold))
    res = {}
    if yearly:
        # Report each year relative to the 2016-2018 mean (2018, the omitted year, enters as zero).
        pre_years = [labels.index(y) for y in (2016, 2017, 2018)]
        for z in sorted({k_.rsplit("_p", 1)[0] for k_ in point}):
            get = lambda r_, k: 0.0 if k == ref else r_[f"{z}_p{k}"]
            base_pt = np.mean([get(point, k) for k in pre_years])
            base_dr = np.array([np.mean([get(r_, k) for k in pre_years]) for r_ in dr])
            for k in range(len(labels)):
                v_ = get(point, k) - base_pt
                x_ = np.array([get(r_, k) for r_ in dr]) - base_dr
                res[f"{z}_{labels[k]}"] = {"coef": v_, "ci": np.percentile(x_, [2.5, 97.5]).tolist(), "pct": float(np.exp(v_) - 1),
                                           "pct_ci": (np.exp(np.percentile(x_, [2.5, 97.5])) - 1).tolist()}
        return res
    for k_, v_ in point.items():
        x_ = np.array([r_[k_] for r_ in dr])
        k2 = k_.rsplit("_p", 1)[0]
        res[k2] = {"coef": v_, "ci": np.percentile(x_, [2.5, 97.5]).tolist(), "pct": float(np.exp(v_) - 1),
                   "pct_ci": (np.exp(np.percentile(x_, [2.5, 97.5])) - 1).tolist()}
    return res


out["did"] = {}
idx = {X: PTS.index(X) for X in PTS}
ALL = list(range(len(PTS)))
CTRL_ONLY = [idx[x] for x in NEW + [1_000_000]]
PLAC_ONLY = [idx[x] for x in NEW + PLACEBO100]
for lab, (p, d) in (("deeds", (price, date)), ("all_rows", (aprice, adate))):
    A, months = monthly_counts(p, d)
    blk = {"pooled": did(A, months, ALL, NEW), "per_threshold": did(A, months, ALL, NEW, True)}
    if lab == "deeds":
        blk["control_only"] = did(A, months, CTRL_ONLY, NEW, B=300)
        blk["placebos_only"] = did(A, months, PLAC_ONLY, NEW, B=300)
        blk["yearly"] = did(A, months, ALL, NEW, yearly=True, B=300)
        # 4. Permutation: each placebo as if taxed, against the control and the other placebos (point estimates)
        per, labels, ref = periods(months, False)
        Tc = np.stack([A[:, per == k].sum(1) for k in range(2)], axis=1)
        fake = {}
        for Y in PLACEBO100:
            used = [idx[x] for x in [1_000_000] + PLACEBO100]
            fake[str(Y)] = fit(Tc, used, [Y], 0)
        blk["permutation"] = {"placebo_estimates": fake}
        real = fit(Tc, ALL, NEW, 0, per_threshold=True)
        realp = fit(Tc, ALL, NEW, 0)
        perm = {}
        for z in ("z4_at_X", "z5_above", "z3_just_below"):
            fk = np.array([fake[str(Y)][f"b_{z}_p1"] for Y in PLACEBO100])
            perm[z] = {"placebo_min": float(fk.min()), "placebo_max": float(fk.max()), "placebo_sd": float(fk.std(ddof=1)),
                       "pooled": realp[f"b_{z}_p1"], "pooled_placebos_as_extreme": int((np.abs(fk) >= abs(realp[f"b_{z}_p1"])).sum()),
                       "by_threshold": {f"{X // 1_000_000}M": {"coef": real[f"b_{z}_{X // 1_000_000}M_p1"],
                                                               "placebos_as_extreme_same_sign": int((np.sign(fk) == np.sign(real[f"b_{z}_{X // 1_000_000}M_p1"])).__and__(np.abs(fk) >= abs(real[f"b_{z}_{X // 1_000_000}M_p1"])).sum())}
                                        for X in NEW}}
        blk["permutation"]["summary"] = perm
        blk["permutation"]["n_placebos"] = len(PLACEBO100)
    out["did"][lab] = blk
    for k_ in ("pooled", "per_threshold"):
        print(lab, k_, {n_: (round(v_["pct"], 3), [round(c_, 3) for c_ in v_["pct_ci"]]) for n_, v_ in blk[k_].items()})
print(json.dumps(out["did"]["deeds"]["permutation"]["summary"], indent=1))
print({k_: round(v_["pct"], 3) for k_, v_ in out["did"]["deeds"]["yearly"].items() if "z4" in k_ or "z5" in k_})

# 6. Avoided tax variants
CS = json.loads((ROOT / "output/cost_and_sponsors.json").read_text())["revenue"]
FR = json.loads((ROOT / "output/focal_robustness.json").read_text())
BM = json.loads((ROOT / "output/benchmarks_v29.json").read_text())["full_schedule"]
JUMP = {X: TAXES[X][0] for X in NEW}
bt = CS["by_threshold"]
a = sum(bt[str(X)]["avoided_tax_per_year"] for X in NEW)
zz = FR["zones"]
b = sum(-(zz[str(X)]["exactly_X"]["sales_per_year"] + zz[str(X)]["above_excluding_X"]["sales_per_year"]) * JUMP[X] for X in NEW)
ctrl = bt["1000000"]["excess_share_of_window"]
c = sum(bt[str(X)]["avoided_tax_per_year"] * max(0.0, 1 - ctrl / bt[str(X)]["excess_share_of_window"]) for X in NEW)
TE = {"__file__": str(ROOT / "code/threshold_extension.py")}
exec(compile((ROOT / "code/threshold_extension.py").read_text().split("\nout = {}")[0], "threshold_extension.py", "exec"), TE)
assert np.array_equal(np.sort(TE["price"]), np.sort(price)), "sample differs from threshold_extension.py"
src = (ROOT / "code/cost_and_sponsors.py").read_text()
ns = {"np": np, "round_dummies": TE["round_dummies"]}
exec(src[src.index("def kw_parts"):src.index("def jump")], ns)
APRE, APOST = adate < "2019-04-01", adate >= "2020-01-01"
dd = sum(ns["reform_counts"](aprice[APRE], aprice[APOST], X)[0] / POST_YEARS * JUMP[X] for X in NEW)
out["avoided_tax"] = {"a_published": a, "b_direct_counts": b, "c_net_of_control": c, "d_all_rows": dd,
                      "revenue_full_schedule": BM["revenue_per_year"], "max_share_of_revenue": max(a, b, c, dd) / BM["revenue_per_year"]}
print("avoided", {k_: round(v_ / 1e6, 2) for k_, v_ in out["avoided_tax"].items() if k_ != "max_share_of_revenue"})

# 7. Loan amounts just below the threshold
src = (ROOT / "code/loan_notch.py").read_text()
LN = {"__file__": str(ROOT / "code/loan_notch.py")}
exec(compile(src.split("\nBW, WIN, EXCL, DEG")[0], "loan_notch.py", "exec"), LN)
x = LN["d"][LN["obs"]].copy()
x["date"] = x.date.astype(str)
KS = np.round(np.arange(0.50, 0.951, 0.05), 2)
loanres = {}
for X in (2_000_000, 3_000_000):
    for lab, m in (("post_just_below", (x.date >= "2020-01-01") & (x.price >= X - 10_000) & (x.price < X)),
                   ("pre_just_below", (x.date < "2019-04-01") & (x.price >= X - 10_000) & (x.price < X)),
                   ("post_at_X", (x.date >= "2020-01-01") & (x.price == X)),
                   ("pre_at_X", (x.date < "2019-04-01") & (x.price == X))):
        g = x[m]
        L, P = g.mort_amt.to_numpy(float), g.price.to_numpy(float)
        of_X = np.isin(L, KS * X)
        of_P = np.array([np.any(np.abs(L_ - np.round(KS * P_)) <= 1) for L_, P_ in zip(L, P)]) if len(L) else np.array([], bool)
        loanres[f"{X}_{lab}"] = {"n": int(len(L)), "loan_round_fraction_of_X": int(of_X.sum()),
                                 "loan_round_fraction_of_P_only": int((of_P & ~of_X).sum()),
                                 "share_of_X": float(of_X.mean()) if len(L) else None,
                                 "share_of_P_only": float((of_P & ~of_X).mean()) if len(L) else None}
out["loan_amounts_near_threshold"] = loanres
(ROOT / "output/focal_inference.json").write_text(json.dumps(out, indent=1))
