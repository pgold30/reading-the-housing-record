"""v1.1: cost the residential purchase-money carve-out bottom-up, and solve for
revenue-neutral smooth replacement schedules.

v1.6: condominium recording tax is computed on each condominium's own loan,
taken from the linked dataset (data/condo_loans.csv.gz, built by
build_linked_fields.py) and matched to the panel on unit BBL, sale date and
price. Condominiums whose loan is missing or outside the loan-to-value screen
are imputed at the mean ratio of observed condominium loans in their price
band, as houses always were. v1.5's output is kept as revenue_neutral_v1.5.json.

Base: the merged house/condominium panel (four boroughs, $300k-$6M, 2016-2025).
Revenue replaced: borrower-borne MRT on each financed purchase at its own loan
size (1.80% below $500k, 1.925% at or above), of which the Section 253(2)
MTA-dedicated component is 0.30% of the loan. Financed purchases whose loan
amount is unobserved are imputed at the mean MRT/price ratio of their property
type and price band; the observed-only figure is reported as a lower bound.
Replacements are continuous marginal schedules on price paid by every buyer,
so no price point carries a jump. Revenue neutrality holds within this sample.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
PANEL = ROOT.parent / "2_tables" / "panel2.csv.gz"  # merged house/condominium panel shipped in 2_tables
d = pd.read_csv(PANEL, dtype={"bbl": str})
# Four boroughs only, as the manuscript states. Staten Island records carry
# financing flag 0 throughout (ACRIS holds no Staten Island deeds or mortgages),
# so including them enlarged the replacement base with no recorded MRT
# (v1.3 correction: 290,840 -> 249,395 purchases).
d = d[d["borough"].astype(str).isin(["1", "2", "3", "4"])].copy()
YEARS = 10
# v1.6: attach each condominium's own loan from the linked dataset (unique keys only).
cl = pd.read_csv(ROOT / "data/condo_loans.csv.gz", dtype={"unit_bbl": str, "sale_date": str})
cl["key"] = cl.unit_bbl + "|" + cl.sale_date + "|" + cl.sale_price.astype(float).map(repr)
cl = cl[~cl.key.duplicated(keep=False)].set_index("key")
d["key"] = d.bbl + "|" + d.date.astype(str) + "|" + d.price.astype(float).map(repr)
is_condo = d.src == "condo"
d.loc[is_condo, "mort_amt"] = d.loc[is_condo, "key"].map(cl.mortgage_amount_base).fillna(0.0).astype(float)
d["ltv"] = d.mort_amt / d.price
obs = (d.financed_base == 1) & (d.mort_amt > 0) & (d.ltv > 0.05) & (d.ltv <= 1.05)
d["mrt"] = np.where(obs, np.where(d.mort_amt < 500_000, 0.0180, 0.01925) * d.mort_amt, 0.0)
d["mta"] = np.where(obs, 0.0030 * d.mort_amt, 0.0)
d["band"] = pd.cut(d.price, [300_000, 500_000, 1_000_000, 2_000_000, 6_000_000], right=False,
                   labels=["$300k-500k", "$500k-1M", "$1M-2M", "$2M-6M"])
# Houses: loan amounts observed in the panel; the few financed houses without
# one are imputed at the observed house band mean MRT/price. Condominium loan
# amounts are not in the panel (they were recovered from ACRIS separately for
# Table 1), so financed condominiums are imputed at Table 1's measured mean
# burden of 1.28% of price. The MTA share of an imputed MRT is the observed
# house ratio of the 253(2) component to total borrower-borne MRT.
obs_house = obs & (d.src == "house"); obs_condo = obs & (d.src == "condo")
ratio = (d[obs_house].assign(r=lambda x: x.mrt / x.price).groupby("band", observed=True).r.mean())
ratio_condo = (d[obs_condo].assign(r=lambda x: x.mrt / x.price).groupby("band", observed=True).r.mean())
mta_to_mrt = d.loc[obs_house, "mta"].sum() / d.loc[obs_house, "mrt"].sum()
imp_house = (d.financed_base == 1) & ~obs & (d.src == "house")
imp_condo = (d.financed_base == 1) & ~obs & (d.src == "condo")
d.loc[imp_house, "mrt"] = d.loc[imp_house, "band"].map(ratio).astype(float) * d.loc[imp_house, "price"]
d.loc[imp_condo, "mrt"] = d.loc[imp_condo, "band"].map(ratio_condo).astype(float) * d.loc[imp_condo, "price"]
imp = imp_house | imp_condo
d.loc[imp, "mta"] = mta_to_mrt * d.loc[imp, "mrt"]
R_obs = d.loc[obs, "mrt"].sum(); R_obs_house = d.loc[obs_house, "mrt"].sum(); R_obs_condo = d.loc[obs_condo, "mrt"].sum()
R_all = d.mrt.sum(); R_mta = d.mta.sum()
P = d.price.to_numpy()


def solve(base):
    return R_all / base.sum()


schedules = {}
# (A) flat rate on the whole price, every buyer
schedules["A_flat"] = {"desc": "tau * P", "tau": solve(P), "tax": lambda t: t * P}
# (B) single marginal rate above $500,000
b500 = np.maximum(P - 500_000, 0)
schedules["B_above_500k"] = {"desc": "tau * max(P - 500k, 0)", "tau": solve(b500), "tax": lambda t: t * b500}
# (C) two brackets, continuous: tau on 500k-2M, 2*tau above 2M
bC = np.minimum(np.maximum(P - 500_000, 0), 1_500_000) + 2 * np.maximum(P - 2_000_000, 0)
schedules["C_two_bracket"] = {"desc": "tau on (500k,2M], 2*tau above 2M", "tau": solve(bC), "tax": lambda t: t * bC}

# v1.8: the borrower-side burden table of the paper (Table 4), computed on the
# same observed loans, so that its condominium row comes from deposited data
# (v1.7 and earlier quoted a non-deposited extract of 47,610 condominium loans
# with the same statistics at the reported precision).
def burden(m):
    x = d[m]; s = np.where(x.mort_amt < 500_000, 0.0180, 0.01925) * x.mort_amt / x.price
    return {"loans": int(m.sum()), "ltv_mean": float(x.ltv.mean()), "ltv_median": float(x.ltv.median()),
            "mrt_share_mean": float(s.mean()), "mrt_share_median": float(np.median(s)),
            "mrt_share_p10": float(np.percentile(s, 10)), "mrt_share_p90": float(np.percentile(s, 90))}


table4 = {"houses": burden(obs_house), "condominiums": burden(obs_condo)}
res = {"table4_burden_on_observed_loans": table4,
       "sample": {"purchases": int(len(d)), "financed": int((d.financed_base == 1).sum()),
                  "financed_loan_observed": int(obs.sum()), "financed_house_loan_observed": int(obs_house.sum()),
                  "financed_condo_loan_observed": int(obs_condo.sum()), "financed_house_imputed": int(imp_house.sum()),
                  "financed_condo_imputed": int(imp_condo.sum()), "years": YEARS},
       "revenue_per_year": {"borrower_mrt_observed_house_loans_only": R_obs_house / YEARS,
                            "borrower_mrt_observed_condo_loans": R_obs_condo / YEARS,
                            "borrower_mrt_observed_loans": R_obs / YEARS,
                            "borrower_mrt_imputed_houses": d.loc[imp_house, "mrt"].sum() / YEARS,
                            "borrower_mrt_imputed_condos": d.loc[imp_condo, "mrt"].sum() / YEARS,
                            "borrower_mrt_with_imputation": R_all / YEARS,
                            "mta_253_2_component_with_imputation": R_mta / YEARS},
       "mta_only_flat_rate": R_mta / P.sum(), "schedules": {}}
fin = d.financed_base.to_numpy() == 1
for k, s in schedules.items():
    tax = s["tax"](s["tau"]); net = tax - d.mrt.to_numpy()
    tab = (pd.DataFrame({"band": d.band, "fin": np.where(fin, "financed", "cash"), "net": net})
           .groupby(["band", "fin"], observed=True).net.mean().unstack())
    res["schedules"][k] = {"desc": s["desc"], "tau_percent": 100 * s["tau"],
                           "revenue_check_per_year": float(tax.sum() / YEARS),
                           "financed_share_paying_less": float((net[fin] < 0).mean()),
                           "mean_net_change_by_band": {b: {c: float(v) for c, v in row.items()} for b, row in tab.iterrows()},
                           "mean_net_change": {"financed": float(net[fin].mean()), "cash": float(net[~fin].mean())}}
res["by_property_type_flat_rate_percent"] = {t: float(100 * g.mrt.sum() / g.price.sum()) for t, g in d.groupby("src")}
res["by_property_type_above_500k_rate_percent"] = {t: float(100 * g.mrt.sum() / np.maximum(g.price - 500_000, 0).sum()) for t, g in d.groupby("src")}
(ROOT / "output/revenue_neutral.json").write_text(json.dumps(res, indent=1, default=float))
print(json.dumps(res, indent=1, default=float))
