"""v2.0: the bin-count difference-in-differences year by year (focal_inference.py,
section 5). Two panels: sales at exactly the threshold, and sales in (X, 1.05X)
beyond the round price; percentage change at the three new
thresholds relative to the 2016-2018 mean, net of the $1M control and the never-taxed $100,000 multiples, with
95% month-block bootstrap intervals. 2019, the transition year, is hollow.
Writes output/Figure_8.pdf and .png."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
Y = json.loads((ROOT / "output/focal_inference.json").read_text())["did"]["deeds"]["yearly"]
BLUE, INK, MUTED = "#1a6fa0", "#222222", "#6b6b6b"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": "#b0b0b0", "axes.linewidth": 0.8,
                     "xtick.color": MUTED, "ytick.color": MUTED, "axes.labelcolor": INK})
years = list(range(2016, 2026))
fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.2))
for ax, (z, title) in zip(axes, (("z4_at_X", "Sales at exactly the threshold"), ("z5_above", "Sales in $(X, 1.05X)$, beyond the round price"))):
    est, lo, hi = [], [], []
    for y in years:
        v = Y[f"b_{z}_{y}"]
        est.append(100 * v["pct"]); lo.append(100 * v["pct_ci"][0]); hi.append(100 * v["pct_ci"][1])
    est, lo, hi = map(np.array, (est, lo, hi))
    ax.axhline(0, color="#9a9a9a", lw=0.8, zorder=1)
    ax.axvspan(2019.5, 2025.5, color="#eef3f7", zorder=0)
    for y, e, a, b in zip(years, est, lo, hi):
        ax.plot([y, y], [a, b], color=BLUE, lw=1.4, zorder=2)
        ax.plot(y, e, "o", ms=6, mfc="white" if y == 2019 else BLUE, mec=BLUE, mew=1.5, zorder=3)
    ax.set_title(title, fontsize=9.5, color=INK, loc="left")
    ax.set_xticks(years); ax.set_xticklabels([str(y)[2:] if y != 2016 else "2016" for y in years])
    ax.grid(axis="y", color="#e6e6e6", lw=0.6, zorder=0)
    ax.spines[["top", "right"]].set_visible(False)
axes[0].set_ylabel("Change relative to 2016–2018 (%)")
fig.tight_layout()
fig.savefig(ROOT / "output/Figure_8.pdf"); fig.savefig(ROOT / "output/Figure_8.png", dpi=200)
print({y: (round(100 * Y[f"b_z4_at_X_{y}"]["pct"]), round(100 * Y[f"b_z5_above_{y}"]["pct"])) for y in years})
