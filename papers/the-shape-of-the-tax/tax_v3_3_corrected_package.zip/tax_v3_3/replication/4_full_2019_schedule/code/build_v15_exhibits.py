"""v1.5: render Supplemental Appendix Table A6 (every core placebo) from
output/placebo_inference.json, and Table 7 of the paper and Supplemental
Table A7 from output/market_splits.json. Writes output/tab_placebos.tex,
output/tab_where.tex and output/tab_where_full.tex."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
P = json.loads((ROOT / "output/placebo_inference.json").read_text())
V, core = P["scaled"]["values"], P["scaled"]["placebos_core"]
f3 = lambda v: f"$+{v:.3f}$" if v >= 0 else f"$-{abs(v):.3f}$"
money = lambda x: "\\$" + f"{x:,}".replace(",", "{,}")
rows = [f"{money(x)} & {V[str(x)]['window_n_pre']:,}/{V[str(x)]['window_n_post']:,} & {f3(V[str(x)]['kw_diff'])} & {f3(V[str(x)]['logR_change'])} \\\\".replace(",", "{,}").replace("{{,}}", "{,}")
        for x in core]
treated = [f"{money(x)} & {V[str(x)]['window_n_pre']:,}/{V[str(x)]['window_n_post']:,} & {f3(V[str(x)]['kw_diff'])} & {f3(V[str(x)]['logR_change'])} \\\\".replace(",", "{,}").replace("{{,}}", "{,}")
           for x in (1_000_000, 2_000_000, 3_000_000, 5_000_000)]
b = P["scaled"]["core"]["placebo_kw"]
tex = r"""\begin{center}
\textbf{Table A6:} Every core placebo, with the treated thresholds for comparison
\end{center}
{\small\begin{tabular}{lccc}
\toprule
Price & Sales in window, pre/post & Bunching, post $-$ pre & $\Delta\log R$ \\
\midrule
\multicolumn{4}{l}{\textit{Never-taxed placebos}}\\
""" + "\n".join(rows) + r"""
\midrule
\multicolumn{4}{l}{\textit{Thresholds (\$1{,}000{,}000 always taxed; the others created in 2019)}}\\
""" + "\n".join(treated) + r"""
\bottomrule
\end{tabular}}

\noindent{\footnotesize Estimator, windows and pre/post periods as in Table 4 of the paper. Placebos are
the \$50{,}000 multiples between \$1{,}200{,}000 and \$6{,}000{,}000 whose window $[0.8X, 1.2X)$ holds no
statutory threshold. Placebo bunching changes: mean """ + f3(b["mean"]) + ", standard deviation " + f"{b['sd']:.3f}" + \
", maximum " + f3(b["max"]) + r""". Source: \texttt{placebo\_inference.py}.}
"""
(ROOT / "output/tab_placebos.tex").write_text(tex)
print(tex)

# Table 7 of the paper and Supplemental Table A7 (market_splits.py)
RX = json.loads((ROOT / "output/market_splits.json").read_text())
H, F, MG = RX["heterogeneity"], RX["foreclosure_and_lender_deeds"], RX["magnitudes"]
S = json.loads((ROOT / "output/cost_and_sponsors.json").read_text())["sponsor"]  # v1.7
X4 = ["1000000", "2000000", "3000000", "5000000"]
SUB = [("All sales", H["all"]), ("Houses", H["houses"]), ("Condominiums", H["condominiums"]), ("Co-operatives", H["co-operatives"]),
       ("Manhattan", H["manhattan"]), ("Other four boroughs", H["other_boroughs"]),
       ("No company seller", S["all_resale"]), ("Company seller (sponsor proxy)", S["all_sponsor"]),
       ("Without legal-rule deeds", F["drop_legal_rule"]), ("Without any lender or referee deed", F["drop_any_lender_or_referee"])]
cell = lambda v: f"{f3(v['kw_diff'])} ({v['placebos_as_large']})"
lines = [f"{lab} & " + " & ".join(cell(h[x]) for x in X4) + f" & {h['placebo_kw_sd']:.3f} \\\\" for lab, h in SUB]
lines.insert(8, "\\addlinespace"); lines.insert(6, "\\addlinespace"); lines.insert(4, "\\addlinespace"); lines.insert(1, "\\addlinespace")
d0 = lambda v: "\\$" + f"{round(v, -2):,.0f}".replace(",", "{,}") if v >= 0 else "$-$\\$" + f"{round(-v, -2):,.0f}".replace(",", "{,}")
mrows = []
for x in X4:
    m = MG[x]
    mrows.append(f"{money(int(x))} & {d0(m['buyer_jump_dollars'])} & {d0(m['excess_below_dollars_change'])} & {d0(m['missing_above_dollars_change'])} & "
                 + (f"{m['missing_above_dollars_change'] / m['buyer_jump_dollars']:.1f}" if x != "1000000" else "---") + " \\\\")
where = r"""\begin{table}[htbp]
\centering
\caption{Where the response comes from, and how large it is}
\label{tab:where}
\singlespacing\footnotesize
\begin{tabular}{lccccc}
\toprule
\multicolumn{6}{l}{\textit{Panel A. Change in bunching, post $-$ pre (placebos at least as large, of 16)}}\\
\midrule
 & \$1{,}000{,}000 & \$2{,}000{,}000 & \$3{,}000{,}000 & \$5{,}000{,}000 & Placebo \\
 & (control) & & & & SD \\
\midrule
""" + "\n".join(lines) + r"""
\midrule
\multicolumn{6}{l}{\textit{Panel B. Size of the change, in dollars of price at the counterfactual density}}\\
\midrule
 & Buyer's & Excess mass & Missing mass & \multicolumn{2}{c}{Missing mass /} \\
 & jump & below $X$ & above $X$ & \multicolumn{2}{c}{buyer's jump} \\
\midrule
""" + "\n".join(r.replace(" \\\\", " & \\\\") if False else r.rsplit(" \\\\", 1)[0] + " & \\\\" for r in mrows) + r"""
\bottomrule
\end{tabular}
\notes{\textit{Notes.} Estimator, windows and periods as in Table~\ref{tab:fullschedule}. Property types follow the Department of Finance building-class category (houses 01--03; condominiums 04, 12, 13, 15; co-operatives 09, 10, 17) and come from the linked dataset \citep{loschi2026data}, whose sales are the same records as this paper's sample. Each row's placebos are the sixteen of Table~\ref{tab:placebo}, recomputed within that row's sample. The last two market rows split sales by whether the linked deed names a company as seller, a proxy that includes sponsor (developer) sales and other company sales; sales without a linked deed are in neither row. Deed screens use the linked dataset's deed classifier \citep{loschi2026deed}; sales with no linked deed (co-operatives, Staten Island sales, and houses and condominiums whose deed was not matched) are kept. Panel~B divides the excess mass in $(X-0.025X, X)$ and the missing mass in $(X, X+0.05X)$ by the counterfactual density of sales per dollar at $X$, post minus pre; the buyer's jump at \$1{,}000{,}000 is the mansion tax, unchanged in 2019. Supplemental Appendix Table~A7 adds log changes in $R$ and window sizes. Replication package v1.12, \texttt{market\_splits.py} and \texttt{cost\_and\_sponsors.py}.}
\end{table}
"""
(ROOT / "output/tab_where.tex").write_text(where)
fl = []
for lab, h in SUB:
    fl.append(f"\\multicolumn{{5}}{{l}}{{\\textit{{{lab}}} (placebo SD {h['placebo_kw_sd']:.3f})}}\\\\")
    for x in X4:
        v = h[x]
        fl.append(f"\\quad {money(int(x))} & {v['window_n_pre']:,} & {f3(v['kw_diff'])} ({v['placebos_as_large']}) & {f3(v['logR_change'])} ({v['placebos_as_low_R']}) & {v['z']:+.1f} \\\\".replace(",", "{,}").replace("{{,}}", "{,}"))
full = r"""\begin{center}
\textbf{Table A7:} The response by market and after deed screens, both statistics
\end{center}
{\small\begin{tabular}{lcccc}
\toprule
 & Pre-reform sales & Bunching, post $-$ pre & $\Delta\log R$ & $z$ against \\
 & in window & (placebos as large) & (placebos as low) & placebo SD \\
\midrule
""" + "\n".join(fl) + r"""
\bottomrule
\end{tabular}}

\noindent{\footnotesize Placebo counts are out of sixteen, computed within each row's sample. Source: \texttt{market\_splits.py}.}
"""
(ROOT / "output/tab_where_full.tex").write_text(full)
print(where)
