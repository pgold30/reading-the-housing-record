"""v1.5: attach property type, borough and deed flags to every sale.

Reads the supplied linked dataset (NYC residential sales linked to ACRIS
deeds and mortgages, 2016-2025, corrected v1.2.0 candidate, concept DOI 10.5281/zenodo.22977532):
build/sales.csv.gz, build/links.csv.gz and build/deed_flags.csv.gz, from the
folder given as the first argument. Its 729,047 sales are the same records as
data/sales_2016_2025_date_price.csv.gz (identical multiset of date and price,
checked below), so the unstratified price sample is unchanged. Linked-property subgroup outputs must be rerun when link or party flags change.

Writes data/linked_fields.csv.gz: sale_date, sale_price, property_group,
borough, deed_event, legal_rule_amount (blank when the sale has no linked
deed: co-operatives, Staten Island and unmatched sales).

v1.6: also writes data/condo_loans.csv.gz, one row per condominium sale whose
deed matched a unit lot: unit BBL, sale date, price, the base-window financing
flag and the largest base-window mortgage amount and document. The costing
(revenue_neutral.py) uses it for loan-level condominium recording tax.

v1.7: linked_fields also carries grantor_company and grantee_company (company
names on the seller or buyer side of the linked deed; blank without a linked
deed) and year_built from the sales file. cost_and_sponsors.py uses them to separate
sponsor (developer) sales from resales.
"""
import collections, csv, gzip, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = Path(sys.argv[1] if len(sys.argv) > 1 else ROOT.parents[1] / "nyc_linked_dataset/build")

flags = {r["deed_document_id"]: r for r in csv.DictReader(gzip.open(SRC / "deed_flags.csv.gz", "rt"))}
links = {r["sale_id"]: r for r in csv.DictReader(gzip.open(SRC / "links.csv.gz", "rt"))}
rows = []
for s in csv.DictReader(gzip.open(SRC / "sales.csv.gz", "rt")):
    d = links[s["sale_id"]]["deed_document_id"]
    f = flags.get(d, {})
    rows.append({"sale_date": s["sale_date"], "sale_price": s["sale_price"], "property_group": s["property_group"],
                 "borough": s["borough"], "deed_event": f.get("deed_event", ""), "legal_rule_amount": f.get("legal_rule_amount", ""),
                 "grantor_company": f.get("grantor_company", ""), "grantee_company": f.get("grantee_company", ""),
                 "year_built": s["year_built"]})

old = collections.Counter((r["sale_date"][:10], float(r["sale_price"] or 0))
                          for r in csv.DictReader(gzip.open(ROOT / "data/sales_2016_2025_date_price.csv.gz", "rt")))
new = collections.Counter((r["sale_date"][:10], float(r["sale_price"] or 0)) for r in rows)
assert old == new, "linked dataset does not match the deposited sales file"

with gzip.open(ROOT / "data/linked_fields.csv.gz", "wt", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0]))
    w.writeheader(); w.writerows(rows)
print(f"wrote data/linked_fields.csv.gz: {len(rows):,} sales, identical to the deposited date/price file")

sales = {s["sale_id"]: s for s in csv.DictReader(gzip.open(SRC / "sales.csv.gz", "rt")) if s["property_group"] == "condo"}
cols = ["unit_bbl", "sale_date", "sale_price", "financed_base", "mortgage_amount_base", "mortgage_document_id_base"]
n = 0
with gzip.open(ROOT / "data/condo_loans.csv.gz", "wt", newline="") as fh:
    w = csv.writer(fh); w.writerow(cols)
    for sid, l in links.items():
        s = sales.get(sid)
        if s and l["linked_bbl"]:
            w.writerow([l["linked_bbl"], s["sale_date"], s["sale_price"], l["financed_base"], l["mortgage_amount_base"], l["mortgage_document_id_base"]]); n += 1
print(f"wrote data/condo_loans.csv.gz: {n:,} condominium sales with a matched unit lot")
