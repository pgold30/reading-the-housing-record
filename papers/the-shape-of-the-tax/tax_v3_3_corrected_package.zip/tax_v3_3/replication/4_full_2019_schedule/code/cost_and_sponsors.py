"""v1.7: four further questions, all with the published scaled estimator.

1. Revenue. How much tax do the 2019 notches lose to bunching? The reform's
   excess mass below X (sales piled up in (0.975X, X), post minus pre, the pre
   pile rescaled to the post counterfactual density) is converted to sales per
   year; each such sale avoids at least the statutory jump at X. That is set
   against the reform's own taxes (the supplemental tax of Tax Law 1402-b and
   the 0.25-point base-rate rise at $3M) collected on post-reform sales between
   $2M and $6M. Bootstrap intervals resample sales within window and period.
2. Where the missing sales go. The same comparison for the missing mass above
   X: missing minus excess, in sales per year, is the part of the emptied range
   not found in the pile just below.
3. Sponsor sales. Developers set price lists and some 2020-21 closings were
   contracted before the April 2019 cut-off. The changes at $1M-$5M are
   recomputed separately for sponsor sales (company grantor on the linked deed)
   and for resales, overall and for condominiums, and for sales in buildings
   completed within three years of the sale; each against the sixteen core
   placebos computed within the same sample (as market_splits.py). A late
   post-period (2022-2025) is added for sponsor sales.
4. Liquidity, with condominium loans. The loan-to-value test of ltv_charm.py
   (Section 4.8) used houses only, because condominium loans were not in the
   panel. Condominium loans are attached from data/condo_loans.csv.gz with the
   key revenue_neutral.py uses, and the test is rerun on houses and
   condominiums with a property-type effect.
Writes output/cost_and_sponsors.json.
"""
import csv, gzip, json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
rng = np.random.default_rng(20260929)
TE = {"__file__": str(ROOT / "code/threshold_extension.py")}
exec(compile((ROOT / "code/threshold_extension.py").read_text().split("\nout = {}")[0], "threshold_extension.py", "exec"), TE)
kw, round_dummies, T = TE["kw"], TE["round_dummies"], TE["T"]
PLACEBOS = json.loads((ROOT / "output/placebo_inference.json").read_text())["scaled"]["placebos_core"]
X4 = [1_000_000, 2_000_000, 3_000_000, 5_000_000]
POST_YEARS = 6.0  # January 2020 to December 2025

import importlib.util as _ilu
_spec = _ilu.spec_from_file_location("deeds", Path(__file__).resolve().parent / "deeds.py")
deeds = _ilu.module_from_spec(_spec); _spec.loader.exec_module(deeds)
rows = deeds.linked_rows()
price = np.array([float(r["sale_price"] or 0) for r in rows])
date = np.array([r["sale_date"][:10] for r in rows])
group = np.array([r["property_group"] for r in rows])
gcomp = np.array([r["grantor_company"] for r in rows])
ybuilt = np.array([int(r["year_built"]) if r["year_built"].isdigit() else 0 for r in rows])
keep = price > 300_000
price, date, group, gcomp, ybuilt = price[keep], date[keep], group[keep], gcomp[keep], ybuilt[keep]
year = np.array([int(d[:4]) for d in date])
PRE, POST = date < "2019-04-01", date >= "2020-01-01"
assert np.array_equal(np.sort(price), np.sort(TE["price"])), "sample differs from threshold_extension.py"


def kw_parts(p, X, deg=5):
    """As in market_splits.py: excess mass B below X, missing mass M above X, counterfactual density h0 at X."""
    bw = max(b for b in (10_000, 25_000, 50_000, 100_000) if b <= max(10_000, 0.005 * X))
    window, below, above = 0.2 * X, 0.025 * X, 0.05 * X
    lo, hi = X - window, X + window
    sel = p[(p >= lo) & (p < hi)]
    edges = np.arange(lo, hi + bw / 2, bw)
    cnt, _ = np.histogram(sel, bins=edges)
    mid = edges[:-1] + bw / 2
    excl = (mid > X - below) & (mid < X + above)
    Xm = np.column_stack([((mid - X) / window) ** k for k in range(deg + 1)] + [round_dummies(mid, bw)])
    beta, *_ = np.linalg.lstsq(Xm[~excl], cnt[~excl], rcond=None)
    cf = Xm @ beta
    a, b = (mid > X) & (mid < X + above), (mid > X - below) & (mid < X)
    i = int(np.searchsorted(mid, X))
    h0 = float((cf[i - 1] + cf[i]) / 2 / bw)
    return float((cnt[b] - cf[b]).sum()), float((cf[a] - cnt[a]).sum()), h0


def reform_counts(pre, post, X):
    """Reform-induced excess and missing sales in the post period: post minus the pre pile scaled to post density."""
    Bq, Mq, hq = kw_parts(post, X); Bp, Mp, hp = kw_parts(pre, X)
    s = hq / hp
    return Bq - s * Bp, Mq - s * Mp


def jump(X):
    b, s = T[X][2], T[X][3]
    return (b + s) / 100 * X if X != 1_000_000 else 0.0  # the $1M notch did not change in 2019


# 1-2. Revenue lost to bunching, and missing minus excess
def supp_rate(p):
    r = np.zeros_like(p)
    for X, (_, cohort, b, s) in sorted(T.items()):
        if cohort == "2019":
            r = np.where(p >= X, sum(T[k][2] + T[k][3] for k in T if T[k][1] == "2019" and k <= X), r)
    return r / 100


band = POST & (price >= 2_000_000) & (price < 6_000_000)
collected = float((supp_rate(price[band]) * price[band]).sum() / POST_YEARS)
rev = {"collected_reform_tax_2M_6M_per_year": collected, "post_sales_2M_6M_per_year": float(band.sum() / POST_YEARS), "by_threshold": {}}
tot_draws = np.zeros(500)
for X in X4:
    pre, post = price[PRE], price[POST]
    B, M = reform_counts(pre, post, X)
    wpre = pre[(pre >= 0.8 * X) & (pre < 1.2 * X)]; wpost = post[(post >= 0.8 * X) & (post < 1.2 * X)]
    dB, dM = [], []
    for r in range(500):
        b_, m_ = reform_counts(rng.choice(wpre, len(wpre)), rng.choice(wpost, len(wpost)), X)
        dB.append(b_); dM.append(m_)
    dB, dM = np.array(dB), np.array(dM)
    j = jump(X)
    if X != 1_000_000:
        tot_draws += dB / POST_YEARS * j
    rev["by_threshold"][str(X)] = {
        "jump_dollars": j,
        "excess_sales_per_year": B / POST_YEARS, "excess_sales_per_year_ci": [float(v) for v in np.percentile(dB / POST_YEARS, [2.5, 97.5])],
        "missing_sales_per_year": M / POST_YEARS, "missing_sales_per_year_ci": [float(v) for v in np.percentile(dM / POST_YEARS, [2.5, 97.5])],
        "missing_minus_excess_per_year": (M - B) / POST_YEARS,
        "missing_minus_excess_per_year_ci": [float(v) for v in np.percentile((dM - dB) / POST_YEARS, [2.5, 97.5])],
        "avoided_tax_per_year": B / POST_YEARS * j, "avoided_tax_per_year_ci": [float(v) for v in np.percentile(dB / POST_YEARS * j, [2.5, 97.5])]}
# Upper bound: a sale moved below X also lowers every ad-valorem transfer tax on
# the price reduction, which is at most the emptied range, 0.05X. Rates just at
# X: mansion tax 1%, city RPTT 1.425%, state base 0.4% (0.65% from $3M), and
# the supplemental rate reached at X.
ADVAL_AT_X = {2_000_000: 1.0 + 1.425 + 0.40 + 0.25, 3_000_000: 1.0 + 1.425 + 0.65 + 0.50, 5_000_000: 1.0 + 1.425 + 0.65 + 1.25}
for X, r in ADVAL_AT_X.items():
    v = rev["by_threshold"][str(X)]
    v["adval_rate_at_X_pct"] = r
    v["avoided_tax_upper_per_year"] = v["excess_sales_per_year"] * (v["jump_dollars"] + 0.05 * X * r / 100)
rev["avoided_total_upper_per_year"] = sum(rev["by_threshold"][str(X)]["avoided_tax_upper_per_year"] for X in ADVAL_AT_X)
avoided = sum(v["avoided_tax_per_year"] for v in rev["by_threshold"].values())
rev["avoided_total_per_year"] = avoided
rev["avoided_upper_share_of_collected_plus_avoided"] = rev["avoided_total_upper_per_year"] / (collected + rev["avoided_total_upper_per_year"])
rev["avoided_total_per_year_ci"] = [float(v) for v in np.percentile(tot_draws, [2.5, 97.5])]
rev["avoided_share_of_collected_plus_avoided"] = avoided / (collected + avoided)
# Placebo noise in the same count, per year, as a share of each window's post sales per year
plac = []
for X in PLACEBOS:
    B, _ = reform_counts(price[PRE], price[POST], X)
    n = ((price[POST] >= 0.8 * X) & (price[POST] < 1.2 * X)).sum()
    plac.append(B / n)
rev["placebo_excess_share_of_window"] = {"mean": float(np.mean(plac)), "sd": float(np.std(plac, ddof=1)), "max": float(np.max(plac))}
for X in X4:
    n = ((price[POST] >= 0.8 * X) & (price[POST] < 1.2 * X)).sum()
    v = rev["by_threshold"][str(X)]
    v["excess_share_of_window"] = v["excess_sales_per_year"] * POST_YEARS / n
    v["placebos_excess_share_as_large"] = int((np.array(plac) >= v["excess_share_of_window"]).sum())


# 3. Sponsor sales
def logR(p, x):
    a = ((p >= x) & (p < 1.05 * x)).sum(); b = ((p >= 0.925 * x) & (p < 0.975 * x)).sum()
    return np.log(a / b) if a > 0 and b > 0 else np.nan


def changes(mask, x, post=POST):
    pre, po = price[mask & PRE], price[mask & post]
    return (float(kw(po, x)[0] - kw(pre, x)[0]), float(logR(po, x) - logR(pre, x)),
            int(((pre >= 0.8 * x) & (pre < 1.2 * x)).sum()), int(((po >= 0.8 * x) & (po < 1.2 * x)).sum()))


def judged(mask, post=POST):
    ref = [changes(mask, x, post) for x in PLACEBOS]
    kref = np.array([r[0] for r in ref]); rref = np.array([r[1] for r in ref])
    sd, mu = float(np.nanstd(kref, ddof=1)), float(np.nanmean(kref))
    out = {"placebo_kw_sd": sd, "placebo_kw_mean": mu}
    for x in X4:
        k, r, npre, npost = changes(mask, x, post)
        out[str(x)] = {"kw_diff": k, "logR_change": r, "window_n_pre": npre, "window_n_post": npost,
                       "placebos_as_large": int(np.sum(kref >= k)), "placebos_as_low_R": int(np.sum(rref <= r)), "z": (k - mu) / sd}
    return out


sponsor = gcomp == "1"; resale = gcomp == "0"
newbuild = (ybuilt > 0) & (ybuilt >= year - 3)
condo = group == "condo"
spon = {"share_sponsor_in_condo_windows": {}}
for x in X4:
    w = condo & (price >= 0.8 * x) & (price < 1.2 * x)
    spon["share_sponsor_in_condo_windows"][str(x)] = {"pre": float(sponsor[w & PRE].mean()), "post": float(sponsor[w & POST].mean())}
spon["all_sponsor"] = judged(sponsor)
spon["all_resale"] = judged(resale)
spon["condo_sponsor"] = judged(condo & sponsor)
spon["condo_resale"] = judged(condo & resale)
spon["condo_new_building"] = judged(condo & newbuild)
spon["condo_older_building"] = judged(condo & ~newbuild)
spon["condo_sponsor_post_2022_2025"] = judged(condo & sponsor, post=date >= "2022-01-01")

# 4. Liquidity test with condominium loans
p = pd.read_csv(ROOT.parent / "2_tables" / "panel2.csv.gz", dtype={"bbl": str})
cl = pd.read_csv(ROOT / "data/condo_loans.csv.gz", dtype={"unit_bbl": str, "sale_date": str})
cl["key"] = cl.unit_bbl + "|" + cl.sale_date + "|" + cl.sale_price.astype(float).map(repr)
cl = cl[~cl.key.duplicated(keep=False)].set_index("key")
p["key"] = p.bbl + "|" + p.date.astype(str) + "|" + p.price.astype(float).map(repr)
is_condo = p.src == "condo"
p.loc[is_condo, "mort_amt"] = p.loc[is_condo, "key"].map(cl.mortgage_amount_base).fillna(0.0).astype(float)
p["year"] = p.date.str[:4].astype(int)
parts = []
for X in [500_000, 1_000_000, 2_000_000, 3_000_000]:
    s = p[p.price.isin([X - 1, X])].copy(); s["X"] = X; parts.append(s)
d = pd.concat(parts, ignore_index=True)
d["charm"] = (d.price == d.X - 1).astype(float)
d["ltv"] = d.mort_amt / d.price
fin = d[(d.financed_base == 1) & (d.mort_amt > 0) & (d.ltv > 0) & (d.ltv <= 1)].copy()
fin["ltv10"] = fin.ltv * 10; fin["high_ltv"] = (fin.ltv >= 0.8).astype(float); fin["condo"] = (fin.src == "condo").astype(float)


def lpm(df, cols):
    Xmat = pd.concat([df[cols], pd.get_dummies(df.X.astype(str), prefix="t", dtype=float),
                      pd.get_dummies(df.year.astype(str), prefix="y", drop_first=True, dtype=float)], axis=1).to_numpy(float)
    y = df.charm.to_numpy()
    XtX_inv = np.linalg.pinv(Xmat.T @ Xmat); b = XtX_inv @ Xmat.T @ y; e = y - Xmat @ b
    g = pd.factorize(df.bbl)[0]
    S = np.zeros((Xmat.shape[1], Xmat.shape[1]))
    for k in np.unique(g):
        sc = Xmat[g == k].T @ e[g == k]; S += np.outer(sc, sc)
    V = XtX_inv @ S @ XtX_inv
    return {c: [float(b[i]), float(np.sqrt(V[i, i]))] for i, c in enumerate(cols)}, int(len(df))


ltv = {}
buyer = fin[fin.X > 500_000]
for name, df, extra in [("houses", buyer[buyer.src == "house"], []), ("condominiums", buyer[buyer.src == "condo"], []),
                        ("houses_and_condominiums", buyer, ["condo"]), ("seller_paid_500k_both", fin[fin.X == 500_000], ["condo"])]:
    ltv[name] = {"per_10pts": lpm(df, ["ltv10"] + extra), "ltv_ge_80": lpm(df, ["high_ltv"] + extra),
                 "charm_share": float(df.charm.mean()), "n": int(len(df))}

out = {"revenue": rev, "sponsor": spon, "liquidity_with_condos": ltv}
(ROOT / "output/cost_and_sponsors.json").write_text(json.dumps(out, indent=1))

print(f"reform tax collected, $2M-$6M sales: ${collected / 1e6:,.1f}M a year on {rev['post_sales_2M_6M_per_year']:,.0f} sales")
for X in X4:
    v = rev["by_threshold"][str(X)]
    print(f"{X:>10,} jump {v['jump_dollars']:>7,.0f} excess/yr {v['excess_sales_per_year']:6.1f} {np.round(v['excess_sales_per_year_ci'], 1)}"
          f" missing/yr {v['missing_sales_per_year']:6.1f}  M-B/yr {v['missing_minus_excess_per_year']:6.1f} {np.round(v['missing_minus_excess_per_year_ci'], 1)}"
          f" avoided ${v['avoided_tax_per_year'] / 1e6:.2f}M {np.round(np.array(v['avoided_tax_per_year_ci']) / 1e6, 2)}"
          f"  share of window {v['excess_share_of_window']:.3f} (placebos >= {v['placebos_excess_share_as_large']})")
print(f"avoided total ${avoided / 1e6:.2f}M {np.round(np.array(rev['avoided_total_per_year_ci']) / 1e6, 2)}; share {rev['avoided_share_of_collected_plus_avoided']:.3%}; placebo excess share {rev['placebo_excess_share_of_window']}")
print("sponsor share in condo windows:", spon["share_sponsor_in_condo_windows"])
for name in ["all_sponsor", "all_resale", "condo_sponsor", "condo_resale", "condo_new_building", "condo_older_building", "condo_sponsor_post_2022_2025"]:
    h = spon[name]; print(f"\n{name}: placebo sd {h['placebo_kw_sd']:.3f}")
    for x in X4:
        v = h[str(x)]
        print(f"  {x:>10,} n {v['window_n_pre']:>5}/{v['window_n_post']:>5} kw {v['kw_diff']:+.3f} (pl>= {v['placebos_as_large']:>2}) dlogR {v['logR_change']:+.3f} (pl<= {v['placebos_as_low_R']})")
print(json.dumps(ltv, indent=1))
