"""v2.0: Table 1 of the paper on one row per deed: sales at exactly X relative to
the local density of non-round sales, and sales at X - 1 a year, before
(January 2016-March 2019, 3.25 years) and after (2020-2025, 6 years) the reform.
Local density: sales between $5,000 and $25,000 from X on either side whose
price is not a multiple of $10,000, per $10,000 of price (v2.0: the $5,000 on
either side of X, where moved sales land or go missing, is left out). Writes
output/focal_table.json and output/tab_focal.tex."""
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
TE = {"__file__": str(ROOT / "code/threshold_extension.py")}
exec(compile((ROOT / "code/threshold_extension.py").read_text().split("\nout = {}")[0], "threshold_extension.py", "exec"), TE)
price, PRE, POST = TE["price"], TE["PRE"], TE["POST"]


YEARS = {"pre": 3.25, "post": 6.0}


def local_density(p, x, half=25_000, gap=5_000):
    d = np.abs(p - x)
    near = p[(d >= gap) & (d < half) & (p % 10_000 != 0)]
    return len(near) / (2 * (half - gap)) * 10_000


out = {}
for x in [1_000_000, 2_000_000, 3_000_000, 5_000_000, 1_500_000, 2_500_000]:
    r = {}
    for lab, m in (("pre", PRE), ("post", POST)):
        p = price[m]
        r[lab] = {"at_X": int((p == x).sum()), "at_X_per_year": float((p == x).sum() / YEARS[lab]),
                  "spike_ratio": float((p == x).sum() / local_density(p, x)), "at_X_minus_1": int((p == x - 1).sum()),
                  "at_X_minus_1_per_year": float((p == x - 1).sum() / YEARS[lab])}
    out[str(x)] = r
    print(x, r)
(ROOT / "output/focal_table.json").write_text(json.dumps(out, indent=1))
lab = {"1000000": "\\$1{,}000{,}000 --- taxed throughout", "2000000": "\\$2{,}000{,}000 --- new in 2019",
       "3000000": "\\$3{,}000{,}000 --- new in 2019", "5000000": "\\$5{,}000{,}000 --- new in 2019",
       "1500000": "\\$1{,}500{,}000 --- never taxed", "2500000": "\\$2{,}500{,}000 --- never taxed"}
rows = []
for k in ("1000000", "2000000", "3000000", "5000000", "1500000", "2500000"):
    v = out[k]
    rows.append(f"{lab[k]} & {v['pre']['spike_ratio']:.1f} & {v['post']['spike_ratio']:.1f} & {v['pre']['at_X_minus_1_per_year']:.1f} & {v['post']['at_X_minus_1_per_year']:.1f} \\\\")
    if k == "5000000":
        rows.append("\\addlinespace")
tab = r"""\begin{table}[htbp]
\centering
\caption{Round prices before and after the 2019 reform}
\label{tab:focal}
\singlespacing\small
\begin{tabular}{lcccc}
\toprule
 & \multicolumn{2}{c}{Sales at exactly $X$, relative} & \multicolumn{2}{c}{Sales at $X-1$,} \\
 & \multicolumn{2}{c}{to local density} & \multicolumn{2}{c}{a year} \\
\cmidrule(lr){2-3}\cmidrule(lr){4-5}
Price point & Before Apr 2019 & From Jan 2020 & Before & From Jan 2020 \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\notes{\textit{Notes.} One row per deed (Section~\ref{sec:data}). The periods are January 2016 to March 2019 and January 2020 to December 2025; the nine months in between are left out, because conveyances under contracts signed on or before 1 April 2019 were grandfathered. Local density is the number of sales between \$5{,}000 and \$25{,}000 from $X$ on either side whose price is not a multiple of \$10{,}000, per \$10{,}000 of price; the \$5{,}000 on either side, where moved sales land or go missing, is left out. Sales at $X-1$ are divided by the length of each period (3.25 and 6 years). The table uses counts only, with no fitted counterfactual. Replication package, \texttt{focal\_table.py}.}
\end{table}
"""
(ROOT / "output/tab_focal.tex").write_text(tab)
