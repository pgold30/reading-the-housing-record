"""v1.1: does closing-cash liquidity explain who avoids a notch?

Buyer-side transfer taxes are paid in cash at closing and cannot be financed.
If liquidity binds, financed buyers with high loan-to-value should price one
dollar below a BUYER-paid notch ($1M, $2M, $3M) more often than low-LTV
financed buyers, and LTV should not matter at the SELLER-paid $500k notch,
which works as a within-design placebo.

Sample: financed purchases (base window) at exactly X-1 or X in the merged
house/condominium panel, with a positive recorded loan and 0 < LTV <= 1.
Linear probability model of P(price = X-1) on LTV, threshold and year fixed
effects; parcel-clustered (CR0) standard errors.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
PANEL = ROOT.parent / "2_tables" / "panel2.csv.gz"  # merged house/condominium panel shipped in 2_tables
p = pd.read_csv(PANEL, dtype={"bbl": str})
p["year"] = p.date.str[:4].astype(int)
rows = []
for X in [500_000, 1_000_000, 2_000_000, 3_000_000]:
    s = p[p.price.isin([X - 1, X])].copy(); s["X"] = X; rows.append(s)
d = pd.concat(rows, ignore_index=True)
d["charm"] = (d.price == d.X - 1).astype(float)
d["ltv"] = d.mort_amt / d.price
fin = d[(d.financed_base == 1) & (d.mort_amt > 0) & (d.ltv > 0) & (d.ltv <= 1)].copy()
cash = d[d.financed_base == 0]


def lpm(df, cols):
    X = pd.concat([df[cols], pd.get_dummies(df.X.astype(str), prefix="t", dtype=float),
                   pd.get_dummies(df.year.astype(str), prefix="y", drop_first=True, dtype=float)], axis=1).to_numpy(float)
    y = df.charm.to_numpy()
    XtX_inv = np.linalg.pinv(X.T @ X); b = XtX_inv @ X.T @ y; e = y - X @ b
    g = pd.factorize(df.bbl)[0]
    S = np.zeros((X.shape[1], X.shape[1]))
    for k in np.unique(g):
        sc = X[g == k].T @ e[g == k]; S += np.outer(sc, sc)
    V = XtX_inv @ S @ XtX_inv
    return {c: (float(b[i]), float(np.sqrt(V[i, i]))) for i, c in enumerate(cols)}, len(df)


out = {"counts": {}, "models": {}}
for X, g in fin.groupby("X"):
    out["counts"][str(X)] = {"financed_n": int(len(g)), "charm_share": float(g.charm.mean()),
                             "ltv_median": float(g.ltv.median()),
                             "charm_by_ltv_tercile": [float(v) for v in g.groupby(pd.qcut(g.ltv, 3, labels=False, duplicates="drop")).charm.mean()],
                             "cash_n": int((cash.X == X).sum()), "cash_charm_share": float(cash[cash.X == X].charm.mean())}
buyer = fin[fin.X > 500_000].copy(); seller = fin[fin.X == 500_000].copy()
for name, df in [("buyer_paid_1M_2M_3M", buyer), ("seller_paid_500k", seller)]:
    df = df.copy(); df["ltv10"] = df.ltv * 10  # per 10 LTV points
    df["high_ltv"] = (df.ltv >= 0.8).astype(float)
    out["models"][name] = {"continuous_per_10pts": lpm(df, ["ltv10"]), "ltv_ge_80": lpm(df, ["high_ltv"])}
# Pooled interaction: LTV slope at buyer-paid minus seller-paid notch
fin2 = fin.copy(); fin2["ltv10"] = fin2.ltv * 10; fin2["buyer_notch"] = (fin2.X > 500_000).astype(float)
fin2["ltv10_x_buyer"] = fin2.ltv10 * fin2.buyer_notch
out["models"]["interaction_all"] = lpm(fin2, ["ltv10", "ltv10_x_buyer"])
(ROOT / "output/ltv_charm.json").write_text(json.dumps(out, indent=1))
print(json.dumps(out, indent=1))
