"""v2.0: the bin-count difference-in-differences of focal_inference.py (part 3)
against never-taxed prices as round as the thresholds, and on two subsamples.

1. Roundness-matched placebos: the multiples of $500,000 among the 24 placebos
   ($1.5M, $2.5M, $3.5M, $4M, $4.5M), with the $1M control, and without it.
   Each matched placebo in turn is also treated as if taxed, against the control
   and the other four.
2. Post-reform years 2022-2025 only (2020-2021 dropped), all 24 placebos.
3. Sales without a company seller on the linked deed, all 24 placebos.
Also: the moved share at X adjusted by the matched placebos' own change in the
share of sales at exactly the round price.
Same model, zones and block bootstrap over calendar months (300 draws, seed
20261015). Writes output/did_round_placebos.json.
"""
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
src = (ROOT / "code/focal_inference.py").read_text()
setup = src[:src.index("pre, post = price[PRE], price[POST]")]
funcs = src[src.index("# 3-5. Bin-count difference-in-differences"):src.index('out["did"] = {}')]
G = {"__file__": str(ROOT / "code/focal_inference.py"), "__name__": "fi"}
exec(compile(setup + "\n" + funcs, "focal_inference.py", "exec"), G)
G["rng"] = np.random.default_rng(20261015)
PTS, NEW, PLACEBO100, did, fit, monthly_counts, periods = (G[k] for k in ("PTS", "NEW", "PLACEBO100", "did", "fit", "monthly_counts", "periods"))
price, date = G["price"], G["date"]
MATCHED = [x for x in PLACEBO100 if x % 500_000 == 0]
idx = {X: PTS.index(X) for X in PTS}
ALL = list(range(len(PTS)))
M_CTRL = [idx[x] for x in NEW + [1_000_000] + MATCHED]
M_ONLY = [idx[x] for x in NEW + MATCHED]
out = {"matched_placebos": MATCHED}
summ = lambda r: {k: {"pct": v["pct"], "pct_ci": v["pct_ci"]} for k, v in r.items() if k.split("_")[1] in ("z4", "z5", "z3")}

A, months = monthly_counts(price, date)
out["matched_with_control"] = {"pooled": summ(did(A, months, M_CTRL, NEW, B=300)), "per_threshold": summ(did(A, months, M_CTRL, NEW, True, B=300))}
out["matched_only"] = {"pooled": summ(did(A, months, M_ONLY, NEW, B=300))}
per, labels, ref = periods(months, False)
Tc = np.stack([A[:, per == k].sum(1) for k in range(2)], axis=1)
fake = {str(Y): fit(Tc, [idx[x] for x in [1_000_000] + MATCHED], [Y], 0) for Y in MATCHED}
out["matched_permutation"] = {z: {Y: float(np.expm1(v[f"b_{z}_p1"])) for Y, v in fake.items()} for z in ("z4_at_X", "z5_above")}

keep = ~((date >= "2020-01-01") & (date < "2022-01-01"))
A2, m2 = monthly_counts(price[keep], date[keep])
out["post_2022_2025"] = {"pooled": summ(did(A2, m2, ALL, NEW, B=300)), "per_threshold": summ(did(A2, m2, ALL, NEW, True, B=300))}

rows = G["deeds"].linked_rows(all_rows=False)
pp = np.array([float(r["sale_price"] or 0) for r in rows]); dd = np.array([r["sale_date"][:10] for r in rows]); cc = np.array([r["grantor_company"] for r in rows])
k = (pp > 300_000) & (cc == "0")
A3, m3 = monthly_counts(pp[k], dd[k])
out["no_company_seller"] = {"pooled": summ(did(A3, m3, ALL, NEW, B=300)), "per_threshold": summ(did(A3, m3, ALL, NEW, True, B=300))}

# moved share at X against the matched placebos
PRE, POST = date < "2019-04-01", date >= "2020-01-01"
w = lambda p, X: p[(p >= 0.9 * X) & (p < 1.1 * X)]
pa = sum((w(price[PRE], Y) == Y).sum() for Y in MATCHED) / sum(len(w(price[PRE], Y)) for Y in MATCHED)
pb = sum((w(price[POST], Y) == Y).sum() for Y in MATCHED) / sum(len(w(price[POST], Y)) for Y in MATCHED)
out["matched_spike_ratio_post_over_pre"] = float(pb / pa)
FI = json.loads((ROOT / "output/focal_inference.json").read_text())["moved_share"]
out["moved_against_matched"] = {X: 1 - (1 - FI[X]["moved"]) / (pb / pa) for X in ("2000000", "3000000", "5000000")}
(ROOT / "output/did_round_placebos.json").write_text(json.dumps(out, indent=1))
print(json.dumps(out, indent=1))
