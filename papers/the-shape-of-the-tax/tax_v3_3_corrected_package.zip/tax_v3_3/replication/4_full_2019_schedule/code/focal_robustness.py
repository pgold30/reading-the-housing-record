"""v1.12: how much of the response is the round price itself?

Before 2019, $2,000,000, $3,000,000 and $5,000,000 were ordinary focal prices,
with many sales recorded at exactly the round number. A notch at X makes that
price the first taxed one, so a sale that would have closed at exactly X can
avoid the jump by recording a price a few dollars or a few thousand dollars
lower. Such moves are real responses to the tax, but they are not price
reductions of the size the bunching widths suggest: the smooth counterfactual
density reads a pile drawn from a mass point at X as if it came from a range of
prices above X.

This script measures that margin and re-estimates the main statistics
without it.
  1. Where the moved sales came from. Shares of sales in [0.9X, 1.1X), before
     and after, in five zones: [0.95X, X-5,000), [X-5,000, X), exactly X,
     (X, 1.05X), and the rest of the window; the change times post-reform
     window sales per year gives sales a year. Bootstrap intervals.
  2. How far below X the reform-induced excess in [X-10,000, X) sits: the
     mean of X - P over post-reform sales there, less the pre-reform sum
     rescaled to post-reform window size, over the excess count.
  3. The published statistics (Kleven-Waseem change, log change in R,
     pile and hole widths) on samples that drop, in both periods and at
     every placebo alike: sales at exactly X and X-1; sales within $1,000 of
     X; sales within $5,000 of X. The counterfactual fit is unchanged,
     because every dropped price lies inside the excluded range; in a bin
     that loses part of its price range the counterfactual is scaled by the
     share kept. Placebo counts against the sixteen core placebos.
  4. The same for houses, whose $1M control is flat (Table 6).
  5. Net of the always-treated control: each threshold's change minus the
     $1M change, with independent bootstrap draws (disjoint windows).
  6. The proportionality contrast 5M - 3 x 2M on the focal-excluded sample.
  7. The round-number indicators. round_dummies() in threshold_extension.py
     flags bins by np.round(mid / bw), which rounds half to even, so with
     $10,000 bins it marks the two bins either side of each multiple of
     $100,000 and never a bin holding a multiple of $50,000 or $25,000 alone.
     The published estimator is kept; this step reports the change when the
     indicators instead mark the bin that contains each multiple.
  8. All rows. The analysis keeps one row per deed (deeds.py); the main
     statistics are recomputed on every row of the sales file, placebos alike.
Writes output/focal_robustness.json and output/tab_focal.tex.
"""
import csv, gzip, json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
TE = {"__file__": str(ROOT / "code/threshold_extension.py")}
exec(compile((ROOT / "code/threshold_extension.py").read_text().split("\nout = {}")[0], "threshold_extension.py", "exec"), TE)
price, PRE, POST, round_dummies, T = TE["price"], TE["PRE"], TE["POST"], TE["round_dummies"], TE["T"]
PLACEBOS = json.loads((ROOT / "output/placebo_inference.json").read_text())["scaled"]["placebos_core"]
rng = np.random.default_rng(20261013)
R = 500
POST_YEARS = 6.0
X4 = [1_000_000, 2_000_000, 3_000_000, 5_000_000]
NEW = [2_000_000, 3_000_000, 5_000_000]
DONUTS = {"all": (0, 0), "drop_X_and_X-1": (1, 1), "drop_1k": (1_000, 1_000), "drop_5k": (5_000, 5_000)}
JUMP_ALL = {X: (T[X][2] + T[X][3]) / 100 * X for X in X4}

import importlib.util as _ilu
_spec = _ilu.spec_from_file_location("deeds", Path(__file__).resolve().parent / "deeds.py")
deeds = _ilu.module_from_spec(_spec); _spec.loader.exec_module(deeds)
rows = deeds.linked_rows()
lp = np.array([float(r["sale_price"] or 0) for r in rows])
ld = np.array([r["sale_date"][:10] for r in rows])
lg = np.array([r["property_group"] for r in rows])
lb = np.array([r["borough"] for r in rows])
k = lp > 300_000
lp, ld, lg, lb = lp[k], ld[k], lg[k], lb[k]
assert np.array_equal(np.sort(lp), np.sort(price)), "sample differs from threshold_extension.py"
HOUSE = lg == "house"


def rd_containing(mid, bw):
    """Indicator for the bin [mid - bw/2, mid + bw/2) that contains a multiple of 100k, 50k, 25k."""
    e = mid - bw / 2
    return np.column_stack([(np.ceil(e / m) * m < e + bw).astype(float) for m in (100_000, 50_000, 25_000)])


def drop(p, X, d):
    return p[~((p >= X - d[0]) & (p < X + d[1]))]


def parts(p, X, d=(0, 0), rd=round_dummies, deg=5):
    """Kleven-Waseem fit as in threshold_extension.kw; returns (missing share, excess B, missing M, density h0)."""
    bw = max(b for b in (10_000, 25_000, 50_000, 100_000) if b <= max(10_000, 0.005 * X))
    window, below, above = 0.2 * X, 0.025 * X, 0.05 * X
    lo, hi = X - window, X + window
    sel = drop(p[(p >= lo) & (p < hi)], X, d)
    edges = np.arange(lo, hi + bw / 2, bw)
    cnt, _ = np.histogram(sel, bins=edges)
    mid = edges[:-1] + bw / 2
    kept = 1 - np.clip(np.minimum(edges[1:], X + d[1]) - np.maximum(edges[:-1], X - d[0]), 0, None) / bw
    excl = (mid > X - below) & (mid < X + above)
    Xm = np.column_stack([((mid - X) / window) ** k for k in range(deg + 1)] + [rd(mid, bw)])
    beta, *_ = np.linalg.lstsq(Xm[~excl], cnt[~excl], rcond=None)
    cf_full = Xm @ beta
    cf = cf_full * kept
    a, b = (mid > X) & (mid < X + above), (mid > X - below) & (mid < X)
    i = int(np.searchsorted(mid, X))
    h0 = float((cf_full[i - 1] + cf_full[i]) / 2 / bw)
    ca = cf[a].sum()
    return float((cf[a] - cnt[a]).sum() / ca), float((cnt[b] - cf[b]).sum()), float((cf[a] - cnt[a]).sum()), h0


def stats(pre, post, X, d, rd=round_dummies):
    s0, B0, M0, h0 = parts(pre, X, d, rd)
    s1, B1, M1, h1 = parts(post, X, d, rd)
    return {"kw": s1 - s0, "pile": B1 / h1 - B0 / h0, "hole": M1 / h1 - M0 / h0}


def logR(pre, post, X, d):
    f = lambda p, lo, hi: int(((p >= lo) & (p < hi)).sum())
    a, b = f(drop(pre, X, d), X, 1.05 * X), f(drop(pre, X, d), 0.925 * X, 0.975 * X)
    c, e = f(drop(post, X, d), X, 1.05 * X), f(drop(post, X, d), 0.925 * X, 0.975 * X)
    est = float(np.log(c / e) - np.log(a / b))
    se = float(np.sqrt(1 / a + 1 / b + 1 / c + 1 / e))
    return est, [est - 1.96 * se, est + 1.96 * se]


def win(p, X):
    return p[(p >= 0.8 * X) & (p < 1.2 * X)]


out = {"donuts": {k: list(v) for k, v in DONUTS.items()}, "placebos": PLACEBOS, "estimates": {}, "houses": {}}

# 3. Published statistics with and without the focal prices, all sales; placebos alike.
pre_all, post_all = price[PRE], price[POST]
draws = {}
for name, d in DONUTS.items():
    pk = np.array([stats(pre_all, post_all, Y, d)["kw"] for Y in PLACEBOS])
    pr = np.array([logR(pre_all, post_all, Y, d)[0] for Y in PLACEBOS])
    blk = {"placebo_kw": {"mean": float(pk.mean()), "sd": float(pk.std(ddof=1)), "max": float(pk.max())},
           "placebo_logR": {"mean": float(pr.mean()), "sd": float(pr.std(ddof=1)), "min": float(pr.min())}}
    for X in X4:
        st = stats(pre_all, post_all, X, d)
        lr, lr_ci = logR(pre_all, post_all, X, d)
        a, b = win(pre_all, X), win(post_all, X)
        dr = np.array([[v for v in stats(rng.choice(a, len(a)), rng.choice(b, len(b)), X, d).values()] for _ in range(R)])
        draws[(name, X)] = dr
        blk[str(X)] = {**st, "kw_ci": np.percentile(dr[:, 0], [2.5, 97.5]).tolist(),
                       "pile_ci": np.percentile(dr[:, 1], [2.5, 97.5]).tolist(), "hole_ci": np.percentile(dr[:, 2], [2.5, 97.5]).tolist(),
                       "kw_placebos_as_large": int((pk >= st["kw"]).sum()), "kw_z": float((st["kw"] - pk.mean()) / pk.std(ddof=1)),
                       "logR": lr, "logR_ci": lr_ci, "logR_placebos_as_low": int((pr <= lr).sum()),
                       "pile_over_jump": st["pile"] / JUMP_ALL[X] if X != 1_000_000 else None,
                       "hole_over_jump": st["hole"] / JUMP_ALL[X] if X != 1_000_000 else None}
    # 5. Net of the $1M control (independent draws; the windows do not overlap).
    for X in NEW:
        est = blk[str(X)]["kw"] - blk["1000000"]["kw"]
        dd = draws[(name, X)][:, 0] - draws[(name, 1_000_000)][:, 0]
        blk[str(X)]["kw_net_of_control"] = est
        blk[str(X)]["kw_net_of_control_ci"] = np.percentile(dd, [2.5, 97.5]).tolist()
        blk[str(X)]["logR_net_of_control"] = blk[str(X)]["logR"] - blk["1000000"]["logR"]
    # 6. Proportionality: 5M - 3 x 2M, and 5M - 2M, as in equality_test.py (recentred draws).
    for tname, mult in (("5M_minus_3x2M", 3.0), ("5M_minus_2M", 1.0), ("3M_minus_2M", None), ("3M_minus_2x2M", -2.0)):
        if mult is None:
            pt = blk["3000000"]["kw"] - blk["2000000"]["kw"]; st_ = draws[(name, 3_000_000)][:, 0] - draws[(name, 2_000_000)][:, 0]
        elif mult < 0:  # v2.0: $3M against twice $2M, proportional to the total rate (0.50 against 0.25 points)
            pt = blk["3000000"]["kw"] + mult * blk["2000000"]["kw"]; st_ = draws[(name, 3_000_000)][:, 0] + mult * draws[(name, 2_000_000)][:, 0]
        else:
            pt = blk["5000000"]["kw"] - mult * blk["2000000"]["kw"]; st_ = draws[(name, 5_000_000)][:, 0] - mult * draws[(name, 2_000_000)][:, 0]
        blk[tname] = {"estimate": float(pt), "ci": np.percentile(st_, [2.5, 97.5]).tolist(),
                      "p_two_sided": float(np.mean(np.abs(st_ - st_.mean()) >= abs(pt)))}
    out["estimates"][name] = blk

# 4. Houses, against placebos within houses.
hpre, hpost = lp[HOUSE & (ld < "2019-04-01")], lp[HOUSE & (ld >= "2020-01-01")]
for name in ("all", "drop_X_and_X-1", "drop_5k"):
    d = DONUTS[name]
    pk = np.array([stats(hpre, hpost, Y, d)["kw"] for Y in PLACEBOS])
    blk = {"placebo_kw_sd": float(pk.std(ddof=1))}
    for X in X4:
        v = stats(hpre, hpost, X, d)["kw"]
        blk[str(X)] = {"kw": v, "kw_placebos_as_large": int((pk >= v).sum())}
    out["houses"][name] = blk

# 1. Where the moved sales came from, and 2. how far below X they sit.
ZONES = {"further_below": lambda p, X: (p >= 0.95 * X) & (p < X - 5_000),
         "within_5k_below": lambda p, X: (p >= X - 5_000) & (p < X),
         "exactly_X": lambda p, X: p == X,
         "above_excluding_X": lambda p, X: (p > X) & (p < 1.05 * X)}


def zones(pre, post, X):
    a = pre[(pre >= 0.9 * X) & (pre < 1.1 * X)]; b = post[(post >= 0.9 * X) & (post < 1.1 * X)]
    res = {}
    for z, f in ZONES.items():
        sa, sb = f(a, X).mean(), f(b, X).mean()
        res[z] = {"share_pre": float(sa), "share_post": float(sb), "sales_per_year": float((sb - sa) * len(b) / POST_YEARS)}
    za, zb = a[(a >= X - 10_000) & (a < X)], b[(b >= X - 10_000) & (b < X)]
    s = len(b) / len(a)
    excess = len(zb) - s * len(za)
    res["mean_distance_below_X_of_excess"] = float(((X - zb).sum() - s * (X - za).sum()) / excess) if excess > 0 else None
    res["excess_in_last_10k"] = float(excess)
    return res


out["zones"] = {}
for X in X4 + [1_500_000, 2_500_000]:
    z = zones(pre_all, post_all, X)
    a, b = pre_all[(pre_all >= 0.9 * X) & (pre_all < 1.1 * X)], post_all[(post_all >= 0.9 * X) & (post_all < 1.1 * X)]
    zd = [zones(rng.choice(a, len(a)), rng.choice(b, len(b)), X) for _ in range(R)]
    for key in ZONES:
        z[key]["sales_per_year_ci"] = np.percentile([v[key]["sales_per_year"] for v in zd], [2.5, 97.5]).tolist()
    md = [v["mean_distance_below_X_of_excess"] for v in zd if v["mean_distance_below_X_of_excess"] is not None]
    z["mean_distance_ci"] = np.percentile(md, [2.5, 97.5]).tolist() if len(md) > 0.9 * R else None
    out["zones"][str(X)] = z

# 7. Round-number indicators that mark the bin containing each multiple.
out["indicator_check"] = {}
for name in ("all", "drop_X_and_X-1"):
    out["indicator_check"][name] = {str(X): stats(pre_all, post_all, X, DONUTS[name], rd_containing) for X in X4}

# The $1M notch has no pre-reform period; its widths are post-reform levels.
out["level_1M"] = {}
for name in ("all", "drop_X_and_X-1", "drop_5k"):
    _, B, M, h = parts(post_all, 1_000_000, DONUTS[name])
    out["level_1M"][name] = {"pile": B / h, "hole": M / h}

# Frictionless elasticities (notch_elasticity.py) from the widths with and without the round price;
# nan where the width is narrower than the range a fully informed buyer would never choose.
NE = {"__file__": str(ROOT / "code/notch_elasticity.py")}
exec(compile((ROOT / "code/notch_elasticity.py").read_text().split("\n# Self-check")[0], "notch_elasticity.py", "exec"), NE)
out["elasticity_all_taxes"] = {}
for name in ("all", "drop_5k"):
    blk = {}
    for X in NEW:
        tb, db, ta, da = NE["RATES"][X]
        v = out["estimates"][name][str(X)]
        blk[str(X)] = {k: NE["elasticity"](v[k] / X, ta, da) for k in ("pile", "hole")}
        blk[str(X)]["dominated_range_dollars"] = da / 100 / (1 + (ta + da) / 100) * X
    out["elasticity_all_taxes"][name] = blk

# 8. Every row of the sales file (the analysis keeps one row per deed).
arows = deeds.linked_rows(all_rows=True)
ap = np.array([float(r["sale_price"] or 0) for r in arows]); ad = np.array([r["sale_date"][:10] for r in arows])
kk = ap > 300_000; ap, ad = ap[kk], ad[kk]
cpre, cpost = ap[ad < "2019-04-01"], ap[ad >= "2020-01-01"]
out["all_rows"] = {"rows": int(len(ap)), "rows_one_per_deed": int(len(price)), "rows_added": int(len(ap) - len(price))}
for name in ("all", "drop_X_and_X-1"):
    d = DONUTS[name]
    pk = np.array([stats(cpre, cpost, Y, d)["kw"] for Y in PLACEBOS])
    blk = {"placebo_kw_sd": float(pk.std(ddof=1))}
    for X in X4:
        st = stats(cpre, cpost, X, d)
        blk[str(X)] = {**st, "kw_placebos_as_large": int((pk >= st["kw"]).sum()), "logR": logR(cpre, cpost, X, d)[0]}
    out["all_rows"][name] = blk

(ROOT / "output/focal_robustness.json").write_text(json.dumps(out, indent=1))

# Printed summary
for name, blk in out["estimates"].items():
    print(f"\n[{name}] placebo kw sd {blk['placebo_kw']['sd']:.3f} max {blk['placebo_kw']['max']:+.3f}; logR min {blk['placebo_logR']['min']:+.3f}")
    for X in X4:
        v = blk[str(X)]
        print(f"  {X:>9,} kw {v['kw']:+.3f} {np.round(v['kw_ci'], 3)} pl>={v['kw_placebos_as_large']} | logR {v['logR']:+.3f} pl<={v['logR_placebos_as_low']}"
              f" | pile {v['pile']:>8,.0f} hole {v['hole']:>8,.0f}" + (f" net {v['kw_net_of_control']:+.3f} {np.round(v['kw_net_of_control_ci'], 3)}" if 'kw_net_of_control' in v else ""))
    for t in ("5M_minus_3x2M", "5M_minus_2M", "3M_minus_2M", "3M_minus_2x2M"):
        print(f"  {t} {blk[t]['estimate']:+.3f} {np.round(blk[t]['ci'], 3)} p={blk[t]['p_two_sided']:.3f}")
for name, blk in out["houses"].items():
    print(f"houses [{name}] sd {blk['placebo_kw_sd']:.3f} " + " ".join(f"{X/1e6:g}M {blk[str(X)]['kw']:+.3f}({blk[str(X)]['kw_placebos_as_large']})" for X in X4))
for X, z in out["zones"].items():
    print(f"{int(X):>9,} " + " | ".join(f"{k} {z[k]['sales_per_year']:+.1f} {np.round(z[k]['sales_per_year_ci'], 1)}" for k in ZONES)
          + f" | mean dist {z['mean_distance_below_X_of_excess']} {z['mean_distance_ci']}")
for name in ("all", "drop_X_and_X-1"):
    blk = out["all_rows"][name]
    print(f"all rows [{name}] sd {blk['placebo_kw_sd']:.3f} " + " ".join(f"{X/1e6:g}M {blk[str(X)]['kw']:+.3f}({blk[str(X)]['kw_placebos_as_large']}) R {blk[str(X)]['logR']:+.3f}" for X in X4))
for name, blk in out["indicator_check"].items():
    print(f"indicators [{name}] " + " ".join(f"{int(X)/1e6:g}M {v['kw']:+.3f}" for X, v in blk.items()))
