"""v2.0: what the one-row-per-deed rule removes near the thresholds, and whether
the removed rows repeat one deed.

The rule (build_deed_groups.py) keeps one row per sale date, borough, tax block
and price. For every group of rows it merges whose price lies within 10% of
$1M, $2M, $3M or $5M, this script counts the rows removed by price zone
(further below, the $5,000 below, exactly X, the 5% above, outer) and period,
and classifies each group:
  - one ACRIS deed: a single recorded deed (ACRIS document type DEED*) dated
    within 30 days of the sale date lists every lot of the group;
  - separate ACRIS deeds: the lots carry different deeds dated within 30 days;
  - same lot, same address: repeated rows for one unit;
  - same lot, different apartments: co-operative apartments in one building
    (co-op share sales are not recorded in ACRIS, so these cannot be checked
    against deeds). They are split by price: a group whose price is at least
    twice the median price of the building's other, unrepeated sales,
    2016-2025, is a price for several apartments together ("bulk price"); the
    rest ("unit price") could be separate sales;
  - not found: no deed within 30 days in ACRIS (Staten Island included, which
    ACRIS does not cover).
Inputs: the full extract written by fetch_full_price_range.py (not deposited)
and data/acris_merge_check.json (the ACRIS Legals and Master records of the
groups' lots, retrieved from NYC Open Data resources 8h5j-fqxa and bnx9-e6tj).
Writes output/deed_merge_check.json.
"""
import json, sys
from collections import defaultdict, Counter
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
src = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "data/annualized_sales_all_prices.json"
rows = json.loads(src.read_text())
A = json.loads((ROOT / "data/acris_merge_check.json").read_text())
TH = (1_000_000, 2_000_000, 3_000_000, 5_000_000)


def zone(p, X):
    if p == X: return "at_X"
    if X - 5_000 <= p < X: return "just_below"
    if X < p < 1.05 * X: return "above"
    if 0.95 * X <= p < X - 5_000: return "below"
    if 0.9 * X <= p < 1.1 * X: return "outer"


def period(d):
    return "pre" if d < "2019-04-01" else ("post" if d >= "2020-01-01" else "transition")


bmed = defaultdict(list)
g = defaultdict(list)
for r in rows:
    g[(r["sale_date"][:10], str(int(float(r["borough"]))), int(float(r.get("sale_price") or 0)), str(r.get("block", "")).strip())].append(r)
for k, rs in g.items():
    if len(rs) == 1 and k[2] > 0:
        bmed[(k[1], k[3], str(rs[0]["lot"]).strip())].append(k[2])
import statistics
bmed = {k: statistics.median(v) for k, v in bmed.items()}
tot = Counter()
for (d, b, p, bl), rs in g.items():
    for X in TH:
        z = zone(p, X)
        if z:
            tot[(X, period(d), z)] += len(rs)
legals = A["legals"]; master = A["master"]
apt = lambda a: (a or "").split(",", 1)[1].strip() if "," in (a or "") else ""
dd = lambda s: date.fromisoformat(s[:10])


def classify(d, b, bl, rs):
    lots = sorted({str(r["lot"]).strip() for r in rs})
    if len(lots) == 1:
        if len({r["address"] for r in rs}) == 1 or len({apt(r["address"]) for r in rs}) == 1:
            return "same_lot_same_address"
        m = bmed.get((b, bl, lots[0]))
        return "coop_apartments_bulk_price" if m and int(float(rs[0].get("sale_price") or 0)) >= 2 * m else "coop_apartments_unit_price"
    docs = defaultdict(set)
    for l in legals.get(f"{b}|{bl}", []):
        m = master.get(l["document_id"])
        if m and m.get("document_date") and abs((dd(m["document_date"]) - dd(d)).days) <= 30:
            docs[l["document_id"]].add(str(l["lot"]).strip())
    if any(set(lots) <= v for v in docs.values()):
        return "one_acris_deed"
    if docs:
        return "separate_acris_deeds" if all(any(l in v for v in docs.values()) for l in lots) else "partly_found"
    return "not_found"


removed = Counter(); kinds = Counter(); kinds_rows = Counter(); kz = Counter()
for (d, b, p, bl), rs in g.items():
    if len(rs) < 2:
        continue
    for X in TH:
        z = zone(p, X)
        if not z:
            continue
        k = classify(d, b, bl, rs)
        removed[(X, period(d), z)] += len(rs) - 1
        kinds[(X, k)] += 1; kinds_rows[(X, k)] += len(rs) - 1
        kz[(X, period(d), z, k)] += len(rs) - 1
out = {"removed": {}, "groups_by_kind": {}, "rows_removed_by_kind": {}, "rows_removed_by_zone_and_kind": {}}
for (X, per, z, k), n in sorted(kz.items()):
    out["rows_removed_by_zone_and_kind"].setdefault(str(X), {}).setdefault(per, {}).setdefault(z, {})[k] = n
for (X, per, z), n in sorted(removed.items()):
    out["removed"].setdefault(str(X), {}).setdefault(per, {})[z] = {"removed": n, "rows": tot[(X, per, z)], "share": n / tot[(X, per, z)]}
for (X, k), n in sorted(kinds.items()):
    out["groups_by_kind"].setdefault(str(X), {})[k] = n
    out["rows_removed_by_kind"].setdefault(str(X), {})[k] = kinds_rows[(X, k)]
(ROOT / "output/deed_merge_check.json").write_text(json.dumps(out, indent=1))
for X in map(str, TH):
    for per in ("pre", "post"):
        print(X, per, {z: (v["removed"], v["rows"], round(100 * v["share"], 1)) for z, v in out["removed"][X].get(per, {}).items()})
    print("  groups:", out["groups_by_kind"][X], "rows removed:", out["rows_removed_by_kind"][X])
    for z, v in out["rows_removed_by_zone_and_kind"][X].get("post", {}).items():
        print("   post", z, v)

# Supplemental Appendix Table A14
K = [("one_acris_deed", "All lots on one recorded deed (ACRIS)"), ("same_lot_same_address", "Repeated rows for one unit"),
     ("coop_apartments_bulk_price", "Co-op apartments, bulk price"), ("separate_acris_deeds", "Separate recorded deeds"),
     ("coop_apartments_unit_price", "Co-op apartments, unit price"), ("not_found", "No deed found in ACRIS")]
RK = out["rows_removed_by_kind"]; ZK = out["rows_removed_by_zone_and_kind"]
fmt = lambda n: f"{n:,}".replace(",", "{,}")
lines = []
for k, lab in K:
    cells = [fmt(RK[X].get(k, 0)) for X in map(str, TH)]
    above = [fmt(ZK[X].get("post", {}).get("above", {}).get(k, 0)) for X in ("3000000", "5000000")]
    lines.append(f"{lab} & " + " & ".join(cells) + " & " + " & ".join(above) + " \\\\")
tots = [fmt(sum(RK[X].values()) - RK[X].get("partly_found", 0)) for X in map(str, TH)]
ta = [fmt(sum(v for k, v in ZK[X].get("post", {}).get("above", {}).items() if k != "partly_found")) for X in ("3000000", "5000000")]
pp = {X: (sum(v["removed"] for v in out["removed"][X]["pre"].values()) / 3.25, sum(v["removed"] for v in out["removed"][X]["post"].values()) / 6) for X in map(str, TH)}
tab = r"""\begin{center}
\textbf{Table A14:} What the one-row-per-deed rule removes near the thresholds
\end{center}
\vspace{-6pt}
\begin{center}
\singlespacing\footnotesize
\begin{tabular}{lcccccc}
\toprule
 & \multicolumn{4}{c}{Rows removed within 10\% of} & \multicolumn{2}{c}{In $(X, 1.05X)$, post-reform} \\
\cmidrule(lr){2-5}\cmidrule(l){6-7}
Removed rows belong to & \$1M & \$2M & \$3M & \$5M & \$3M & \$5M \\
\midrule
""" + "\n".join(lines) + r"""
\midrule
All & """ + " & ".join(tots) + " & " + " & ".join(ta) + r""" \\
Removed a year, before / after & """ + " & ".join(f"{pp[X][0]:.0f} / {pp[X][1]:.0f}" for X in map(str, TH)) + r""" & & \\
\bottomrule
\end{tabular}
\notes{\textit{Notes.} Rows of the sales file removed by the rule of Section 3.1 of the paper (one row per sale date, borough, tax block and price) in groups priced within 10\% of each threshold, all periods. Groups whose rows carry different lots are checked against ACRIS: all lots listed on one deed dated within 30 days of the sale date, or on separate deeds. Groups on one lot are repeated rows for one unit when the address or apartment is the same; otherwise they are co-operative apartments in one building, whose share sales ACRIS does not record, and are classed as a bulk price when the price is at least twice the median of the building's other, unrepeated sales. Staten Island groups on several lots are among those with no deed found, because ACRIS does not cover the borough. Replication package, \texttt{deed\_merge\_check.py}, from \texttt{data/acris\_merge\_check.json}.}
\end{center}
"""
(ROOT / "output/tab_merge.tex").write_text(tab)
