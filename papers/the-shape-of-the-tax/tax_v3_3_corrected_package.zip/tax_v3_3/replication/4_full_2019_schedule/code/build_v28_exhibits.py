"""v1.11 (preprint v2.8): render Table 6, local incidence, unraveling and recorded-price elasticities,
from output/notch_elasticity.json and output/loan_notch.json. Writes output/tab_elasticity.tex."""
import json
from pathlib import Path
import numpy as np
from scipy.optimize import brentq

ROOT = Path(__file__).resolve().parents[1]
src = (ROOT / "code/notch_elasticity.py").read_text()
exec(compile(src[src.index("def gain"):src.index("# Self-check")], "notch_elasticity.py", "exec"))
D = json.loads((ROOT / "output/notch_elasticity.json").read_text())["thresholds"]
L = json.loads((ROOT / "output/loan_notch.json").read_text())["thresholds"]["500000"]


def f(x, dp=3):
    return f"{x:.{dp}f}".replace("-", "$-$")


def ci(c, dp=3):
    return f"[{f(c[0], dp)}, {f(c[1], dp)}]"


def usd(x):
    return ("$-$" if x < 0 else "") + f"\\${abs(x):,.0f}".replace(",", "{,}")


lab = {"1000000": "\\$1{,}000{,}000 (post level)", "2000000": "\\$2{,}000{,}000", "3000000": "\\$3{,}000{,}000", "5000000": "\\$5{,}000{,}000"}
rows = []
for X in ["2000000", "3000000", "5000000", "1000000"]:
    r = D[X]; km = r["kopczuk_munroe"]
    rows.append(f"{lab[X]} & {usd(r['jump_all_dollars'])} & {f(km['h_over_T']['est'], 2)} {ci(km['h_over_T']['ci'], 2)} & "
                f"{usd(km['Z_dollars']['est'])} [{usd(km['Z_dollars']['ci'][0])}, {usd(km['Z_dollars']['ci'][1])}] & "
                f"{f(r['pile']['e_all'])} {ci(r['pile']['e_all_ci'])} & {f(r['hole']['e_all'])} {ci(r['hole']['e_all_ci'])} \\\\")
el = {k: [elasticity(L[k] / 500_000, 1.80, 0.125)] + [elasticity(x / 500_000, 1.80, 0.125) for x in L["ci"][k]] for k in ("pile_dollars", "hole_dollars")}
loan = (f"\\$500{{,}}000 loan (MRT) & \\$625 & --- & --- & {f(el['pile_dollars'][0])} {ci(el['pile_dollars'][1:])} & "
        f"{f(el['hole_dollars'][0])} {ci(el['hole_dollars'][1:])} \\\\")
tab = r"""\begin{table}[htbp]
\centering
\caption{From bunching to behavioural parameters}
\label{tab:elasticity}
\singlespacing\scriptsize
\setlength{\tabcolsep}{2.5pt}
\begin{tabular}{lccccc}
\toprule
 & Jump & Local incidence & Unraveling & \multicolumn{2}{c}{Recorded-price elasticity} \\
\cmidrule(l){5-6}
Threshold & $T$ & $\hat h/T$ & $\hat Z$ & from the pile & from the hole \\
\midrule
""" + "\n".join(rows[:3]) + "\n\\addlinespace\n" + rows[3] + "\n" + loan + r"""
\bottomrule
\end{tabular}
\notes{\textit{Notes.} Widths are the excess mass below $X$ (pile) and the missing mass above it (hole), each divided by the counterfactual density at $X$; at the 2019 thresholds they are post-reform minus pre-reform, at \$1{,}000{,}000 the post-reform level. $T$ is the jump in all transfer taxes at $X$. Local incidence $\hat h$ is the pile width \citep{kopczuk2015}. $\hat Z$ is the hole width minus the pile width; $\hat Z>0$ indicates sales that leave the market rather than move below $X$. The elasticity is that of the recorded price with respect to one plus the transfer-tax rate, solved from the indifference condition of the marginal buncher \citep{kleven2013} with $1+t$ in place of $1-t$, all transfer taxes counted and no optimisation frictions. Counting only buyer-paid taxes changes the elasticities by at most 0.005 and doubles $\hat h/T$ at \$3{,}000{,}000 to 2.22. 95\% percentile intervals from 500 bootstrap draws that resample sales within $\pm0.2X$ in each period. The loan row applies the same elasticity to purchase-mortgage amounts (1.80\% below \$500{,}000, 1.925\% at or above, on the whole loan; 1{,}000-dollar bins, $\pm$\$100{,}000 window); local incidence and $\hat Z$ do not apply. Replication package v1.12, \texttt{notch\_elasticity.py}, \texttt{loan\_notch.py}.}
\end{table}
"""
(ROOT / "output/tab_elasticity.tex").write_text(tab)
print(tab)
