"""v1.12: the Kopczuk-Munroe (2015) unraveling test with their counterfactual.

Kopczuk and Munroe fit the counterfactual with a third-degree polynomial plus
a level shift for prices at or above the threshold, so that the counterfactual
above X already absorbs the ordinary extensive-margin response. Bunching I is
the excess below X, the gap G is the shortfall above X against the shifted
counterfactual, local incidence h is I divided by the smooth counterfactual
density just below X, and Z = h (G / I - 1), in dollars. Z > 0 means more sales
are missing above X than bunch below it, which they read as local unraveling.

Post-reform sales (from 2020) at $1M, $2M and $3M, with the paper's bins and
round-number indicators and a lower exclusion of 0.025X. The grid varies the
fitting window (+/-0.2X, 0.3X, 0.4X) and the upper limit of the excluded range
(+0.05X as in the paper, +0.10X, and +0.155X, the limit Kopczuk and Munroe
used at $1M). The $5M market is too thin for this estimator. A 500-draw
bootstrap interval is reported for the specification closest to theirs
(window 0.4X, upper limit 0.155X). Writes output/km_unraveling.json.
"""
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
TE = {"__file__": str(ROOT / "code/threshold_extension.py")}
exec(compile((ROOT / "code/threshold_extension.py").read_text().split("\nout = {}")[0], "threshold_extension.py", "exec"), TE)
price, POST, round_dummies = TE["price"], TE["POST"], TE["round_dummies"]
rng = np.random.default_rng(20261012)
WINDOWS, UPPERS = (0.2, 0.3, 0.4), (0.05, 0.10, 0.155)


def km(p, X, window_share, above, deg=3):
    bw = max(b for b in (10_000, 25_000, 50_000, 100_000) if b <= max(10_000, 0.005 * X))
    window, below = window_share * X, 0.025 * X
    lo, hi = X - window, X + window
    s = p[(p >= lo) & (p < hi)]
    edges = np.arange(lo, hi + bw / 2, bw)
    cnt, _ = np.histogram(s, bins=edges)
    mid = edges[:-1] + bw / 2
    excl = (mid > X - below) & (mid < X + above * X)
    shift = (mid > X).astype(float)
    poly = np.column_stack([((mid - X) / window) ** k for k in range(deg + 1)])
    Xm = np.column_stack([poly, shift, round_dummies(mid, bw)])
    beta, *_ = np.linalg.lstsq(Xm[~excl], cnt[~excl], rcond=None)
    cf = Xm @ beta
    b, a = excl & (mid < X), excl & (mid > X)
    I, G = float((cnt[b] - cf[b]).sum()), float((cf[a] - cnt[a]).sum())
    h0 = float((poly @ beta[:deg + 1])[int(np.searchsorted(mid, X)) - 1] / bw)
    h = I / h0
    return {"I": I, "G": G, "h_dollars": h, "Z_dollars": h * (G / I - 1) if I > 0 else float("nan")}


out = {"grid": {}, "closest_to_kopczuk_munroe": {}}
for X in (1_000_000, 2_000_000, 3_000_000):
    g = {}
    for w in WINDOWS:
        sample = price[POST][(price[POST] >= (1 - w) * X) & (price[POST] < (1 + w) * X)]
        for u in UPPERS:
            g[f"window_{w:g}_upper_{u:g}"] = km(sample, X, w, u)
    out["grid"][str(X)] = g
    sample = price[POST][(price[POST] >= 0.6 * X) & (price[POST] < 1.4 * X)]
    pt = g["window_0.4_upper_0.155"]
    dr = np.array([km(rng.choice(sample, len(sample)), X, 0.4, 0.155)["Z_dollars"] for _ in range(500)])
    dr = dr[np.isfinite(dr)]
    out["closest_to_kopczuk_munroe"][str(X)] = {**pt, "Z_ci": np.percentile(dr, [2.5, 97.5]).tolist(), "share_draws_Z_positive": float((dr > 0).mean())}
    zs = [v["Z_dollars"] for v in g.values()]
    print(f"{X:>10,} Z over grid: min {min(zs):>10,.0f} max {max(zs):>10,.0f}, positive in {sum(z > 0 for z in zs)} of {len(zs)}; "
          f"KM-like {pt['Z_dollars']:,.0f} {np.round(out['closest_to_kopczuk_munroe'][str(X)]['Z_ci'], 0)}")
(ROOT / "output/km_unraveling.json").write_text(json.dumps(out, indent=1))
