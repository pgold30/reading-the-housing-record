"""v1.7: render the paper's cost table (output/tab_cost.tex) and Supplemental
Tables A8 (sponsor sales in detail) and A9 (loan-to-value test with
condominium loans) from output/cost_and_sponsors.json."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
R = json.loads((ROOT / "output/cost_and_sponsors.json").read_text())
rev, S, L = R["revenue"], R["sponsor"], R["liquidity_with_condos"]
money = lambda x: "\\$" + f"{x:,.0f}".replace(",", "{,}")
f3 = lambda v: f"$+{v:.3f}$" if v >= 0 else f"$-{abs(v):.3f}$"
f0 = lambda v: f"${v:+.0f}$".replace("-", "-") if v < 0 else f"${v:.0f}$"
ci0 = lambda c: f"[{sg(c[0], 0)}, {sg(c[1], 0)}]".replace("$+$", "")
m2 = lambda v: f"{v / 1e6:.2f}"
sg = lambda v, d: ("$-$" if round(v, d) < 0 else "$+$" if round(v, d) > 0 else "") + f"{abs(v):.{d}f}"

rows = []
for x in ["1000000", "2000000", "3000000", "5000000"]:
    v = rev["by_threshold"][x]
    lab = money(int(x)) + (" (control)" if x == "1000000" else "")
    tax = "---" if x == "1000000" else f"{m2(v['avoided_tax_per_year'])} [{m2(v['avoided_tax_per_year_ci'][0])}, {m2(v['avoided_tax_per_year_ci'][1])}]"
    upper = "---" if x == "1000000" else m2(v["avoided_tax_upper_per_year"])
    rows.append(f"{lab} & {money(v['jump_dollars']) if v['jump_dollars'] else '---'} & {v['excess_sales_per_year']:.0f} {ci0(v['excess_sales_per_year_ci'])} & "
                f"{sg(v['missing_minus_excess_per_year'], 0)} {ci0(v['missing_minus_excess_per_year_ci'])} & {tax} & {upper} \\\\".replace("+-", "-"))
tot = (f"\\textbf{{Total, new thresholds}} & & & & \\textbf{{{m2(rev['avoided_total_per_year'])}}} "
       f"[{m2(rev['avoided_total_per_year_ci'][0])}, {m2(rev['avoided_total_per_year_ci'][1])}] & \\textbf{{{m2(rev['avoided_total_upper_per_year'])}}} \\\\")
cost = r"""\begin{table}[htbp]
\centering
\caption{What the 2019 notches cost in avoided tax}
\label{tab:cost}
\singlespacing\footnotesize
\setlength{\tabcolsep}{3.5pt}
\begin{tabular}{lccccc}
\toprule
 & Jump & Extra sales just & Missing minus & \multicolumn{2}{c}{Tax avoided, \$M a year} \\
\cmidrule(l){5-6}
Threshold & at $X$ & below $X$, a year & extra, a year & At the jump & $0.05X$ price cut \\
\midrule
""" + "\n".join(rows) + "\n\\midrule\n" + tot + r"""
\bottomrule
\end{tabular}
\notes{\textit{Notes.} Post-reform period, January 2020 to December 2025. Extra sales just below $X$ are the excess mass in $(0.975X, X)$ after the reform minus the pre-reform excess rescaled to the post-reform counterfactual density; missing minus extra is the corresponding missing mass in $(X, 1.05X)$ less that excess. Estimator and windows as in Table~\ref{tab:fullschedule}; 95\% bootstrap intervals in brackets. Each extra sale avoids at least the statutory jump at $X$ (at \$3{,}000{,}000 the buyer's 0.25 points and the seller's 0.25-point base-rate rise). The tax figures assume that the extra sales below each threshold relocated from above it; the intervals cover sampling uncertainty conditional on the estimator and that assumption. The $0.05X$ price-cut column is a scenario, not an identified bound: it assumes each extra sale also cut its price by the emptied range, $0.05X$, and adds every ad-valorem transfer tax on that reduction. The reform's schedule (the supplemental tax and the base-rate rise) implies """ + f"\\${rev['collected_reform_tax_2M_6M_per_year'] / 1e6:.1f}" + r""" million a year on the """ + f"{rev['post_sales_2M_6M_per_year']:,.0f}".replace(",", "{,}") + r""" sales a year between \$2{,}000{,}000 and \$6{,}000{,}000. At the \$1{,}000{,}000 control, whose tax did not change, the extra sales are within the range of the never-taxed placebos. Replication package v1.12, \texttt{cost\_and\_sponsors.py}.}
\end{table}
"""
(ROOT / "output/tab_cost_v24.tex").write_text(cost)  # v1.12: the paper's cost table is now rendered by build_v29_exhibits.py
print(cost)

# Table A8: sponsor sales in detail
SUB = [("All sales, no company seller", S["all_resale"]), ("All sales, company seller", S["all_sponsor"]),
       ("Condominiums, no company seller", S["condo_resale"]), ("Condominiums, company seller", S["condo_sponsor"]),
       ("Condominiums, company seller, post-period 2022--2025", S["condo_sponsor_post_2022_2025"]),
       ("Condominiums in buildings at most three years old", S["condo_new_building"]), ("Condominiums in older buildings", S["condo_older_building"])]
fl = []
for lab, h in SUB:
    fl.append(f"\\multicolumn{{5}}{{l}}{{\\textit{{{lab}}} (placebo SD {h['placebo_kw_sd']:.3f})}}\\\\")
    for x in ["1000000", "2000000", "3000000", "5000000"]:
        v = h[x]
        fl.append(f"\\quad {money(int(x))} & {v['window_n_pre']:,}/{v['window_n_post']:,} & {f3(v['kw_diff'])} ({v['placebos_as_large']}) & {f3(v['logR_change'])} ({v['placebos_as_low_R']}) & {v['z']:+.1f} \\\\".replace(",", "{,}").replace("{{,}}", "{,}"))
sh = S["share_sponsor_in_condo_windows"]
shares = "; ".join(f"{money(int(x))}, {100 * v['pre']:.0f}\\% before and {100 * v['post']:.0f}\\% after" for x, v in sh.items())
a8 = r"""\begin{center}
\textbf{Table A8:} Sales with and without a company seller
\end{center}
{\small\begin{tabular}{lcccc}
\toprule
 & Sales in window & Bunching, post $-$ pre & $\Delta\log R$ & $z$ against \\
 & pre/post & (placebos as large) & (placebos as low) & placebo SD \\
\midrule
""" + "\n".join(fl) + r"""
\bottomrule
\end{tabular}}

\noindent{\footnotesize A company seller on the linked deed is a proxy that includes sponsor (developer) sales and other company sales; sales without a linked deed are in neither group. Buildings at most three years old use the Department of Finance year built. Share of condominium window sales with a company seller: """ + shares + r""". Placebo counts are out of sixteen, computed within each row's sample. Source: \texttt{cost\_and\_sponsors.py}.}
"""
(ROOT / "output/tab_sponsor.tex").write_text(a8)

# Table A9: liquidity test with condominium loans
sg = lambda v, d: ("$-$" if round(v, d) < 0 else "$+$" if round(v, d) > 0 else "") + f"{abs(v):.{d}f}"
se = lambda b: f"{sg(100 * b[0], 1)} ({100 * b[1]:.1f})"
lr = []
for lab, k in [("Houses (as in the paper)", "houses"), ("Condominiums", "condominiums"), ("Houses and condominiums", "houses_and_condominiums"),
               ("Seller-paid \\$500{,}000 notch (placebo)", "seller_paid_500k_both")]:
    m = L[k]
    lr.append(f"{lab} & {m['n']:,} & {100 * m['charm_share']:.1f} & {se(m['per_10pts'][0]['ltv10'])} & {se(m['ltv_ge_80'][0]['high_ltv'])} \\\\".replace(",", "{,}").replace("{{,}}", "{,}"))
a9 = r"""\begin{center}
\textbf{Table A9:} Loan-to-value and the charm price, with condominium loans
\end{center}
{\small\begin{tabular}{lcccc}
\toprule
Financed purchases at $X-1$ or $X$ & $N$ & Charm (\%) & Per 10 LTV points & LTV $\geq$ 80\% \\
\midrule
""" + "\n".join(lr) + r"""
\bottomrule
\end{tabular}}

\noindent{\footnotesize Linear probability of a price of $X-1$, in percentage points, with threshold and year effects (and a condominium effect where both types are pooled); standard errors clustered by parcel in parentheses. Buyer-paid thresholds \$1{,}000{,}000, \$2{,}000{,}000 and \$3{,}000{,}000; the \$500{,}000 row pools houses and condominiums at the seller-paid notch. Condominium loans come from \texttt{data/condo\_loans.csv.gz}, matched as in the costing. Source: \texttt{cost\_and\_sponsors.py}.}
"""
(ROOT / "output/tab_ltv_condo.tex").write_text(a9)
print(a8); print(a9)
