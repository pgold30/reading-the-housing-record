"""v2.0: one row per deed.

one_per_deed(date, borough, price) returns a boolean mask that keeps, within each
group of rows sharing a sale date, borough and price, as many rows as the group
has distinct tax blocks (data/deed_groups.csv.gz, built by build_deed_groups.py).
Rows outside a repeated group are always kept. Within a group the first rows in
file order are kept. The analysis uses one row per deed throughout; setting
SHAPE_ALL_ROWS=1 in the environment keeps every row, as the sales file is
published.
"""
import csv, gzip, os
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
ALL_ROWS = os.environ.get("SHAPE_ALL_ROWS") == "1"


def _groups():
    g = {}
    for r in csv.DictReader(gzip.open(ROOT / "data/deed_groups.csv.gz", "rt")):
        g[(r["sale_date"], r["borough"], r["sale_price"])] = (int(r["n_rows"]), int(r["n_deeds"]))
    return g


def one_per_deed(date, borough, price):
    g = _groups()
    seen = {}
    keep = np.ones(len(price), bool)
    for i, (d, b, p) in enumerate(zip(date, borough, price)):
        k = (str(d)[:10], str(int(float(b))), str(int(float(p or 0))))
        if k in g:
            c = seen.get(k, 0)
            keep[i] = c < g[k][1]
            seen[k] = c + 1
    bad = [k for k, c in seen.items() if c != g[k][0]]
    assert not bad, f"{len(bad)} groups do not match deed_groups.csv.gz"
    return keep


def linked_rows(all_rows=None):
    """The deposited linked sales file (data/linked_fields.csv.gz), one row per deed unless all_rows."""
    all_rows = ALL_ROWS if all_rows is None else all_rows
    rows = list(csv.DictReader(gzip.open(ROOT / "data/linked_fields.csv.gz", "rt")))
    if all_rows:
        return rows
    m = one_per_deed([r["sale_date"] for r in rows], [r["borough"] or 0 for r in rows], [float(r["sale_price"] or 0) for r in rows])
    return [r for r, k in zip(rows, m) if k]
