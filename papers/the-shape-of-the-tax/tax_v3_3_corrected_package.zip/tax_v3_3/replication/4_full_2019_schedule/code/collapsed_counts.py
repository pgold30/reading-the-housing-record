"""v2.0: the just-below count (Supplemental Table A3) on one row per deed and on
every row of the sales file. S = N[0.99X, X) / N[0.99X, 1.01X); post-minus-pre
log change with a Poisson interval, as in threshold_extension.py. Above $10M
most rows of the sales file repeat a multi-lot deed. Writes
output/collapsed_counts.json."""
import json
from pathlib import Path
import numpy as np
import importlib.util as _ilu

ROOT = Path(__file__).resolve().parents[1]
_spec = _ilu.spec_from_file_location("deeds", Path(__file__).resolve().parent / "deeds.py")
deeds = _ilu.module_from_spec(_spec); _spec.loader.exec_module(deeds)
n = lambda p, lo, hi: int(((p >= lo) & (p < hi)).sum())
out = {}
data = {}
for lab, allr in (("deeds", False), ("all_rows", True)):
    rows = deeds.linked_rows(all_rows=allr)
    p = np.array([float(r["sale_price"] or 0) for r in rows]); d = np.array([r["sale_date"][:10] for r in rows])
    data[lab] = (p[d < "2019-04-01"], p[d >= "2020-01-01"])
for X in (2_000_000, 3_000_000, 5_000_000, 10_000_000, 15_000_000, 20_000_000, 25_000_000, 4_000_000, 7_000_000, 8_000_000):
    res = {}
    for lab, (a, b) in data.items():
        c = [n(a, 0.99 * X, X), n(a, X, 1.01 * X), n(b, 0.99 * X, X), n(b, X, 1.01 * X)]
        if min(c) == 0:
            res[lab] = {"counts": c, "S_logdiff": None}
            continue
        est = float(np.log(c[2] / c[3]) - np.log(c[0] / c[1])); se = float(np.sqrt(sum(1 / v for v in c)))
        res[lab] = {"counts": c, "S_logdiff": est, "ci": [est - 1.96 * se, est + 1.96 * se]}
    out[str(X)] = res
    print(f"{X:>11,} " + " | ".join(f"{lab} {v['counts']} " + (f"{v['S_logdiff']:+.2f} [{v['ci'][0]:+.2f}, {v['ci'][1]:+.2f}]" if v['S_logdiff'] is not None else "n/a") for lab, v in res.items()))
(ROOT / "output/collapsed_counts.json").write_text(json.dumps(out, indent=1))
