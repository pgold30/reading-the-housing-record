"""v1.5: year-by-year event study of the 2019 notches.

For each calendar year 2016-2025 and each price point, two statistics:
  - KW: the Kleven-Waseem share of counterfactual mass missing above X
    (scaled estimator of Table 5, unchanged);
  - log R: log of N[X, 1.05X) / N[0.925X, 0.975X), no counterfactual fitted.
Each series is normalised to its own 2016-2018 mean, so a price point's fixed
focal-price behaviour drops out. 2019 is the transition year (contracts signed
by 1 April 2019 were grandfathered) and is shown but not used in any test.

Null bands. For a treated threshold T, every eligible never-taxed placebo
(placebo_inference.py, scaled set) whose window has at least as many sales as
T's in every year is subsampled to T's yearly counts, K times; each draw is
normalised the same way. The band is the 5th-95th percentile of those draws.
The $1M control has more sales than any placebo, so its band uses, without
subsampling, the placebos with at least half its sales; with fewer sales per
year, that band is somewhat wider than a matched one would be.

Pre-trend test (a fake reform date). With the reform moved back to January
2018, the scaled bunching change 2018 minus 2016-2017 is computed at each
treated threshold and compared with the same statistic at size-matched
placebos. Output: output/event_study.json, output/Figure_7.pdf/.png.
"""
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
TE = {"__file__": str(ROOT / "code/threshold_extension.py")}
exec(compile((ROOT / "code/threshold_extension.py").read_text().split("\nout = {}")[0], "threshold_extension.py", "exec"), TE)
PI = json.loads((ROOT / "output/placebo_inference.json").read_text())
price, date = TE["price"], TE["date"]
year = np.array([int(d[:4]) for d in date])
kw = TE["kw"]
YEARS = list(range(2016, 2026))
BASE = [2016, 2017, 2018]
TREATED = [2_000_000, 3_000_000, 5_000_000]
CONTROL = 1_000_000
PLACEBOS = PI["scaled"]["placebos_extended"]
K = 40
rng = np.random.default_rng(20260927)


def window(p, x):
    return p[(p >= 0.8 * x) & (p < 1.2 * x)]


def logR(p, x):
    a = ((p >= x) & (p < 1.05 * x)).sum(); b = ((p >= 0.925 * x) & (p < 0.975 * x)).sum()
    return float(np.log(a / b)) if a > 0 and b > 0 else np.nan


def series(samples, x):
    """samples: {year: prices in x's window}. Returns normalised KW and log R by year."""
    k = {y: kw(samples[y], x)[0] for y in YEARS}; r = {y: logR(samples[y], x) for y in YEARS}
    kb, rb = np.nanmean([k[y] for y in BASE]), np.nanmean([r[y] for y in BASE])
    return {y: k[y] - kb for y in YEARS}, {y: r[y] - rb for y in YEARS}


by_year = {y: price[year == y] for y in YEARS}
out = {"years": YEARS, "base_years": BASE, "K": K, "seed": 20260927, "thresholds": {}}
for T in [CONTROL] + TREATED:
    own = {y: window(by_year[y], T) for y in YEARS}
    k_obs, r_obs = series(own, T)
    counts = {y: len(own[y]) for y in YEARS}
    kd, rd, used = [], [], []
    for x in PLACEBOS:
        pw = {y: window(by_year[y], x) for y in YEARS}
        if T == CONTROL:   # unmatched; only placebos with at least half the control's sales
            if len(window(price, x)) < 0.5 * len(window(price, T)):
                continue
            kx, rx = series(pw, x); kd.append([kx[y] for y in YEARS]); rd.append([rx[y] for y in YEARS]); used.append(x)
            continue
        if any(len(pw[y]) < counts[y] for y in YEARS):
            continue
        used.append(x)
        for _ in range(K):
            sub = {y: rng.choice(pw[y], counts[y], replace=True) for y in YEARS}
            kx, rx = series(sub, x); kd.append([kx[y] for y in YEARS]); rd.append([rx[y] for y in YEARS])
    kd, rd = np.array(kd), np.array(rd)
    band = lambda D: {y: [float(np.nanpercentile(D[:, i], 5)), float(np.nanpercentile(D[:, i], 95))] for i, y in enumerate(YEARS)}
    out["thresholds"][str(T)] = {
        "window_counts": counts, "placebos_used": used, "matched": T != CONTROL,
        "kw": {str(y): float(k_obs[y]) for y in YEARS}, "logR": {str(y): float(r_obs[y]) for y in YEARS},
        "kw_band90": {str(y): v for y, v in band(kd).items()}, "logR_band90": {str(y): v for y, v in band(rd).items()},
        "post_years_kw_above_band": int(sum(k_obs[y] > np.nanpercentile(kd[:, i], 95) for i, y in enumerate(YEARS) if y >= 2020)),
        "post_years_logR_below_band": int(sum(r_obs[y] < np.nanpercentile(rd[:, i], 5) for i, y in enumerate(YEARS) if y >= 2020)),
        "base_years_kw_outside_band": int(sum(not (np.nanpercentile(kd[:, i], 5) <= k_obs[y] <= np.nanpercentile(kd[:, i], 95))
                                          for i, y in enumerate(YEARS) if y in BASE)),
    }

# Fake reform date: January 2018. Change 2018 vs 2016-2017, scaled estimator.
fake = {}
A, B = (year == 2016) | (year == 2017), year == 2018
for T in [CONTROL] + TREATED:
    wa, wb = window(price[A], T), window(price[B], T)
    stat = kw(wb, T)[0] - kw(wa, T)[0]
    draws = []
    for x in PLACEBOS:
        pa, pb = window(price[A], x), window(price[B], x)
        if T == CONTROL:
            if len(window(price, x)) < 0.5 * len(window(price, T)):
                continue
            draws.append(kw(pb, x)[0] - kw(pa, x)[0]); continue
        if len(pa) < len(wa) or len(pb) < len(wb):
            continue
        draws += [kw(rng.choice(pb, len(wb), replace=True), x)[0] - kw(rng.choice(pa, len(wa), replace=True), x)[0] for _ in range(K)]
    draws = np.array(draws)
    fake[str(T)] = {"kw_2018_minus_2016_17": float(stat), "null_p05_p95": [float(np.percentile(draws, 5)), float(np.percentile(draws, 95))],
                    "p_two_sided": float(np.mean(np.abs(draws - np.median(draws)) >= abs(stat - np.median(draws)))),
                    "n_2016_17": int(len(wa)), "n_2018": int(len(wb))}
out["fake_reform_2018"] = fake
(ROOT / "output/event_study.json").write_text(json.dumps(out, indent=1))

for T in [CONTROL] + TREATED:
    t = out["thresholds"][str(T)]
    print(f"\n{T:,}  placebos {len(t['placebos_used'])}  post years KW above band {t['post_years_kw_above_band']}/6, "
          f"log R below band {t['post_years_logR_below_band']}/6, base years KW outside band {t['base_years_kw_outside_band']}/3")
    print("   year   KW    band90          logR   band90")
    for y in YEARS:
        kb, rb = t["kw_band90"][str(y)], t["logR_band90"][str(y)]
        print(f"   {y} {t['kw'][str(y)]:+.3f} [{kb[0]:+.3f},{kb[1]:+.3f}]  {t['logR'][str(y)]:+.3f} [{rb[0]:+.3f},{rb[1]:+.3f}]")
print("\nfake reform (Jan 2018):", json.dumps(fake, indent=1))

# Figure 7
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
BLUE, GREY, INK = "#1a6fa0", "#c9ced6", "#1b1f24"
plt.rcParams.update({"font.family": "serif", "font.size": 8.5, "axes.spines.top": False, "axes.spines.right": False})
fig, axes = plt.subplots(2, 4, figsize=(10, 4.9), sharex=True, sharey="row")
titles = {CONTROL: "$1,000,000 (taxed since 1989)", 2_000_000: "$2,000,000 (new in 2019)",
          3_000_000: "$3,000,000 (new in 2019)", 5_000_000: "$5,000,000 (new in 2019)"}
for c, T in enumerate([CONTROL] + TREATED):
    t = out["thresholds"][str(T)]
    for r, (key, bkey, lab) in enumerate([("kw", "kw_band90", "Bunching (share missing above X)"),
                                            ("logR", "logR_band90", "log R: sales just above / below")]):
        ax = axes[r, c]
        lo = [t[bkey][str(y)][0] for y in YEARS]; hi = [t[bkey][str(y)][1] for y in YEARS]
        ax.fill_between(YEARS, lo, hi, color=GREY, alpha=.7, lw=0, label="90% placebo band")
        ax.axhline(0, color="#8a9099", lw=.6)
        ax.axvspan(2018.5, 2019.5, color="#eef0f3", lw=0)
        v = [t[key][str(y)] for y in YEARS]
        ax.plot([y for y in YEARS if y != 2019], [x for y, x in zip(YEARS, v) if y != 2019], "o-", color=BLUE, ms=4, lw=1.4)
        ax.plot([2019], [v[YEARS.index(2019)]], "o", mfc="white", mec=BLUE, ms=4)
        if r == 0: ax.set_title(titles[T], fontsize=8.5, color=INK)
        if c == 0: ax.set_ylabel(lab, fontsize=8)
        ax.set_xticks([2016, 2018, 2020, 2022, 2024])
        ax.tick_params(labelsize=7.5)
axes[0, 0].legend(frameon=False, fontsize=7, loc="upper left")
fig.tight_layout()
for ext in ("pdf", "png"):
    fig.savefig(ROOT / f"output/Figure_7.{ext}", dpi=200)
print("wrote output/event_study.json and Figure_7")
