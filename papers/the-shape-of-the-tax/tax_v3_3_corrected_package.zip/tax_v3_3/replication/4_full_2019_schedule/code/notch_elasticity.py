"""Notch elasticity: turn the bunching widths into a structural elasticity.

The widths come from market_splits.py (kw_parts): the excess mass below
X (B) and the missing mass above X (M), each divided by the counterfactual
density at X, post-reform minus pre-reform. Either width is an estimate of
dP*, the price response of the marginal buncher (Kleven and Waseem 2013): the
pile measures it from the sales that arrive below X, the hole from the sales
that leave the range above X. The two differ when sales disappear rather than
move, so both are reported.

Model. A buyer of type n chooses the recorded price P to maximise
    v(P) - (1 + t(P)) P,   v(P) = n^(1/e) P^(1 - 1/e) / (1 - 1/e),
so P = n (1 + t)^(-e) and e is the elasticity of the recorded price with
respect to the tax-inclusive price factor 1 + t. With a notch, t jumps from
t0 to t0 + dt on the whole price at X. The marginal buncher, whose price
without the notch would be X + dP*, is indifferent between X and its interior
optimum above X. Given dP*/X, t0 and dt, that indifference condition pins
down e (solved numerically below). This is the Kleven-Waseem condition with
1 + t in place of 1 - t. It ignores optimisation frictions (which would make
the implied e larger) and treats relabelled value (credits, personal
property) as a price response, so e is an elasticity of the recorded price.

Tax rates (percentage points of price, TSB-M-19(1)R; NYC Admin. Code
11-2102): t0 is the transfer-tax rate just below X, either buyer-paid only
or all transfer taxes (buyer and seller) because incidence is not known.
Pre = before 1 Apr 2019; post = from 1 Jan 2020. Intervals: percentile
bootstrap, resampling sales within the +/-0.2X window in each period.
Writes output/notch_elasticity.json.
"""
import json
from pathlib import Path
import numpy as np
from scipy.optimize import brentq

ROOT = Path(__file__).resolve().parents[1]
TE = {"__file__": str(ROOT / "code/threshold_extension.py")}
exec(compile((ROOT / "code/threshold_extension.py").read_text().split("\nout = {}")[0], "threshold_extension.py", "exec"), TE)
price, PRE, POST, round_dummies = TE["price"], TE["PRE"], TE["POST"], TE["round_dummies"]
rng = np.random.default_rng(20261009)
R = 500

# X: (t0 buyer-paid, dt buyer-paid, t0 all transfer taxes, dt all transfer taxes), percent of price.
# All-taxes t0 adds the NYC RPTT (1.425) and the state tax (0.4; 0.65 for residential >= $3M) to the buyer's mansion rate.
RATES = {
    1_000_000: (0.0, 1.00, 1.825, 1.00),
    2_000_000: (1.0, 0.25, 2.825, 0.25),
    3_000_000: (1.25, 0.25, 3.075, 0.50),
    5_000_000: (1.5, 0.75, 3.575, 0.75),
}


def kw_parts(p, X, deg=5):
    """Identical to market_splits.py: B, M and counterfactual density h0 at X."""
    bw = max(b for b in (10_000, 25_000, 50_000, 100_000) if b <= max(10_000, 0.005 * X))
    window, below, above = 0.2 * X, 0.025 * X, 0.05 * X
    lo, hi = X - window, X + window
    sel = p[(p >= lo) & (p < hi)]
    edges = np.arange(lo, hi + bw / 2, bw)
    cnt, _ = np.histogram(sel, bins=edges)
    mid = edges[:-1] + bw / 2
    excl = (mid > X - below) & (mid < X + above)
    Xm = np.column_stack([((mid - X) / window) ** k for k in range(deg + 1)] + [round_dummies(mid, bw)])
    beta, *_ = np.linalg.lstsq(Xm[~excl], cnt[~excl], rcond=None)
    cf = Xm @ beta
    a, b = (mid > X) & (mid < X + above), (mid > X - below) & (mid < X)
    i = int(np.searchsorted(mid, X))
    h0 = float((cf[i - 1] + cf[i]) / 2 / bw)
    return float((cnt[b] - cf[b]).sum()), float((cf[a] - cnt[a]).sum()), h0


def widths(pre, post, X, differenced):
    """Pile and hole widths in dollars; reform-induced (post minus pre) or post-period level."""
    B1, M1, h1 = kw_parts(post, X)
    if not differenced:
        return B1 / h1, M1 / h1
    B0, M0, h0 = kw_parts(pre, X)
    return B1 / h1 - B0 / h0, M1 / h1 - M0 / h0


def gain(e, d, t0, dt):
    """Utility at the interior optimum above X minus utility at X, for the marginal buncher (X = 1)."""
    n = (1 + d) * (1 + t0) ** e
    v = (lambda P: n ** (1 / e) * P ** (1 - 1 / e) / (1 - 1 / e)) if abs(e - 1) > 1e-9 else (lambda P: n * np.log(P))
    PI = n * (1 + t0 + dt) ** (-e)
    return (v(PI) - (1 + t0 + dt) * PI) - (v(1.0) - (1 + t0))


def elasticity(d, t0, dt):
    """Solve the indifference condition for e given dP*/X = d; nan if no root in (1e-4, 200)."""
    if not np.isfinite(d) or d <= 0:
        return np.nan
    f = lambda e: gain(e, d, t0 / 100, dt / 100)
    lo, hi = 1e-4, 200.0
    if f(lo) * f(hi) > 0:
        return np.nan
    return float(brentq(f, lo, hi, xtol=1e-10))


# Self-check: at small notches the exact solution matches the second-order approximation e ~ d^2 (1+t0) / (2 dt).
for d, t0, dt in [(0.0005, 1.0, 0.0005), (0.0002, 3.0, 0.0001)]:
    approx = d ** 2 * (1 + t0 / 100) / (2 * dt / 100)
    assert abs(elasticity(d, t0, dt) / approx - 1) < 0.01, (d, elasticity(d, t0, dt), approx)

out = {"model": "recorded-price elasticity w.r.t. (1 + transfer-tax rate); Kleven-Waseem indifference condition; no frictions",
       "bootstrap_draws": R, "thresholds": {}}
for X, (tb, db, ta, da) in RATES.items():
    differenced = X != 1_000_000
    wpre = price[PRE][(price[PRE] >= 0.8 * X) & (price[PRE] < 1.2 * X)]
    wpost = price[POST][(price[POST] >= 0.8 * X) & (price[POST] < 1.2 * X)]
    pile, hole = widths(wpre, wpost, X, differenced)
    draws = []
    for _ in range(R):
        a, b = rng.choice(wpre, len(wpre)), rng.choice(wpost, len(wpost))
        draws.append(widths(a, b, X, differenced))
    draws = np.array(draws)
    res = {"differenced": differenced, "jump_buyer_dollars": db / 100 * X, "jump_all_dollars": da / 100 * X}
    for k, w, col in [("pile", pile, 0), ("hole", hole, 1)]:
        ci = np.percentile(draws[:, col], [2.5, 97.5])
        res[k] = {"width_dollars": w, "width_ci": ci.tolist(), "width_pct_of_X": 100 * w / X}
        for tax, t0, dt in [("buyer", tb, db), ("all", ta, da)]:
            e = elasticity(w / X, t0, dt)
            ed = np.array([elasticity(x / X, t0, dt) for x in draws[:, col]])
            ok = np.isfinite(ed)
            res[k]["e_" + tax] = e
            res[k]["e_" + tax + "_ci"] = np.percentile(ed[ok], [2.5, 97.5]).tolist() if ok.sum() > 0.9 * R else None
            res[k]["e_" + tax + "_valid_draws"] = int(ok.sum())
    # Kopczuk-Munroe (2015) quantities, in dollars of counterfactual density at X:
    #   local incidence h = pile width, reported relative to the jump T (all transfer taxes);
    #   unraveling Z = h (G/I - 1) = hole - pile; Z > 0 cannot be reconciled with seller bargaining power in [0, 1];
    #   if Z <= 0, seller bargaining power beta solves F0(X + beta T) - F0(X) = I - G, i.e. beta = (pile - hole) / T.
    T_all = da / 100 * X
    km = {"h_over_T": pile / T_all, "Z_dollars": hole - pile, "beta_if_no_unraveling": (pile - hole) / T_all}
    kd = {"h_over_T": draws[:, 0] / T_all, "Z_dollars": draws[:, 1] - draws[:, 0], "beta_if_no_unraveling": (draws[:, 0] - draws[:, 1]) / T_all}
    res["kopczuk_munroe"] = {k: {"est": float(v), "ci": np.percentile(kd[k], [2.5, 97.5]).tolist()} for k, v in km.items()}
    res["kopczuk_munroe"]["share_of_draws_Z_positive"] = float((kd["Z_dollars"] > 0).mean())
    out["thresholds"][str(X)] = res
    print("   KM: h/T {:.2f} [{:.2f}, {:.2f}]  Z ${:,.0f} [{:,.0f}, {:,.0f}]  beta {:.2f} [{:.2f}, {:.2f}]  P(Z>0) {:.2f}".format(
        km["h_over_T"], *res["kopczuk_munroe"]["h_over_T"]["ci"], km["Z_dollars"], *res["kopczuk_munroe"]["Z_dollars"]["ci"],
        km["beta_if_no_unraveling"], *res["kopczuk_munroe"]["beta_if_no_unraveling"]["ci"], res["kopczuk_munroe"]["share_of_draws_Z_positive"]))
    print(f"{X:>10,} {'reform-induced' if differenced else 'post level  '} jump b/all {db / 100 * X:>7,.0f}/{da / 100 * X:>7,.0f} | "
          + " | ".join(f"{k} {res[k]['width_dollars']:>8,.0f} [{res[k]['width_ci'][0]:>7,.0f}, {res[k]['width_ci'][1]:>7,.0f}] "
                       f"e_buyer {res[k]['e_buyer']:.3f} {np.round(res[k]['e_buyer_ci'], 3) if res[k]['e_buyer_ci'] else '-'} "
                       f"e_all {res[k]['e_all']:.3f} {np.round(res[k]['e_all_ci'], 3) if res[k]['e_all_ci'] else '-'}"
                       for k in ("pile", "hole")), flush=True)

(ROOT / "output/notch_elasticity.json").write_text(json.dumps(out, indent=1))
