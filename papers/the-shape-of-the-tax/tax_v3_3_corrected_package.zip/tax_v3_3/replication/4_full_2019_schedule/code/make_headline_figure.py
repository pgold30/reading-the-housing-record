"""v2.0: headline figure. Change in the distribution of recorded prices around $2M, $3M and $5M
before (Jan 2016-Mar 2019) and after (2020-2025) the 2019 reform, in $10,000
bins from 0.9X to 1.1X: each period's bins as a share of its window sales, after minus before.
Writes output/Figure_1_headline.pdf and .png, and output/headline_figure.json."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
TE = {"__file__": str(ROOT / "code/threshold_extension.py")}
exec(compile((ROOT / "code/threshold_extension.py").read_text().split("\nout = {}")[0], "threshold_extension.py", "exec"), TE)
price, PRE, POST = TE["price"], TE["PRE"], TE["POST"]
BLUE, RED, INK, MUTED = "#5b7fa6", "#c8423f", "#222222", "#6b6b6b"
BW = 10_000

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11, "axes.edgecolor": "#b0b0b0", "axes.linewidth": 0.8,
                     "xtick.color": MUTED, "ytick.color": MUTED, "axes.labelcolor": INK})
fig, axes = plt.subplots(1, 3, figsize=(9.6, 3.9), sharey=True)
summary = {}
titles = (r"\$2,000,000: jump \$5,000", r"\$3,000,000: jump \$15,000", r"\$5,000,000: jump \$37,500")
for ax, X, label in zip(axes, (2_000_000, 3_000_000, 5_000_000), titles):
    edges = np.arange(0.9 * X, 1.1 * X + BW / 2, BW)
    left = (edges[:-1] - X) / 1_000
    share = {}
    for name, m in (("pre", PRE), ("post", POST)):
        p = price[m]; w = p[(p >= 0.9 * X) & (p < 1.1 * X)]
        c, _ = np.histogram(w, bins=edges)
        share[name] = 100 * c / len(w)
    d = share["post"] - share["pre"]
    colors = [RED if v > 0 else BLUE for v in d]
    ax.bar(left + BW / 2000, d, width=BW / 1000 * 0.85, color=colors, zorder=2)
    ax.axhline(0, color="#9a9a9a", lw=0.8, zorder=1)
    ax.axvline(0, color=INK, lw=0.9, ls=(0, (3, 2)), zorder=3)
    below = (edges[:-1] >= X - BW) & (edges[:-1] < X)
    at = (edges[:-1] >= X) & (edges[:-1] < X + BW)
    ax.annotate(f"just below\n+{d[below][0]:.1f}", xy=(-BW / 1000, d[below][0] * 0.9), xytext=(-0.012 * X / 1000, d[below][0] * 0.9),
                fontsize=10, color=INK, va="center", ha="right")
    ax.annotate(f"from the\nthreshold {d[at][0]:.1f}".replace("-", "\u2212"), xy=(BW / 1000, d[at][0] * 0.9), xytext=(0.012 * X / 1000, d[at][0] * 0.9),
                fontsize=10, color=INK, va="center", ha="left")
    ax.set_title(label, fontsize=11.5, color=INK, loc="left")
    ax.set_xlabel("Price minus threshold (\\$000)")
    ax.grid(axis="y", color="#e6e6e6", lw=0.6, zorder=0)
    ax.spines[["top", "right"]].set_visible(False)
    ax.set_xlim(left[0], left[-1] + BW / 1000)
    ax.set_xticks([-0.08 * X / 1000, 0, 0.08 * X / 1000])
    summary[str(X)] = {"pre_bin_below_pct": float(share["pre"][below][0]), "post_bin_below_pct": float(share["post"][below][0]),
                       "pre_bin_from_X_pct": float(share["pre"][at][0]), "post_bin_from_X_pct": float(share["post"][at][0]),
                       "change_below_pts": float(d[below][0]), "change_from_X_pts": float(d[at][0])}
axes[0].set_ylabel("Change in share of sales,\nafter minus before (points)")
fig.tight_layout()
fig.savefig(ROOT / "output/Figure_1_headline.pdf")
fig.savefig(ROOT / "output/Figure_1_headline.png", dpi=200)
(ROOT / "output/headline_figure.json").write_text(json.dumps(summary, indent=1))
print(json.dumps(summary, indent=1))
