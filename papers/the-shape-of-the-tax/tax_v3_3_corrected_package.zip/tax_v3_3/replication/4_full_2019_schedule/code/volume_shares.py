"""Share of sales at $2M-$10M among sales at $1M-$10M, before (Jan 2016-Mar 2019) and after (2020-2025) the 2019 reform,
one row per deed (deeds.py). Descriptive comparison with the volume response in Green et al. (2026). Writes output/volume_shares.json."""
import json
from pathlib import Path
import numpy as np
import importlib.util as _ilu

ROOT = Path(__file__).resolve().parents[1]
_spec = _ilu.spec_from_file_location("deeds", Path(__file__).resolve().parent / "deeds.py")
deeds = _ilu.module_from_spec(_spec); _spec.loader.exec_module(deeds)
rows = deeds.linked_rows()
p = np.array([float(r["sale_price"] or 0) for r in rows]); dt = np.array([r["sale_date"][:10] for r in rows])
out = {}
for lab, m in [("pre_2016_2019q1", dt < "2019-04-01"), ("post_2020_2025", dt >= "2020-01-01")]:
    base = int(((p >= 1e6) & (p < 1e7) & m).sum())
    high = int(((p >= 2e6) & (p < 1e7) & m).sum())
    out[lab] = {"sales_1m_10m": base, "sales_2m_10m": high, "share": high / base}
    print(lab, base, high, f"{high / base:.3f}")
(ROOT / "output/volume_shares.json").write_text(json.dumps(out, indent=1))
