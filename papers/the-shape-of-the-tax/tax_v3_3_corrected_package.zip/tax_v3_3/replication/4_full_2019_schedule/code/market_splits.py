"""v1.5: three extensions, all with the published scaled estimator.

1. Heterogeneity. The post-minus-pre bunching change and log change in R at
   $1M, $2M, $3M and $5M, separately for houses (building classes 01-03),
   condominiums (04, 12, 13, 15) and co-operatives (09, 10, 17), and for
   Manhattan against the other four boroughs. Each subgroup's estimates are
   judged against the same sixteen core placebos (placebo_inference.py)
   computed within that subgroup: rank count and z against the placebo SD.
2. Foreclosure and lender deeds. The same changes after dropping sales whose
   linked ACRIS deed is (a) a legal-rule transfer (referee's deed or other
   conveyance to a lender, lender-to-lender) or (b) any deed with a lender or
   referee party, using the classifier carried by the linked dataset.
3. Magnitudes. Excess mass below X (B) and missing mass above X (M), each
   converted to dollars by dividing by the counterfactual density at X, post
   minus pre. The dollar widths are compared with the buyer's tax jump, the
   width of the range a buyer could never prefer (the dominated range).
Writes output/market_splits.json.
"""
import csv, gzip, json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
TE = {"__file__": str(ROOT / "code/threshold_extension.py")}
exec(compile((ROOT / "code/threshold_extension.py").read_text().split("\nout = {}")[0], "threshold_extension.py", "exec"), TE)
kw, round_dummies, T = TE["kw"], TE["round_dummies"], TE["T"]
PI = json.loads((ROOT / "output/placebo_inference.json").read_text())
PLACEBOS = PI["scaled"]["placebos_core"]
X4 = [1_000_000, 2_000_000, 3_000_000, 5_000_000]

import importlib.util as _ilu
_spec = _ilu.spec_from_file_location("deeds", Path(__file__).resolve().parent / "deeds.py")
deeds = _ilu.module_from_spec(_spec); _spec.loader.exec_module(deeds)
rows = deeds.linked_rows()
price = np.array([float(r["sale_price"] or 0) for r in rows])
date = np.array([r["sale_date"][:10] for r in rows])
group = np.array([r["property_group"] for r in rows])
boro = np.array([r["borough"] for r in rows])
event = np.array([r["deed_event"] for r in rows])
legal = np.array([r["legal_rule_amount"] == "1" for r in rows])
keep = price > 300_000
price, date, group, boro, event, legal = price[keep], date[keep], group[keep], boro[keep], event[keep], legal[keep]
PRE, POST = date < "2019-04-01", date >= "2020-01-01"
assert np.array_equal(np.sort(price), np.sort(TE["price"])), "sample differs from threshold_extension.py"


def logR(p, x):
    a = ((p >= x) & (p < 1.05 * x)).sum(); b = ((p >= 0.925 * x) & (p < 0.975 * x)).sum()
    return np.log(a / b) if a > 0 and b > 0 else np.nan


def changes(mask, x):
    pre, post = price[mask & PRE], price[mask & POST]
    n_pre = int(((pre >= 0.8 * x) & (pre < 1.2 * x)).sum())
    return float(kw(post, x)[0] - kw(pre, x)[0]), float(logR(post, x) - logR(pre, x)), n_pre


def judged(mask):
    ref = [changes(mask, x) for x in PLACEBOS]
    kref = np.array([r[0] for r in ref]); rref = np.array([r[1] for r in ref])
    sd, mu = float(np.nanstd(kref, ddof=1)), float(np.nanmean(kref))
    out = {"placebo_kw_sd": sd, "placebo_kw_mean": mu}
    for x in X4:
        k, r, n = changes(mask, x)
        out[str(x)] = {"kw_diff": k, "logR_change": r, "window_n_pre": n,
                       "placebos_as_large": int((kref >= k).sum()), "placebos_as_low_R": int((rref <= r).sum()),
                       "z": (k - mu) / sd}
    return out


everyone = np.ones(len(price), bool)
het = {"all": judged(everyone),
       "houses": judged(group == "house"), "condominiums": judged(group == "condo"), "co-operatives": judged(group == "coop"),
       "manhattan": judged(boro == "1"), "other_boroughs": judged(boro != "1")}

# 2. Foreclosure and lender deeds
lender_any = (event != "") & (event != "ORDINARY")
fore = {"share_flagged_in_windows": {}}
for x in X4:
    w = (price >= 0.8 * x) & (price < 1.2 * x)
    fore["share_flagged_in_windows"][str(x)] = {"legal_rule": float(legal[w].mean()), "any_lender_or_referee": float(lender_any[w].mean()),
                                                 "no_linked_deed": float((event[w] == "").mean())}
fore["drop_legal_rule"] = judged(~legal)
fore["drop_any_lender_or_referee"] = judged(~lender_any)


# 3. Magnitudes: kw() internals, returning B, M and counterfactual density.
def kw_parts(p, X, deg=5):
    bw = max(b for b in (10_000, 25_000, 50_000, 100_000) if b <= max(10_000, 0.005 * X))
    window, below, above = 0.2 * X, 0.025 * X, 0.05 * X
    lo, hi = X - window, X + window
    sel = p[(p >= lo) & (p < hi)]
    edges = np.arange(lo, hi + bw / 2, bw)
    cnt, _ = np.histogram(sel, bins=edges)
    mid = edges[:-1] + bw / 2
    excl = (mid > X - below) & (mid < X + above)
    Xm = np.column_stack([((mid - X) / window) ** k for k in range(deg + 1)] + [round_dummies(mid, bw)])
    beta, *_ = np.linalg.lstsq(Xm[~excl], cnt[~excl], rcond=None)
    cf = Xm @ beta
    a, b = (mid > X) & (mid < X + above), (mid > X - below) & (mid < X)
    i = int(np.searchsorted(mid, X))                       # first bin above X
    h0 = float((cf[i - 1] + cf[i]) / 2 / bw)               # counterfactual sales per dollar at X
    share = float((cf[a] - cnt[a]).sum() / cf[a].sum())
    return {"B": float((cnt[b] - cf[b]).sum()), "M": float((cf[a] - cnt[a]).sum()), "h0": h0, "share": share}


mag = {}
for x in X4 + PLACEBOS:
    pre, post = kw_parts(price[PRE], x), kw_parts(price[POST], x)
    assert abs(pre["share"] - kw(price[PRE], x)[0]) < 1e-9 and abs(post["share"] - kw(price[POST], x)[0]) < 1e-9
    dB = post["B"] / post["h0"] - pre["B"] / pre["h0"]
    dM = post["M"] / post["h0"] - pre["M"] / pre["h0"]
    mag[str(x)] = {"excess_below_dollars_change": dB, "missing_above_dollars_change": dM,
                   "pre": {k: pre[k] for k in ("B", "M", "h0")}, "post": {k: post[k] for k in ("B", "M", "h0")},
                   "buyer_jump_dollars": T.get(x, (None, None, 0.0, 0.0))[2] / 100 * x,
                   "seller_jump_dollars": T.get(x, (None, None, 0.0, 0.0))[3] / 100 * x}
pl = np.array([mag[str(x)]["missing_above_dollars_change"] / x for x in PLACEBOS])
pb = np.array([mag[str(x)]["excess_below_dollars_change"] / x for x in PLACEBOS])
for x in X4:
    m = mag[str(x)]
    m["missing_above_pct_of_X"] = 100 * m["missing_above_dollars_change"] / x
    m["excess_below_pct_of_X"] = 100 * m["excess_below_dollars_change"] / x
    m["placebos_missing_as_large"] = int((pl >= m["missing_above_dollars_change"] / x).sum())
    m["placebos_excess_as_large"] = int((pb >= m["excess_below_dollars_change"] / x).sum())
    if m["buyer_jump_dollars"]:
        m["missing_over_buyer_jump"] = m["missing_above_dollars_change"] / m["buyer_jump_dollars"]
mag["placebo_missing_pct_of_X"] = {"mean": float(100 * pl.mean()), "sd": float(100 * pl.std(ddof=1)), "max": float(100 * pl.max())}
mag["placebo_excess_pct_of_X"] = {"mean": float(100 * pb.mean()), "sd": float(100 * pb.std(ddof=1)), "max": float(100 * pb.max())}

out = {"heterogeneity": het, "foreclosure_and_lender_deeds": fore, "magnitudes": mag}
(ROOT / "output/market_splits.json").write_text(json.dumps(out, indent=1))

for name, h in list(het.items()) + [("drop legal-rule deeds", fore["drop_legal_rule"]), ("drop any lender/referee deed", fore["drop_any_lender_or_referee"])]:
    print(f"\n{name}: placebo sd {h['placebo_kw_sd']:.3f}")
    for x in X4:
        v = h[str(x)]
        print(f"  {x:>10,} n_pre {v['window_n_pre']:>6,}  kw {v['kw_diff']:+.3f} (placebos >= {v['placebos_as_large']:>2}, z {v['z']:+.1f})"
              f"  dlogR {v['logR_change']:+.3f} (placebos <= {v['placebos_as_low_R']})")
print("\nflag shares in windows:", json.dumps(fore["share_flagged_in_windows"], indent=0))
print("\nmagnitudes (post - pre), dollars:")
for x in X4:
    m = mag[str(x)]
    print(f"  {x:>10,} excess below {m['excess_below_dollars_change']:>9,.0f} ({m['excess_below_pct_of_X']:.2f}% of X, placebos>= {m['placebos_excess_as_large']})"
          f"  missing above {m['missing_above_dollars_change']:>9,.0f} ({m['missing_above_pct_of_X']:.2f}%, placebos>= {m['placebos_missing_as_large']})"
          f"  buyer jump {m['buyer_jump_dollars']:,.0f}")
print("placebo missing % of X:", mag["placebo_missing_pct_of_X"], " excess:", mag["placebo_excess_pct_of_X"])
