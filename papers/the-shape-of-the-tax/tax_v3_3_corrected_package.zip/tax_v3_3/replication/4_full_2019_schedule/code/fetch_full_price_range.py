"""Retrieve NYC DOF annualized calendar sales 2016-2025 (w2pb-icbu), all prices.

v1.1 extends the price sample above the archived $6M cap so that the 2019
supplemental-tax notches at $5M, $10M, $15M, $20M and $25M can be studied.
Same residential building-class codes as fetch_annualized.py, matched on the
two-digit code (2016 uses a double space after the code). Pages on the stable
Socrata row id and asserts the total against a server-side count(1).
"""
import json, time, urllib.parse, urllib.request
from pathlib import Path

BASE = "https://data.cityofnewyork.us/resource/w2pb-icbu.json"
CODES = ["01", "02", "03", "04", "09", "10", "12", "13", "15", "17"]
FIELDS = ("sale_price,sale_date,borough,building_class_category,bbl,block,lot,"
          "apartment_number,address,residential_units,total_units")
WHERE = "(" + " OR ".join(f"building_class_category like '{c}%'" for c in CODES) + ")"
OUT = Path(__file__).resolve().parents[1] / "data/annualized_sales_all_prices.json"


def get(params, tries=8):
    url = f"{BASE}?{urllib.parse.urlencode(params)}"
    for i in range(tries):
        try:
            with urllib.request.urlopen(url, timeout=180) as r:
                return json.load(r)
        except Exception as e:
            print(f"  retry {i+1}: {type(e).__name__}", flush=True); time.sleep(4 * (i + 1))
    raise SystemExit("giving up")


expected = int(get({"$select": "count(1)", "$where": WHERE})[0]["count_1"])
print("server count:", expected, flush=True)
rows, offset = [], 0
while True:
    batch = get({"$select": FIELDS, "$where": WHERE, "$order": ":id", "$limit": 50000, "$offset": offset})
    rows += batch; offset += len(batch)
    print(f"  {len(rows):,}", flush=True)
    if len(batch) < 50000:
        break
assert len(rows) == expected, (len(rows), expected)
OUT.write_text(json.dumps(rows))
print(f"wrote {len(rows):,} rows (count-verified) -> {OUT}")
