"""v1.12: two benchmarks and the full-schedule slice calculation.

1. The recording-tax costing against the Department of Finance. The paper's
   $244 million a year is the borrower-side schedule (1.80% / 1.925%) on
   purchase mortgages in its four-borough, $300k-$6M panel, by sale year. The
   Department of Finance reports total mortgage-recording-tax liability on
   residential mortgages (1-3 family homes and condominiums; all five
   boroughs; purchase and refinance loans; state and city levies, including
   the 0.25% special additional tax payable by the lender) by calendar year
   of execution: Statistical Profile of the New York City Mortgage Recording
   Tax, Calendar Year 2024 (October 2025), Table 10. The panel's charge is put
   on the same all-levies basis (2.05% / 2.175%) and compared year by year.
2. The full 2019 schedule. The reform's whole-price rates (Tax Law 1402-b
   from $2M to $25M and the 0.25-point state base-rate rise at $3M) on every
   post-reform sale from $2M, with no upper limit, one row per deed
   (deeds.py), set against the
   $365 million a year the reform was reported to raise (residential and
   commercial). Two revenue-neutral slice schedules on the same sales, as in
   slice_schedule.py but over the whole schedule: (A) one marginal rate above
   $2M; (B) the statutory increments applied as marginal rates and scaled by a
   common factor.
Writes output/benchmarks_v29.json.
"""
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]

# 1. Recording tax. The panel and loan attachment of revenue_neutral.py, run up to its costing.
src = (ROOT / "code/revenue_neutral.py").read_text()
RN = {"__file__": str(ROOT / "code/revenue_neutral.py")}
exec(compile(src.split("\nP = d.price.to_numpy()")[0], "revenue_neutral.py", "exec"), RN)
d = RN["d"]
gross_factor = np.where(d.mort_amt < 500_000, 2.05 / 1.80, 2.175 / 1.925)
# Imputed charges carry the observed ratio; put them on the all-levies basis at the 2.05/1.80 ratio.
d["gross_all_levies"] = np.where(d.mort_amt > 0, d.mrt * gross_factor, d.mrt * 2.05 / 1.80)
d["year"] = d.date.astype(str).str[:4].astype(int)
DOF = {  # Table 10, total MRT liability, $ million: (1-3 family, condominiums)
    2016: (318.1, 182.5), 2017: (350.4, 191.0), 2018: (356.9, 155.2), 2019: (361.9, 160.2), 2020: (356.9, 144.2),
    2021: (548.4, 261.5), 2022: (443.8, 250.6), 2023: (269.2, 113.3), 2024: (299.3, 104.3)}
by_year = {}
for y, (h, c) in DOF.items():
    m = d.year == y
    by_year[str(y)] = {"panel_borrower_side": float(d.loc[m, "mrt"].sum() / 1e6),
                       "panel_all_levies": float(d.loc[m, "gross_all_levies"].sum() / 1e6),
                       "dof_residential_liability": h + c}
    by_year[str(y)]["ratio_all_levies_to_dof"] = by_year[str(y)]["panel_all_levies"] / (h + c)
yrs = [str(y) for y in DOF]
mrt = {"by_year": by_year,
       "mean_2016_2024": {k: float(np.mean([by_year[y][k] for y in yrs])) for k in ("panel_borrower_side", "panel_all_levies", "dof_residential_liability")},
       "source": "NYC Department of Finance, Statistical Profile of the New York City Mortgage Recording Tax, Calendar Year 2024, Table 10"}
mrt["mean_2016_2024"]["ratio"] = mrt["mean_2016_2024"]["panel_all_levies"] / mrt["mean_2016_2024"]["dof_residential_liability"]

# 2. Full 2019 schedule.
TE = {"__file__": str(ROOT / "code/threshold_extension.py")}
exec(compile((ROOT / "code/threshold_extension.py").read_text().split("\nout = {}")[0], "threshold_extension.py", "exec"), TE)
import csv, gzip
import importlib.util as _ilu
_spec = _ilu.spec_from_file_location("deeds", Path(__file__).resolve().parent / "deeds.py")
deeds = _ilu.module_from_spec(_spec); _spec.loader.exec_module(deeds)
rows = deeds.linked_rows()
lp = np.array([float(r["sale_price"] or 0) for r in rows]); ld = np.array([r["sale_date"][:10] for r in rows])
lb = np.array([r["borough"] for r in rows])
k = lp > 300_000
lp, ld, lb = lp[k], ld[k], lb[k]
assert np.array_equal(np.sort(lp), np.sort(TE["price"])), "sample differs from threshold_extension.py"
# v2.0: rows are already one per deed (deeds.py); the all-rows revenue is kept for comparison.
uniq = np.ones(len(lp), bool)
POST_YEARS = 6.0
post2m = (ld >= "2020-01-01") & (lp >= 2_000_000)
raw_revenue = None
STEPS = [(2_000_000, 0.25), (3_000_000, 0.50), (5_000_000, 0.75), (10_000_000, 1.00),
         (15_000_000, 0.25), (20_000_000, 0.25), (25_000_000, 0.15)]  # points; 3M = 0.25 supplemental + 0.25 base


def notch_tax(x):
    return sum(np.where(x >= X, inc, 0.0) for X, inc in STEPS) / 100 * x


_all = deeds.linked_rows(all_rows=True)
_ap = np.array([float(r['sale_price'] or 0) for r in _all]); _ad = np.array([r['sale_date'][:10] for r in _all])
raw_revenue = float(notch_tax(_ap[(_ad >= '2020-01-01') & (_ap >= 2_000_000)]).sum() / POST_YEARS)
p = lp[post2m & uniq]
R = float(notch_tax(p).sum() / POST_YEARS)
base_A = float(np.maximum(p - 2_000_000, 0).sum() / POST_YEARS)
rate_A = R / base_A
base_B = float(sum(inc / 100 * np.maximum(p - X, 0) for X, inc in STEPS).sum() / POST_YEARS)
scale_B = R / base_B
tax_A = lambda x: rate_A * np.maximum(np.asarray(x, float) - 2_000_000, 0)
tax_B = lambda x: sum(scale_B * inc / 100 * np.maximum(np.asarray(x, float) - X, 0) for X, inc in STEPS)
tn, ta, tb = notch_tax(p), tax_A(p), tax_B(p)
bands = [(2e6, 3e6), (3e6, 5e6), (5e6, 10e6), (10e6, 25e6), (25e6, np.inf)]
full = {"sales_per_year": float(len(p) / POST_YEARS), "revenue_per_year": R, "revenue_per_year_all_rows": raw_revenue,
        
        "reported_projection_per_year_all_property": 365e6,
        "share_from_2M_6M": float(notch_tax(p[p < 6e6]).sum() / POST_YEARS / R),
        "A_single_marginal_rate_above_2M_pct": 100 * rate_A, "B_scale_factor": scale_B,
        "B_cumulative_marginal_rates_pct": dict(zip([f"above {X / 1e6:g}M" for X, _ in STEPS], np.cumsum([scale_B * inc for _, inc in STEPS]).tolist())),
        "share_paying_more_A": float((ta > tn + 1e-6).mean()), "share_paying_more_B": float((tb > tn + 1e-6).mean()),
        "examples": {str(x): {"notch": float(notch_tax(np.array([float(x)]))[0]), "slice_A": float(tax_A([x])[0]), "slice_B": float(tax_B([x])[0])}
                     for x in (1_999_999, 2_000_000, 2_500_000, 3_000_000, 4_000_000, 5_000_000, 7_500_000, 10_000_000, 20_000_000)},
        "mean_tax_by_band": {}}
for lo, hi in bands:
    m = (p >= lo) & (p < hi)
    full["mean_tax_by_band"][f"{lo / 1e6:g}M-{hi / 1e6:g}M"] = {"n_per_year": float(m.sum() / POST_YEARS), "notch": float(tn[m].mean()),
                                                               "A": float(ta[m].mean()), "B": float(tb[m].mean())}
out = {"mortgage_recording_tax": mrt, "full_schedule": full}
(ROOT / "output/benchmarks_v29.json").write_text(json.dumps(out, indent=1))
print(json.dumps(out, indent=1))
