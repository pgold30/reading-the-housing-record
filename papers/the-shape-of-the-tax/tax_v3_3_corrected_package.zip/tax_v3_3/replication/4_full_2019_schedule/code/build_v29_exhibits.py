"""v1.12 (preprint v2.9): render the tables added or rebuilt in v2.9 from their outputs.
  tab_moved.tex    where the moved sales came from          (focal_robustness.json)
  tab_beyond.tex   the response beyond the round price      (focal_robustness.json, equality_test.json)
  tab_size.tex     how far sales moved                       (focal_robustness.json)
  tab_cost.tex     avoided tax                               (cost_and_sponsors.json, benchmarks_v29.json)
  tab_slice.tex    the full 2019 schedule and two slice schedules (benchmarks_v29.json)
Writes them to output/."""
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
O = ROOT / "output"
F = json.loads((O / "focal_robustness.json").read_text())
FI = json.loads((O / "focal_inference.json").read_text())
EQ = json.loads((O / "equality_test.json").read_text())
RV = json.loads((O / "cost_and_sponsors.json").read_text())["revenue"]
BM = json.loads((O / "benchmarks_v29.json").read_text())
X4 = ["1000000", "2000000", "3000000", "5000000"]


def usd(x, dp=0):
    s = f"{abs(x):,.{dp}f}".replace(",", "{,}")
    return ("$-$" if x < 0 else "") + "\\$" + s


def sg(x, dp=3):
    return f"${x:+.{dp}f}$".replace("+", "+").replace("-", "-")


def ci(v, dp=3):
    return f"[${v[0]:+.{dp}f}$, ${v[1]:+.{dp}f}$]"


def n0(x):
    return f"${x:+.0f}$"


def ci0(v):
    return f"[${v[0]:+.0f}$, ${v[1]:+.0f}$]"


def note(body):
    return "\\notes{\\textit{Notes.} " + body + "}\n"


# --- Table: where the moved sales came from -------------------------------------------
Z = F["zones"]
rows = []
labels = {"1000000": "\\$1{,}000{,}000 (control)", "2000000": "\\$2{,}000{,}000", "3000000": "\\$3{,}000{,}000",
          "5000000": "\\$5{,}000{,}000", "1500000": "\\$1{,}500{,}000 (never taxed)", "2500000": "\\$2{,}500{,}000 (never taxed)"}
for X in ["2000000", "3000000", "5000000", "1000000", "1500000", "2500000"]:
    z = Z[X]
    md = z["mean_distance_below_X_of_excess"]
    mdc = z["mean_distance_ci"]
    cells = [n0(z[k]["sales_per_year"]) for k in ("further_below", "within_5k_below", "exactly_X", "above_excluding_X")]
    cis = [ci0(z[k]["sales_per_year_ci"]) for k in ("further_below", "within_5k_below", "exactly_X", "above_excluding_X")]
    ms = FI["moved_share"].get(X)
    rows.append(labels[X] + " & " + " & ".join(cells) + " & " + (usd(md) if md is not None and mdc else "---")
                + " & " + (f"{100 * ms['moved']:.0f}\\%" if ms else "---") + " \\\\")
    rows.append(" & " + " & ".join("{\\scriptsize " + c + "}" for c in cis) + " & " + (
        "{\\scriptsize [" + usd(mdc[0]) + ", " + usd(mdc[1]) + "]}" if md is not None and mdc else "")
        + " & " + ("{\\scriptsize [" + f"{100 * ms['moved_ci'][0]:.0f}, {100 * ms['moved_ci'][1]:.0f}" + "]}" if ms else "") + " \\\\")
    if X == "5000000":
        rows.append("\\addlinespace")
moved = {X: 1 - Z[X]["exactly_X"]["share_post"] / Z[X]["exactly_X"]["share_pre"] for X in ("2000000", "3000000", "5000000")}
tab_moved = r"""\begin{table}[htbp]
\centering
\caption{Where the moved sales came from}
\label{tab:moved}
\singlespacing\footnotesize
\setlength{\tabcolsep}{3pt}
\begin{tabular}{lcccccc}
\toprule
 & \multicolumn{4}{c}{Change in sales a year, by recorded price} & Mean distance & Sales at \\
\cmidrule(lr){2-5}
 & $[0.95X,$ & $[X-5{,}000,$ & Exactly & $(X,$ & below $X$ of & $X$ that \\
Threshold & $X-5{,}000)$ & $X)$ & $X$ & $1.05X)$ & added sales & moved \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
""" + note(
    "Each cell is the change in a price zone's share of sales between $0.9X$ and $1.1X$, from January 2016--March 2019 to "
    "2020--2025, multiplied by post-reform sales a year in that range: the number of sales a year the zone gained or lost. "
    "The mean distance is the mean of $X-P$ over the sales added to $[X-10{,}000, X)$: post-reform sales there, less pre-reform "
    "sales rescaled to the post-reform window size. The share that moved is one minus the ratio of the post-reform to the "
    "pre-reform share of window sales recorded at exactly $X$; equality across the three thresholds is not rejected "
    f"($p={FI['moved_share']['equal_moved_shares']['p']:.2f}$). Prices are whole dollars, so the zone just below $X$ includes $X-1$. "
    "95\\% bootstrap intervals (500 draws; 1{,}000 for the share that moved), resampling sales within the window in each period, in "
    "brackets. Replication package, \\texttt{focal\\_robustness.py}, \\texttt{focal\\_inference.py}.") + r"""\end{table}
"""
(O / "tab_moved.tex").write_text(tab_moved)

# --- Table: bin-count difference-in-differences -------------------------------------------------
DD = FI["did"]
zl = [("z2_below", "$[0.95X, X-5{,}000)$"), ("z3_just_below", "$[X-5{,}000, X)$"), ("z4_at_X", "Exactly $X$"), ("z5_above", "$(X, 1.05X)$")]
pc = lambda v: f"${int(round(100 * v)):+d}$"
pci = lambda c: "{\\scriptsize [" + f"${int(round(100 * c[0])):+d}$, ${int(round(100 * c[1])):+d}$" + "]}"
drow = []
for key, lab in zl:
    cols = [DD["deeds"]["pooled"][f"b_{key}"], DD["all_rows"]["pooled"][f"b_{key}"]] + \
           [DD["deeds"]["per_threshold"][f"b_{key}_{m}M"] for m in (2, 3, 5)]
    drow.append(lab + " & " + " & ".join(pc(c["pct"]) for c in cols) + " \\\\")
    drow.append(" & " + " & ".join(pci(c["pct_ci"]) for c in cols) + " \\\\")
RP = json.loads((O / "did_round_placebos.json").read_text())
def brow(lab, pooled, per=None):
    cells = [pooled["b_z4_at_X"], pooled["b_z5_above"]] + ([per[f"b_z5_above_{m}M"] for m in (2, 3, 5)] if per else [])
    r1 = lab + " & " + " & ".join(pc(c["pct"]) for c in cells) + " & ---" * (5 - len(cells)) + " \\\\"
    r2 = " & " + " & ".join(pci(c["pct_ci"]) for c in cells) + " &" * (5 - len(cells)) + " \\\\"
    return [r1, r2]
panel_b = []
panel_b += brow("\\$1M control only", DD["deeds"]["control_only"])
panel_b += brow("24 placebos only", DD["deeds"]["placebos_only"])
panel_b += brow("Control and placebos as round as $X$$^{a}$", RP["matched_with_control"]["pooled"], RP["matched_with_control"]["per_threshold"])
panel_b += brow("Placebos as round as $X$ only", RP["matched_only"]["pooled"])
panel_b += brow("Post-period 2022--2025 only", RP["post_2022_2025"]["pooled"], RP["post_2022_2025"]["per_threshold"])
panel_b += brow("No company seller", RP["no_company_seller"]["pooled"], RP["no_company_seller"]["per_threshold"])
mp = RP["matched_permutation"]
tab_did = r"""\begin{table}[htbp]
\centering
\caption{Bin-count difference-in-differences: the new thresholds against the control and never-taxed round prices}
\label{tab:did}
\singlespacing\footnotesize
\setlength{\tabcolsep}{4pt}
\begin{tabular}{lccccc}
\toprule
 & \multicolumn{2}{c}{Pooled, \$2M, \$3M, \$5M} & \multicolumn{3}{c}{By threshold} \\
\cmidrule(lr){2-3}\cmidrule(l){4-6}
Price zone & One row per deed & Every row & \$2{,}000{,}000 & \$3{,}000{,}000 & \$5{,}000{,}000 \\
\midrule
""" + "\n".join(drow) + r"""
\midrule
\multicolumn{6}{l}{\textit{Panel B. Other comparisons and samples}}\\
\midrule
 & \multicolumn{2}{c}{Pooled} & \multicolumn{3}{c}{$(X, 1.05X)$, by threshold} \\
\cmidrule(lr){2-3}\cmidrule(l){4-6}
 & Exactly $X$ & $(X, 1.05X)$ & \$2{,}000{,}000 & \$3{,}000{,}000 & \$5{,}000{,}000 \\
\midrule
""" + "\n".join(panel_b) + r"""
\bottomrule
\end{tabular}
""" + note(
    "Panel A: percentage change in the number of sales in each zone after the reform (2020--2025 against January 2016--March 2019), "
    "relative to the two outer zones $[0.9X, 0.95X)$ and $[1.05X, 1.1X)$ and net of the same change at the always-taxed "
    "\\$1{,}000{,}000 threshold and at the " + str(len(FI["placebos_100k"])) + " never-taxed multiples of \\$100{,}000 between \\$1.2 and \\$4.5 million "
    "whose $\\pm10\\%$ windows hold no threshold. Poisson regression on zone counts with price point $\\times$ period, price "
    "point $\\times$ zone and zone $\\times$ period effects; reported as $\\exp(\\beta)-1$. 95\\% intervals from 500 "
    "block-bootstrap draws that resample calendar months within each period. One row per deed except in the second column, "
    "which uses every row of the sales file (Section~\\ref{sec:data}). "
    "Treating each placebo in turn as if it had been taxed gives changes at exactly $X$ between "
    f"{pc(np.expm1(DD["deeds"]["permutation"]["summary"]['z4_at_X']['placebo_min']))}\\% and {pc(np.expm1(DD["deeds"]["permutation"]["summary"]['z4_at_X']['placebo_max']))}\\%, "
    "and in $(X, 1.05X)$ between "
    f"{pc(np.expm1(DD["deeds"]["permutation"]["summary"]['z5_above']['placebo_min']))}\\% and {pc(np.expm1(DD["deeds"]["permutation"]["summary"]['z5_above']['placebo_max']))}\\%. "
    "Panel B re-estimates the pooled and by-threshold models with other comparison groups and samples, one row per deed. "
    "$^{a}$The never-taxed multiples of \\$500{,}000 among the placebos (" + ", ".join(f"\\${x / 1e6:g}M" for x in RP["matched_placebos"]) + "). "
    "Treating each of these in turn as if it had been taxed, against the control and the other four, gives changes at exactly $X$ between "
    f"{pc(min(mp['z4_at_X'].values()))}\\% and {pc(max(mp['z4_at_X'].values()))}\\% and in $(X, 1.05X)$ between "
    f"{pc(min(mp['z5_above'].values()))}\\% and {pc(max(mp['z5_above'].values()))}\\%. Panel B intervals from 300 draws. "
    "Replication package, \\texttt{focal\\_inference.py}, \\texttt{did\\_round\\_placebos.py}.") + r"""\end{table}
"""
(O / "tab_did.tex").write_text(tab_did)

# --- Table: the share of round-price sales that moved (v2.0: Panels B and C) ----------------------------
MS = FI["moved_share"]
arow = []
for X in ("2000000", "3000000", "5000000"):
    v = MS[X]
    pc0 = lambda x: f"{100 * x:.0f}\\%"
    cr = lambda c: "{\\scriptsize [" + f"{100 * c[0]:.0f}, {100 * c[1]:.0f}" + "]}"
    arow.append(f"{labels[X]} & {usd(round(v['dominated_range_dollars'], -2))} & {pc0(v['moved'])} & {pc0(v['moved_placebo_adjusted'])} & "
                f"{pc0(v['dominated_gone'])} & {pc0(v['dominated_gone_placebo_adjusted'])} \\\\")
    arow.append(f" & & {cr(v['moved_ci'])} & {cr(v['moved_placebo_adjusted_ci'])} & {cr(v['dominated_gone_ci'])} & {cr(v['dominated_gone_placebo_adjusted_ci'])} \\\\")
P_ = MS["pooled"]
arow.append("\\addlinespace")
arow.append(f"Average of the three & & {100 * P_['moved']:.0f}\\% & & {100 * P_['dominated_gone']:.0f}\\% & \\\\")
arow.append(" & & {\\scriptsize [" + f"{100 * P_['moved_ci'][0]:.0f}, {100 * P_['moved_ci'][1]:.0f}" + "]} & & {\\scriptsize [" + f"{100 * P_['dominated_gone_ci'][0]:.0f}, {100 * P_['dominated_gone_ci'][1]:.0f}" + "]} & \\\\")
MC = json.loads((O / "moved_share_checks.json").read_text())
pc0 = lambda x: f"{100 * x:.0f}\\%"
brow = []
for key, lab in (("all_rows", "Every row of the sales file"), ("post_2022_2025", "Post-reform years 2022--2025 only"),
                 ("no_company_seller", "No company seller on the deed"), ("company_seller", "Company seller on the deed")):
    brow.append(f"{lab} & & " + " & ".join(pc0(MC[key][X]["moved"]) for X in ("2000000", "3000000", "5000000")) + f" & {pc0(MC[key]['average_moved'])} \\\\")
AC = MC["across_notches"]
crow = [f"Recording tax, \\$500{{,}}000 loan & \\$625 & \\multicolumn{{3}}{{c}}{{other round loan amounts}} & {pc0(AC['loan_500000']['moved'])} \\\\",
        f"Mansion tax, \\$1{{,}}000{{,}}000, since 1989 & \\$10{{,}}000 & \\multicolumn{{3}}{{c}}{{new thresholds before 2019}} & {pc0(AC['1000000']['moved'])} \\\\"]
tab_aware = r"""\begin{table}[htbp]
\centering
\caption{The share of round-price sales that moved, and the dominated range}
\label{tab:aware}
\singlespacing\footnotesize
\setlength{\tabcolsep}{4pt}
\begin{tabular}{lccccc}
\toprule
\multicolumn{6}{l}{\textit{Panel A. The 2019 thresholds, one row per deed}}\\
\midrule
 & Dominated & \multicolumn{2}{c}{Sales at exactly $X$ that moved} & \multicolumn{2}{c}{Sales in $(X, X+D]$ that disappeared} \\
\cmidrule(lr){3-4}\cmidrule(l){5-6}
Threshold & range $D$ & Raw & Against placebos & Raw & Against placebos \\
\midrule
""" + "\n".join(arow) + r"""
\midrule
\multicolumn{6}{l}{\textit{Panel B. Sales at exactly $X$ that moved, other samples}}\\
\midrule
 & & \$2{,}000{,}000 & \$3{,}000{,}000 & \$5{,}000{,}000 & Average \\
\midrule
""" + "\n".join(brow) + r"""
\midrule
\multicolumn{6}{l}{\textit{Panel C. Other notches}}\\
\midrule
 & Jump & \multicolumn{3}{c}{Comparison} & Moved \\
\midrule
""" + "\n".join(crow) + r"""
\bottomrule
\end{tabular}
""" + note(
    "Each share is one minus the ratio of the post-reform to the pre-reform share of sales in $[0.9X, 1.1X)$ recorded at exactly $X$ "
    "(Panel A, columns 3--4, and Panel B) or in the dominated range $(X, X+D]$, excluding $X$ itself (Panel A, columns 5--6). $D = T/(1+t)$, with $T$ the jump in "
    "all transfer taxes and $t$ the total rate just above $X$: no buyer who noticed the notch would record a price in that range. "
    "Against placebos divides the post-to-pre ratio by its average over the " + str(len(FI["placebos_100k"])) + " never-taxed "
    "multiples of \\$100{,}000 of Table~\\ref{tab:did} (for the dominated range, over the same proportional band above each). "
    "The difference between the two averages in Panel A is " + f"{100 * P_['difference']:+.0f}" + " points (95\\% interval "
    + f"{100 * P_['difference_ci'][0]:+.0f} to {100 * P_['difference_ci'][1]:+.0f}" + "). 95\\% bootstrap intervals (1{,}000 draws) in "
    "brackets. Panel B: the company-seller flag comes from the linked deed and includes sponsor sales; the average without a company seller exceeds the average with one by "
    + f"{100 * MC['seller_difference']['estimate']:.0f}" + " points (95\\% interval " + f"{100 * MC['seller_difference']['ci'][0]:.0f} to {100 * MC['seller_difference']['ci'][1]:.0f}" + "). "
    "Panel C compares levels, not periods. For loans, the share of loans in the last \\$1{,}000 up to and including \\$500{,}000 that sit at exactly \\$500{,}000 ("
    + pc0(AC['loan_500000']['share_at_X']) + ") against the same share at the untaxed round amounts from \\$300{,}000 to \\$700{,}000 (" + pc0(AC['loan_500000']['benchmark_share_mean'])
    + " on average; " + pc0(AC['loan_500000']['moved_range'][0]) + " to " + pc0(AC['loan_500000']['moved_range'][1]) + " against any one of them). For \\$1{,}000{,}000, the post-reform spike at exactly the threshold relative to local density ("
    + f"{AC['1000000']['spike_post']:.1f}" + ", Table~\\ref{tab:focal}) against the average pre-reform spike at the three new thresholds (" + f"{AC['1000000']['benchmark_spike']:.1f}" + "). "
    "Replication package, \\texttt{focal\\_inference.py}, \\texttt{moved\\_share\\_checks.py}.") + r"""\end{table}
"""
(O / "tab_aware.tex").write_text(tab_aware)

ROWS_ADDED = f"{F['all_rows']['rows_added']:,}".replace(",", "{,}")
ROWS_ALL = f"{F['all_rows']['rows']:,}".replace(",", "{,}")
NEL = json.loads((O / "notch_elasticity.json").read_text())["thresholds"]["1000000"]

# --- Table: beyond the round price -------------------------------------------------------
E = F["estimates"]


def kwcell(blk, X, with_ci=False):
    v = blk[X]
    s = f"{sg(v['kw'])} ({v['kw_placebos_as_large']})"
    return s


lines = []
lines.append("All sales (Table~\\ref{tab:fullschedule}) & " + " & ".join(kwcell(E["all"], X) for X in X4) + " \\\\")
for key, lab in (("drop_X_and_X-1", "Without sales at $X$ and $X-1$"), ("drop_1k", "Without sales within \\$1{,}000"),
                 ("drop_5k", "Without sales within \\$5{,}000")):
    lines.append(lab + " & " + " & ".join(kwcell(E[key], X) for X in X4) + " \\\\")
    if key == "drop_X_and_X-1":
        lines.append(" & " + " & ".join("{\\scriptsize " + ci(E[key][X]["kw_ci"]) + "}" for X in X4) + " \\\\")
lines.append("\\addlinespace")
lines.append("\\multicolumn{5}{l}{\\textit{Without sales at $X$ and $X-1$:}}\\\\")
lines.append("\\quad Net of the control & --- & " + " & ".join(
    sg(E["drop_X_and_X-1"][X]["kw_net_of_control"]) for X in X4[1:]) + " \\\\")
lines.append(" & & " + " & ".join("{\\scriptsize " + ci(E["drop_X_and_X-1"][X]["kw_net_of_control_ci"]) + "}" for X in X4[1:]) + " \\\\")
H = F["houses"]["drop_X_and_X-1"]
lines.append("\\quad Houses only & " + " & ".join(f"{sg(H[X]['kw'])} ({H[X]['kw_placebos_as_large']})" for X in X4) + " \\\\")
C = F["all_rows"]["drop_X_and_X-1"]
lines.append("\\quad Every row of the sales file & " + " & ".join(f"{sg(C[X]['kw'])} ({C[X]['kw_placebos_as_large']})" for X in X4) + " \\\\")
I = F["indicator_check"]["drop_X_and_X-1"]
lines.append("\\quad Indicators on containing bin & " + " & ".join(sg(I[X]["kw"]) for X in X4) + " \\\\")
panelB = []
for key, lab in (("all", "All sales"), ("drop_X_and_X-1", "Without sales at $X$ and $X-1$")):
    panelB.append(lab + " & " + " & ".join(f"{sg(E[key][X]['logR'])} ({E[key][X]['logR_placebos_as_low']})" for X in X4) + " \\\\")
D = E["drop_X_and_X-1"]
panelC = []
for t, lab in (("5M_minus_3x2M", "\\$5M $-$ 3 $\\times$ \\$2M (proportional)"), ("3M_minus_2x2M", "\\$3M $-$ 2 $\\times$ \\$2M (proportional)"), ("5M_minus_2M", "\\$5M $-$ \\$2M"), ("3M_minus_2M", "\\$3M $-$ \\$2M")):
    panelC.append(f"{lab} & {sg(EQ[t]['estimate'])} & {EQ[t]['p_two_sided']:.3f} & {sg(D[t]['estimate'])} & {D[t]['p_two_sided']:.2f} \\\\")
tab_beyond = r"""\begin{table}[htbp]
\centering
\caption{The response with and without the round price}
\label{tab:beyond}
\singlespacing\footnotesize
\setlength{\tabcolsep}{4pt}
\begin{tabular}{lcccc}
\toprule
\multicolumn{5}{l}{\textit{Panel A. Change in bunching, post $-$ pre (placebos at least as large, of 16)}}\\
\midrule
 & \$1{,}000{,}000 & \$2{,}000{,}000 & \$3{,}000{,}000 & \$5{,}000{,}000 \\
 & (control) & & & \\
\midrule
""" + "\n".join(lines) + r"""
\midrule
\multicolumn{5}{l}{\textit{Panel B. Log change in $R$ (placebos at least as low, of 16)}}\\
\midrule
""" + "\n".join(panelB) + r"""
\midrule
\multicolumn{5}{l}{\textit{Panel C. Tests across thresholds (bunching)}}\\
\midrule
 & \multicolumn{2}{c}{All sales} & \multicolumn{2}{c}{Without $X$ and $X-1$} \\
 & Estimate & Bootstrap $p$ & Estimate & Bootstrap $p$ \\
\midrule
""" + "\n".join(panelC) + r"""
\bottomrule
\end{tabular}
""" + note(
    "Estimator, windows, periods and placebos as in Tables~\\ref{tab:fullschedule} and \\ref{tab:placebo}. "
    "Each row drops the stated sales in both periods, at the thresholds and at every placebo alike; the dropped prices lie "
    "inside the range left out of the counterfactual fit, and where a bin loses part of its price range its counterfactual "
    "count is scaled by the share kept. 95\\% bootstrap intervals (500 draws) in brackets. Net of the control subtracts the "
    "\\$1{,}000{,}000 change, with independent draws for the two windows, which do not overlap. Houses are building classes "
    "01--03, with placebos recomputed among houses. The analysis keeps one row per deed; the every-row line uses all "
    + ROWS_ALL + " rows of the sales file above \\$300{,}000, " + ROWS_ADDED + " more. The estimator marks, for "
    "\\$10{,}000 bins, the two bins on either side of each multiple of \\$100{,}000 (Section~\\ref{sec:notchrobust}); the "
    "last row of Panel~A marks instead the bin that contains each multiple of \\$100{,}000, \\$50{,}000 and \\$25{,}000. "
    "$R$ is sales in $[X, 1.05X)$ over sales in $[0.925X, 0.975X)$. Panel~C: the proportional rows test a response proportional to the change in the total transfer-tax rate, 0.25, 0.50 and 0.75 points at \\$2, \\$3 and \\$5 million; all-sales $p$-values from 1{,}000 joint draws "
    "(Section~\\ref{sec:fullschedule}); without $X$ and $X-1$, from 500. Replication package, "
    "\\texttt{focal\\_robustness.py}.") + r"""\end{table}
"""
(O / "tab_beyond.tex").write_text(tab_beyond)

# --- Table: how far sales moved -----------------------------------------------------------
EL = F["elasticity_all_taxes"]
srows = []
for X in ("2000000", "3000000", "5000000"):
    a, b = E["all"][X], E["drop_5k"][X]
    T = {"2000000": 5000, "3000000": 15000, "5000000": 37500}[X]
    dom = EL["all"][X]["dominated_range_dollars"]
    k = lambda v: f"{v / 1000:.1f}".replace("-", "$-$")
    srows.append(f"{labels[X]} & {k(T)} & {k(dom)} & {k(a['pile'])} & {k(b['pile'])} & {k(a['hole'])} & {k(b['hole'])} & {EL['all'][X]['pile']:.3f} & {EL['all'][X]['hole']:.3f} \\\\")
L1 = F["level_1M"]
srows.append("\\addlinespace")
srows.append(f"\\$1{{,}}000{{,}}000 (level) & 10.0 & --- & {L1['all']['pile'] / 1000:.1f} & {L1['drop_5k']['pile'] / 1000:.1f} & {L1['all']['hole'] / 1000:.1f} & {L1['drop_5k']['hole'] / 1000:.1f} & {NEL['pile']['e_all']:.3f} & {NEL['hole']['e_all']:.3f} \\\\")

tab_size = r"""\begin{table}[htbp]
\centering
\caption{How far sales moved: bunching widths with and without the round price}
\label{tab:size}
\singlespacing\footnotesize
\setlength{\tabcolsep}{3pt}
\begin{tabular}{lcccccccc}
\toprule
 & Jump & Dominated & \multicolumn{2}{c}{Pile width} & \multicolumn{2}{c}{Hole width} & \multicolumn{2}{c}{Elasticity,} \\
 & $T$ & range & All & Without & All & Without & \multicolumn{2}{c}{all sales} \\
\cmidrule(lr){4-5}\cmidrule(lr){6-7}\cmidrule(l){8-9}
Threshold & \multicolumn{6}{c}{(\$ thousand)} & Pile & Hole \\
\midrule
""" + "\n".join(srows) + r"""
\bottomrule
\end{tabular}
""" + note(
    "Widths are the excess mass in $(0.975X, X)$ (pile) and the missing mass in $(X, 1.05X)$ (hole), each divided by the "
    "counterfactual density of sales per dollar at $X$; at the 2019 thresholds they are post-reform minus pre-reform, at "
    "\\$1{,}000{,}000 the post-reform level. ``Without'' drops sales within \\$5{,}000 of $X$ in both periods, "
    "as in Table~\\ref{tab:beyond}. $T$ is the jump in all transfer taxes at $X$; the dominated range is the band above $X$ in "
    "which a buyer who saw the notch could never prefer to transact, $T/(1+t)$ with $t$ the total transfer-tax rate just "
    "above $X$. The elasticity is that of the recorded price with respect to one plus the transfer-tax rate, solved from the "
    "indifference condition of the marginal buncher \\citep{kleven2013} with $1+t$ in place of $1-t$, all transfer taxes "
    "counted and no optimization frictions, from the all-sales widths; counting only buyer-paid taxes changes them by at "
    "most 0.005. Replication package, \\texttt{focal\\_robustness.py}, "
    "\\texttt{notch\\_elasticity.py}.") + r"""\end{table}
"""
(O / "tab_size.tex").write_text(tab_size)

# --- Table: avoided tax ---------------------------------------------------------------------
B = RV["by_threshold"]
FS = BM["full_schedule"]
crow = []
for X in X4:
    v = B[X]
    lab = labels[X]
    jump = "---" if X == "1000000" else usd(v["jump_dollars"])
    exc = f"{v['excess_sales_per_year']:.0f} [{v['excess_sales_per_year_ci'][0]:.0f}, {v['excess_sales_per_year_ci'][1]:.0f}]"
    mm = f"{n0(v['missing_minus_excess_per_year'])} [{n0(v['missing_minus_excess_per_year_ci'][0])}, {n0(v['missing_minus_excess_per_year_ci'][1])}]"
    av = "---" if X == "1000000" else f"{v['avoided_tax_per_year'] / 1e6:.2f} [{v['avoided_tax_per_year_ci'][0] / 1e6:.2f}, {v['avoided_tax_per_year_ci'][1] / 1e6:.2f}]"
    crow.append(f"{lab} & {jump} & {exc} & {mm} & {av} \\\\")
tot = RV["avoided_total_per_year"] / 1e6
tci = [v / 1e6 for v in RV["avoided_total_per_year_ci"]]
tab_cost = r"""\begin{table}[htbp]
\centering
\caption{What the 2019 notches cost in avoided tax}
\label{tab:cost}
\singlespacing\footnotesize
\setlength{\tabcolsep}{3.5pt}
\begin{tabular}{lcccc}
\toprule
 & Jump & Extra sales just & Missing minus & Tax avoided at the \\
Threshold & at $X$ & below $X$, a year & extra, a year & jump, \$M a year \\
\midrule
""" + "\n".join(crow).replace("$+", "$+").replace("$-", "$-") + r"""
\midrule
\textbf{Total, new thresholds} & & & & \textbf{""" + f"{tot:.2f}" + r"""} [""" + f"{tci[0]:.2f}, {tci[1]:.2f}" + r"""] \\
\bottomrule
\end{tabular}
""" + note(
    "Post-reform period, January 2020 to December 2025. Extra sales just below $X$ are the excess mass in $(0.975X, X)$ after "
    "the reform minus the pre-reform excess rescaled to the post-reform counterfactual density; missing minus extra is the "
    "corresponding missing mass in $(X, 1.05X)$ less that excess. Estimator and windows as in Table~\\ref{tab:fullschedule}; "
    "95\\% bootstrap intervals in brackets, covering sampling uncertainty conditional on the estimator. Each extra sale is "
    "assumed to have crossed the threshold from above (Table~\\ref{tab:moved} shows most came from the round price itself) and "
    "to avoid the statutory jump at $X$ (at \\$3{,}000{,}000 the buyer's 0.25 points and the seller's 0.25-point base-rate "
    "rise); it also lowers the other transfer taxes by about 3--4\\% of a price reduction that is mostly under \\$5{,}000, "
    "which is not counted. Other counts give " + f"\\${FI['avoided_tax']['b_direct_counts'] / 1e6:.1f}" + " million when the moved sales are counted "
    "directly as those lost at and above $X$ (Table~\\ref{tab:moved}), " + f"\\${FI['avoided_tax']['d_all_rows'] / 1e6:.1f}" +
    " million on every row of the sales file, and " + f"\\${FI['avoided_tax']['c_net_of_control'] / 1e6:.1f}" + " million when each pile is reduced by "
    "the control's own excess as a share of its window. The reform's whole residential schedule implies " + f"\\${FS['revenue_per_year'] / 1e6:.0f}" +
    " million a year on post-reform sales from \\$2{,}000{,}000 (Table~\\ref{tab:slice}). At the \\$1{,}000{,}000 control, whose "
    "tax did not change, the extra sales are within the range of the never-taxed placebos. Replication package, "
    "\\texttt{cost\\_and\\_sponsors.py}, \\texttt{focal\\_inference.py}, \\texttt{benchmarks\\_v29.py}.") + r"""\end{table}
"""
(O / "tab_cost.tex").write_text(tab_cost)

# --- Table: slice schedules over the full schedule -----------------------------------------
ex = FS["examples"]
erows = [f"{usd(int(k))} & {usd(ex[k]['notch'])} & {usd(ex[k]['slice_A'])} & {usd(ex[k]['slice_B'])} \\\\"
         for k in ("1999999", "2000000", "3000000", "5000000", "10000000", "20000000")]
brows = []
blab = {"2M-3M": "\\$2--3 million", "3M-5M": "\\$3--5 million", "5M-10M": "\\$5--10 million", "10M-25M": "\\$10--25 million",
        "25M-infM": "\\$25 million and above"}
for k, v in FS["mean_tax_by_band"].items():
    brows.append(f"{blab[k]} ({v['n_per_year']:,.0f} a year) & {usd(v['notch'])} & {usd(v['A'])} & {usd(v['B'])} \\\\".replace(",", "{,}", 1) if False else
                 f"{blab[k]} ({v['n_per_year']:,.0f} a year)".replace(",", "{,}") + f" & {usd(v['notch'])} & {usd(v['A'])} & {usd(v['B'])} \\\\")
cm = FS["B_cumulative_marginal_rates_pct"]
brates = ", ".join(f"{v:.2f}\\%" for v in cm.values())
tab_slice = r"""\begin{table}[htbp]
\centering
\caption{The 2019 schedule and two revenue-neutral slice schedules}
\label{tab:slice}
\singlespacing\footnotesize
\begin{tabular}{lccc}
\toprule
 & 2019 notches & Slice A & Slice B \\
 & (whole price) & (one marginal rate) & (scaled steps) \\
\midrule
\multicolumn{4}{l}{\textit{Panel A. Tax added by the 2019 reform at a recorded price of}} \\
""" + "\n".join(erows) + r"""
\addlinespace
\multicolumn{4}{l}{\textit{Panel B. Mean tax added, by price band}} \\
""" + "\n".join(brows) + r"""
\addlinespace
\multicolumn{4}{l}{\textit{Panel C. Totals}} \\
Revenue, \$M a year & """ + f"{FS['revenue_per_year'] / 1e6:.0f} & {FS['revenue_per_year'] / 1e6:.0f} & {FS['revenue_per_year'] / 1e6:.0f}" + r""" \\
Sales paying more than under the notches & --- & """ + f"{100 * FS['share_paying_more_A']:.0f}\\% & {100 * FS['share_paying_more_B']:.0f}\\%" + r""" \\
\bottomrule
\end{tabular}
""" + note(
    "Post-reform sales (2020--2025) from \\$2{,}000{,}000, " + f"{FS['sales_per_year']:,.0f}".replace(",", "{,}") +
    " a year, one row per deed (Section~\\ref{sec:data}), with recorded prices "
    "held fixed. The 2019 column is the supplemental tax under \\S1402-b (0.25\\% from \\$2{,}000{,}000 to 2.90\\% from "
    "\\$25{,}000{,}000) and the 0.25-point state base-rate rise at \\$3{,}000{,}000, each charged on the whole price. A slice "
    "schedule charges each marginal rate only on the part of the price above its threshold. Slice A charges " +
    f"{FS['A_single_marginal_rate_above_2M_pct']:.2f}\\%" + " on the part above \\$2{,}000{,}000. Slice B applies the "
    "statutory increments as marginal rates scaled by a common factor of " + f"{FS['B_scale_factor']:.2f}" + ", giving "
    "cumulative marginal rates of " + brates + " above \\$2, 3, 5, 10, 15, 20 and 25 million. Both raise the same revenue "
    "as the 2019 notches on these sales. A static calculation: it ignores the bunching that removing the jumps would undo "
    "and any other behavioral response. Replication package, \\texttt{benchmarks\\_v29.py}.") + r"""\end{table}
"""
(O / "tab_slice.tex").write_text(tab_slice)
print({X: round(v, 3) for X, v in moved.items()})
for f in ("tab_moved", "tab_aware", "tab_did", "tab_beyond", "tab_size", "tab_cost", "tab_slice"):
    print(f"--- {f}"); print((O / f"{f}.tex").read_text()[:4000])
