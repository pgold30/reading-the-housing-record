"""v2.0: the share of round-price sales that moved, m(X) = 1 - s_post/s_pre
(focal_inference.py, part 1), under alternative samples, and the same share at
the other notches in the data.

1. Samples: every row of the sales file; post-reform years 2022-2025 only (by
   then contracts signed before the 1 April 2019 grandfathering date have
   closed); sales without a company seller on the linked deed (a proxy that
   includes sponsor sales); sales with a company seller.
2. Across notches: the $1,000,000 notch (in place since 1989, $10,000 jump),
   where m is one minus the post-reform spike at exactly $1,000,000 relative to
   local density over the average pre-reform spike at the three then-untaxed
   new thresholds (focal_table.json); and the mortgage recording tax's
   $500,000 loan notch ($625 jump), where m is one minus the share of loans in
   the last $1,000 up to and including $500,000 that sit at exactly $500,000,
   over the same share at the untaxed round amounts $300,000-$700,000
   (loan_notch_checks.json). Both are cross-sectional comparisons.
The difference between the average moved share without and with a company
seller has a bootstrap interval. Bootstrap intervals (1,000 draws, seed 20261014). Writes
output/moved_share_checks.json.
"""
import json, warnings
from pathlib import Path
import numpy as np
import importlib.util as _ilu

ROOT = Path(__file__).resolve().parents[1]
_spec = _ilu.spec_from_file_location("deeds", Path(__file__).resolve().parent / "deeds.py")
deeds = _ilu.module_from_spec(_spec); _spec.loader.exec_module(deeds)
rng = np.random.default_rng(20261014)
warnings.filterwarnings("ignore", category=RuntimeWarning)
np.seterr(all="ignore")
R = 1000
NEW = [2_000_000, 3_000_000, 5_000_000]
TAXES = {2_000_000: (5_000, 0.03075), 3_000_000: (15_000, 0.03575), 5_000_000: (37_500, 0.04325)}
ci = lambda v: [float(x) for x in np.percentile(v, [2.5, 97.5])]


def arrays(all_rows):
    rows = deeds.linked_rows(all_rows=all_rows)
    p = np.array([float(r["sale_price"] or 0) for r in rows]); d = np.array([r["sale_date"][:10] for r in rows])
    c = np.array([r["grantor_company"] for r in rows])
    return p, d, c


DRAWS = {}


def moved(pre, post, key=None):
    out = {}
    avg = np.zeros(R)
    for X in NEW:
        a = pre[(pre >= 0.9 * X) & (pre < 1.1 * X)]; b = post[(post >= 0.9 * X) & (post < 1.1 * X)]
        D = TAXES[X][0] / (1 + TAXES[X][1])
        f = lambda a_, b_: (1 - (b_ == X).mean() / (a_ == X).mean(),
                            1 - ((b_ > X) & (b_ <= X + D)).mean() / ((a_ > X) & (a_ <= X + D)).mean())
        pt = f(a, b)
        dr = np.array([f(rng.choice(a, len(a)), rng.choice(b, len(b))) for _ in range(R)])
        fin = lambda v: float(v) if np.isfinite(v) else None
        out[str(X)] = {"moved": float(pt[0]), "moved_ci": ci(dr[:, 0]), "dominated_gone": fin(pt[1]),
                       "n_pre_at_X": int((a == X).sum()), "n_post_at_X": int((b == X).sum())}
        avg += dr[:, 0] / len(NEW)
    if key:
        DRAWS[key] = avg
    out["average_moved"] = float(np.mean([out[str(X)]["moved"] for X in NEW]))
    return out


res = {}
p, d, c = arrays(False)
ap, ad, _ = arrays(True)
PRE = lambda dd: dd < "2019-04-01"
res["deeds"] = moved(p[PRE(d)], p[d >= "2020-01-01"])
res["all_rows"] = moved(ap[PRE(ad)], ap[ad >= "2020-01-01"])
res["post_2022_2025"] = moved(p[PRE(d)], p[d >= "2022-01-01"])
res["no_company_seller"] = moved(p[PRE(d) & (c == "0")], p[(d >= "2020-01-01") & (c == "0")], "no")
res["company_seller"] = moved(p[PRE(d) & (c == "1")], p[(d >= "2020-01-01") & (c == "1")], "co")
res["seller_difference"] = {"estimate": res["no_company_seller"]["average_moved"] - res["company_seller"]["average_moved"],
                            "ci": ci(DRAWS["no"] - DRAWS["co"])}

F = json.loads((ROOT / "output/focal_table.json").read_text())
base = float(np.mean([F[str(X)]["pre"]["spike_ratio"] for X in NEW]))
L = json.loads((ROOT / "output/loan_notch_checks.json").read_text())["round_amounts"]
others = {k: v["share_at_X_of_last_1000"] for k, v in L.items() if k != "500000"}
s500 = L["500000"]["share_at_X_of_last_1000"]
res["across_notches"] = {
    "1000000": {"jump": 10_000, "since": 1989, "spike_post": F["1000000"]["post"]["spike_ratio"], "spike_pre": F["1000000"]["pre"]["spike_ratio"],
                "benchmark_spike": base, "moved": 1 - F["1000000"]["post"]["spike_ratio"] / base},
    "loan_500000": {"jump": 625, "share_at_X": s500, "benchmark_share_mean": float(np.mean(list(others.values()))),
                    "moved": 1 - s500 / float(np.mean(list(others.values()))),
                    "moved_range": [1 - s500 / min(others.values()), 1 - s500 / max(others.values())]},
}
(ROOT / "output/moved_share_checks.json").write_text(json.dumps(res, indent=1))
for k in ("deeds", "all_rows", "post_2022_2025", "no_company_seller", "company_seller"):
    print(k, {X: (round(res[k][X]["moved"], 3), np.round(res[k][X]["moved_ci"], 3).tolist(), res[k][X]["dominated_gone"], res[k][X]["n_pre_at_X"], res[k][X]["n_post_at_X"]) for X in map(str, NEW)}, round(res[k]["average_moved"], 3))
print("seller difference", res["seller_difference"])
print(json.dumps(res["across_notches"], indent=1))
