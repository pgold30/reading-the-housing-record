"""Formal tests behind "who pays matters, how much does not" (Section 5.6).

Bootstraps the post-minus-pre bunching change at $2M, $3M and $5M jointly
(independent resamples of each period's sales in each threshold's window;
windows are disjoint) and reports, draw by draw:
  - Delta(5M) - Delta(2M): equal responses despite a 3x rate / 7.5x dollar jump;
  - Delta(5M) - 3*Delta(2M): a response proportional to the buyer's rate;
  - Delta(3M) - Delta(2M): adding a seller-paid 0.25 pt to a buyer-paid 0.25 pt;
  - Delta(3M) - 2*Delta(2M): a response proportional to the total rate (v2.0, after review);
  - a Wald test that the three responses are equal.
Uses the Kleven-Waseem estimator of threshold_extension.py unchanged; its own
published outputs are not modified. Seed 20260924.
"""
import json
import numpy as np
import threshold_extension as te  # note: importing re-runs that script, rewriting its output identically

rng = np.random.default_rng(20260924)
R = 1000
pre, post = te.price[te.PRE], te.price[te.POST]
X = [2_000_000, 3_000_000, 5_000_000]
win = {x: (pre[(pre >= 0.8 * x) & (pre < 1.2 * x)], post[(post >= 0.8 * x) & (post < 1.2 * x)]) for x in X}
point = {x: te.kw(win[x][1], x)[0] - te.kw(win[x][0], x)[0] for x in X}
D = []
for _ in range(R):
    row = []
    for x in X:
        a, b = win[x]
        row.append(te.kw(rng.choice(b, len(b)), x)[0] - te.kw(rng.choice(a, len(a)), x)[0])
    D.append(row)
D = np.array(D); D = D[np.isfinite(D).all(1)]
d2, d3, d5 = D[:, 0], D[:, 1], D[:, 2]
ci = lambda v: [float(x) for x in np.percentile(v, [2.5, 97.5])]
out = {"point": {str(x): float(point[x]) for x in X}, "draws": int(len(D))}
for name, stat, pt in [("5M_minus_2M", d5 - d2, point[5_000_000] - point[2_000_000]),
                       ("5M_minus_3x2M", d5 - 3 * d2, point[5_000_000] - 3 * point[2_000_000]),
                       ("3M_minus_2M", d3 - d2, point[3_000_000] - point[2_000_000]),
                       ("3M_minus_2x2M", d3 - 2 * d2, point[3_000_000] - 2 * point[2_000_000])]:
    # Two-sided p for H0 "stat = 0": share of recentred draws at least as extreme as the estimate.
    centred = stat - stat.mean()
    out[name] = {"estimate": float(pt), "ci": ci(stat), "se": float(stat.std(ddof=1)),
                 "p_two_sided": float(np.mean(np.abs(centred) >= abs(pt)))}
# Wald test of equality of the three responses (bootstrap covariance)
C = np.array([[1, -1, 0], [0, 1, -1]]); v = C @ np.array([point[x] for x in X])
V = C @ np.cov(D.T) @ C.T
W = float(v @ np.linalg.solve(V, v))
from math import exp
out["wald_equal_all_three"] = {"W": W, "df": 2, "p": float(exp(-W / 2))}  # chi2(2) survival = exp(-W/2)
(te.ROOT / "output/equality_test.json").write_text(json.dumps(out, indent=1))
print(json.dumps(out, indent=1))
