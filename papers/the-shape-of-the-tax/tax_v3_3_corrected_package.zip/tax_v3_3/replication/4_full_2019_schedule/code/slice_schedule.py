"""v1.12 (preprint v2.9): revenue-neutral slice schedules for the 2019 notches.

The 2019 reform charges its added rates on the whole price once a threshold is
reached (Tax Law 1402-b and the 0.25-point state base-rate rise at $3M). In the
$2M-$6M band studied here that gives whole-price rates of 0.25% ($2M-$3M),
0.75% ($3M-$5M) and 1.50% ($5M-$6M), and the schedule-implied revenue on
post-reform sales that cost_and_sponsors.py reports ($92.7M a year).

A slice schedule charges each rate only on the part of the price above its
threshold, so the tax rises continuously and there is no jump to avoid. Two
revenue-neutral versions are computed on the same recorded post-reform prices:
  A. one marginal rate on the part of the price above $2M;
  B. the statutory increments (0.25, 0.50 and 0.75 points at $2M, $3M and
     $5M) applied as marginal rates and scaled by a common factor.
Both hold recorded prices and transactions fixed (a static calculation). They
ignore that removing the jumps would also remove the bunching below them,
which would raise the base slightly. Writes output/slice_schedule.json.
"""
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
TE = {"__file__": str(ROOT / "code/threshold_extension.py")}
exec(compile((ROOT / "code/threshold_extension.py").read_text().split("\nout = {}")[0], "threshold_extension.py", "exec"), TE)
price, date = TE["price"], TE["date"]
POST = date >= "2020-01-01"
POST_YEARS = 6.0
band = POST & (price >= 2_000_000) & (price < 6_000_000)
p = price[band]

STEPS = [(2_000_000, 0.25), (3_000_000, 0.50), (5_000_000, 0.75)]  # points of price, buyer plus seller


def notch_tax(x):
    rate = np.zeros_like(x)
    for X, inc in STEPS:
        rate = rate + np.where(x >= X, inc, 0.0)
    return rate / 100 * x


def slice_base(x, X):
    return np.maximum(x - X, 0.0)


R = float(notch_tax(p).sum() / POST_YEARS)
ref = json.loads((ROOT / "output/cost_and_sponsors.json").read_text())["revenue"]["collected_reform_tax_2M_6M_per_year"]
assert abs(R - ref) < 1.0, (R, ref)

base_A = float(slice_base(p, 2_000_000).sum() / POST_YEARS)
rate_A = R / base_A
base_B = float(sum(inc / 100 * slice_base(p, X) for X, inc in STEPS).sum() / POST_YEARS)
scale_B = R / base_B
rates_B = [inc * scale_B for _, inc in STEPS]


def tax_A(x):
    return rate_A * slice_base(np.asarray(x, float), 2_000_000)


def tax_B(x):
    x = np.asarray(x, float)
    return sum(r / 100 * slice_base(x, X) for (X, _), r in zip(STEPS, rates_B))


examples = {}
for x in (1_999_999, 2_000_000, 2_500_000, 2_999_999, 3_000_000, 4_000_000, 4_999_999, 5_000_000, 5_500_000):
    examples[str(x)] = {"notch": float(notch_tax(np.array([float(x)]))[0]), "slice_A": float(tax_A([x])[0]), "slice_B": float(tax_B([x])[0])}
# Who pays more under each slice schedule than under the notches.
tn, ta, tb = notch_tax(p), tax_A(p), tax_B(p)
out = {
    "revenue_per_year": R, "sales_per_year": float(band.sum() / POST_YEARS),
    "A_single_marginal_rate_above_2M_pct": 100 * rate_A,
    "B_scaled_increments_pct": dict(zip(["2M", "3M", "5M"], rates_B)), "B_scale_factor": scale_B,
    "B_cumulative_marginal_rates_pct": dict(zip(["above 2M", "above 3M", "above 5M"], np.cumsum(rates_B).tolist())),
    "share_paying_more_A": float((ta > tn + 1e-6).mean()), "share_paying_more_B": float((tb > tn + 1e-6).mean()),
    "mean_tax_change_by_band": {},
    "examples": examples,
}
for lo, hi in [(2_000_000, 3_000_000), (3_000_000, 5_000_000), (5_000_000, 6_000_000)]:
    m = (p >= lo) & (p < hi)
    out["mean_tax_change_by_band"][f"{lo // 1_000_000}M-{hi // 1_000_000}M"] = {
        "n_per_year": float(m.sum() / POST_YEARS), "notch_mean": float(tn[m].mean()),
        "A_mean": float(ta[m].mean()), "B_mean": float(tb[m].mean())}
(ROOT / "output/slice_schedule.json").write_text(json.dumps(out, indent=1))
print(json.dumps({k: v for k, v in out.items() if k != "examples"}, indent=1))
for k, v in examples.items():
    print(f"{int(k):>10,}  notch {v['notch']:>9,.0f}  slice A {v['slice_A']:>9,.0f}  slice B {v['slice_B']:>9,.0f}")
