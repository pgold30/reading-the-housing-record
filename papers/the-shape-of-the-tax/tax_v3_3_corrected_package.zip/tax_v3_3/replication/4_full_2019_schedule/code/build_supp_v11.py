"""Build Supplemental Appendix Section C (v1.1 detail) from the analysis outputs."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; O = ROOT / "output"
E = json.loads((O / "threshold_extension.json").read_text())
L = json.loads((O / "ltv_charm.json").read_text())
V = json.loads((O / "revenue_neutral.json").read_text())
num = lambda n: f"{n:,.0f}".replace(",", "{,}")
sg = lambda v: (f"$+{v:.3f}$" if v >= 0 else f"$-{abs(v):.3f}$")
rows = []
for X in [500_000, 1_000_000, 2_000_000, 3_000_000, 5_000_000, 10_000_000, 15_000_000, 20_000_000, 25_000_000,
          1_500_000, 1_750_000, 2_250_000, 2_500_000, 4_000_000, 6_000_000, 7_000_000, 8_000_000, 12_000_000]:
    e = E[str(X)]
    if X == 1_500_000: rows.append(r"\midrule")
    if e["S_logdiff"] is None:
        cell = "---"
    else:
        cell = f"{sg(e['S_logdiff'])} [{sg(e['S_logdiff'] - 1.96 * e['S_se'])}, {sg(e['S_logdiff'] + 1.96 * e['S_se'])}]"
    kind = "placebo" if e["label"] == "placebo" else f"{e['label']}, {e['cohort']}"
    rows.append(f"\\${num(X)} & {kind} & {e['S_counts_pre'][0]}/{e['S_counts_pre'][1]} & {e['S_counts_post'][0]}/{e['S_counts_post'][1]} & {cell} \\\\")
t3 = r"""\begin{center}
\textbf{Table A3:} Mass just below each threshold, before and after the reform
\end{center}
{\footnotesize
\begin{tabular}{llccl}
\toprule
Threshold & Statute & Pre: below/above & Post: below/above & $\Delta\log S$ [95\% CI] \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}}

\noindent{\footnotesize $S$ compares sales in $[0.99X, X)$ with sales in $[X, 1.01X)$, so it captures pricing
a few thousand dollars below a threshold as well as one dollar below. At \$5{,}000{,}000, sales at
\$4{,}995{,}000 rose from 7 before the reform to 80 after. Pre is January 2016 to March 2019, post
January 2020 to December 2025; Poisson intervals. The always-treated \$500{,}000 and
\$1{,}000{,}000 rows measure drift, not a reform response.}
"""
c = L["counts"]
r4 = []
for X in ["500000", "1000000", "2000000", "3000000"]:
    x = c[X]; ter = " / ".join(f"{100*v:.1f}" for v in x["charm_by_ltv_tercile"])
    r4.append(f"\\${num(int(X))} & {'seller' if X == '500000' else 'buyer'} & {x['financed_n']} & {100*x['charm_share']:.1f} & {ter} & {x['ltv_median']:.2f} \\\\")
m = L["models"]
t4 = r"""\begin{center}
\textbf{Table A4:} Charm pricing by loan-to-value, financed house purchases
\end{center}
{\footnotesize
\begin{tabular}{llcccc}
\toprule
Threshold & Payer & $N$ at $X-1$ or $X$ & Charm share (\%) & By LTV tercile, low / mid / high (\%) & Median LTV \\
\midrule
""" + "\n".join(r4) + r"""
\bottomrule
\end{tabular}}

\noindent{\footnotesize Financed house purchases recorded at exactly $X-1$ or $X$ with a positive loan
amount and $0<\mathrm{LTV}\le1$; condominium loan amounts are not in the linked panel. Pooling the three
buyer-paid thresholds with threshold and year fixed effects and parcel-clustered errors, the charm
probability changes by """ + f"{100*m['buyer_paid_1M_2M_3M']['continuous_per_10pts'][0]['ltv10'][0]:+.1f}" + r""" points per ten points of LTV
(s.e. """ + f"{100*m['buyer_paid_1M_2M_3M']['continuous_per_10pts'][0]['ltv10'][1]:.1f}" + r"""), and by """ + f"{100*m['buyer_paid_1M_2M_3M']['ltv_ge_80'][0]['high_ltv'][0]:+.1f}" + r""" points for LTV of 0.80 or more
(s.e. """ + f"{100*m['buyer_paid_1M_2M_3M']['ltv_ge_80'][0]['high_ltv'][1]:.1f}" + r"""). At \$500{,}000, where pricing one dollar below saves no tax (the city's higher
rate applies only above \$500{,}000), the slope is """ + f"{100*m['seller_paid_500k']['continuous_per_10pts'][0]['ltv10'][0]:+.1f}" + r"""
(s.e. """ + f"{100*m['seller_paid_500k']['continuous_per_10pts'][0]['ltv10'][1]:.1f}" + r""").}
"""
S = V["schedules"]
r5 = []
for band in ["$300k-500k", "$500k-1M", "$1M-2M", "$2M-6M"]:
    cells = []
    for k in ["A_flat", "B_above_500k", "C_two_bracket"]:
        d = S[k]["mean_net_change_by_band"][band]
        cells += [f"{d['financed']:+,.0f}".replace(",", "{,}"), f"{d['cash']:+,.0f}".replace(",", "{,}")]
    r5.append(band.replace("$", r"\$").replace("k", "k").replace("-", "--") + " & " + " & ".join(cells) + r" \\")
t5 = r"""\begin{center}
\textbf{Table A5:} Mean change in tax per purchase under each replacement, by price band (\$)
\end{center}
{\footnotesize
\begin{tabular}{lrrrrrr}
\toprule
 & \multicolumn{2}{c}{Flat """ + f"{S['A_flat']['tau_percent']:.2f}" + r"""\%} & \multicolumn{2}{c}{""" + f"{S['B_above_500k']['tau_percent']:.2f}" + r"""\% above \$500k} & \multicolumn{2}{c}{Two brackets} \\
Price band & Financed & Cash & Financed & Cash & Financed & Cash \\
\midrule
""" + "\n".join(r5) + r"""
\bottomrule
\end{tabular}}

\noindent{\footnotesize New tax minus the borrower-borne recording tax the purchase paid, averaged within
band and payment method; static, statutory incidence; four boroughs (Staten Island excluded). Schedules as in Table 8 of the paper.}
"""
sec = r"""\section*{C.\quad The full 2019 schedule, who responds, and the replacement: detail}

This section supports Sections 5.6, 5.7 and 6 of the paper. The extended price sample is a fresh,
count-verified retrieval of the same Department of Finance resource with the same building-class
filter and no upper price limit (729{,}047 residential records; 442{,}497 above \$300{,}000).
Its \$300{,}000--\$6{,}000{,}000 slice is identical, sale for sale, to the archived 431{,}471-sale
sample used in Tables 2--4 of the paper.

""" + t3 + "\n\\bigskip\n" + t4 + "\n\\bigskip\n" + t5 + "\n"
(O / "supp_section_C.tex").write_text(sec)
print("built supp_section_C.tex")
