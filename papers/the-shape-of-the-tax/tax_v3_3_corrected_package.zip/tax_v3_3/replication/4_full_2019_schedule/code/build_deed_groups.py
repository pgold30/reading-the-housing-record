"""v2.0: identify the rows of the sales file that repeat one deed.

A deed that conveys several lots (a building sold whole, a unit with its storage
or parking lot) appears in the Department of Finance sales file once per lot,
each row carrying the deed's whole consideration. Rows that share a sale date,
borough, tax block and price are treated as one deed; rows on different blocks
are kept apart, so that two separate sales at the same round price on the same
day are not merged.

Input: the full extract written by fetch_full_price_range.py
(data/annualized_sales_all_prices.json; not deposited, rebuilt from the public
API). Output: data/deed_groups.csv.gz, one line per (sale date, borough, price)
group with more than one row: the number of rows and the number of distinct
blocks among them, which is the number of deeds kept. Also asserts that the
extract's date-price records are those of data/sales_2016_2025_date_price.csv.gz.
"""
import csv, gzip, json, sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
src = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "data/annualized_sales_all_prices.json"
rows = json.loads(src.read_text())
dep = list(csv.DictReader(gzip.open(ROOT / "data/sales_2016_2025_date_price.csv.gz", "rt")))
key_dp = lambda d, p: (d[:10], str(int(float(p or 0))))
assert Counter(key_dp(r["sale_date"], r.get("sale_price")) for r in rows) == Counter(key_dp(r["sale_date"], r["sale_price"]) for r in dep), \
    "the extract differs from the deposited date-price records"
groups = defaultdict(list)
for r in rows:
    groups[(r["sale_date"][:10], str(int(float(r["borough"]))), str(int(float(r.get("sale_price") or 0))))].append(str(r.get("block", "")).strip())
out = [(d, b, p, len(bl), len(set(bl))) for (d, b, p), bl in groups.items() if len(bl) > 1]
out.sort()
with gzip.open(ROOT / "data/deed_groups.csv.gz", "wt", newline="") as f:
    w = csv.writer(f)
    w.writerow(["sale_date", "borough", "sale_price", "n_rows", "n_deeds"])
    w.writerows(out)
n_rows = sum(o[3] for o in out); n_deeds = sum(o[4] for o in out)
print(f"{len(out):,} repeated groups: {n_rows:,} rows, {n_deeds:,} deeds; {n_rows - n_deeds:,} rows dropped of {len(rows):,}")
