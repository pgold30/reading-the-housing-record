"""Robustness grid for the $500,000 loan notch, following DeFusco and Paciorek (2017):
bin width x polynomial degree x lower exclusion limit, with the upper exclusion limit chosen
to equate excess mass below and missing mass above the notch. Writes output/loan_notch_grid.json."""
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
NS = {"__file__": str(ROOT / "code/loan_notch.py")}
src = (ROOT / "code/loan_notch.py").read_text()
exec(compile(src.split("\nout = {")[0], "loan_notch.py", "exec"), NS)
L, X = NS["LOANS"], 500_000
EL = {"__file__": str(ROOT / "code/notch_elasticity.py")}
esrc = (ROOT / "code/notch_elasticity.py").read_text()
exec(compile("import numpy as np\nfrom scipy.optimize import brentq\n" + esrc[esrc.index("def gain"):esrc.index("# Self-check")], "notch_elasticity.py", "exec"), EL)


def fit(bw, deg, lo_ex, hi_ex, win=100_000):
    s = L[(L >= X - win) & (L < X + win)]
    edges = np.arange(X - win, X + win + bw / 2, bw)
    cnt, _ = np.histogram(s, bins=edges)
    lo = edges[:-1]
    excl = (lo >= X - lo_ex) & (lo < X + hi_ex)
    rd = np.column_stack([(lo % m == 0).astype(float) for m in (100_000, 50_000, 25_000, 10_000, 5_000) if m % bw == 0])
    Xm = np.column_stack([((lo - X) / win) ** k for k in range(deg + 1)] + [rd])
    beta, *_ = np.linalg.lstsq(Xm[~excl], cnt[~excl], rcond=None)
    cf = Xm @ beta
    below, above = excl & (lo < X), excl & (lo >= X)
    h0 = float(Xm[lo == X][0, :deg + 1] @ beta[:deg + 1] / bw)
    return float((cnt[below] - cf[below]).sum()), float((cf[above] - cnt[above]).sum()), h0


rows = []
for bw in (500, 1_000, 2_500):
    for deg in (5, 7, 9):
        for lo_ex in (5_000, 10_000, 15_000):
            best = min(((abs(B - M), hi, B, M, h0) for hi in range(2_500, 25_001, 2_500)
                        for B, M, h0 in [fit(bw, deg, lo_ex, hi)]), key=lambda r: r[0])
            _, hi, B, M, h0 = best
            w = B / h0
            rows.append({"bin": bw, "degree": deg, "lower": lo_ex, "upper": hi, "pile_dollars": w,
                         "e": EL["elasticity"](w / X, 1.80, 0.125)})
w = np.array([r["pile_dollars"] for r in rows]); e = np.array([r["e"] for r in rows])
summary = {"n_specs": len(rows), "pile_min": float(w.min()), "pile_median": float(np.median(w)), "pile_max": float(w.max()),
           "e_min": float(np.nanmin(e)), "e_median": float(np.nanmedian(e)), "e_max": float(np.nanmax(e))}
print(json.dumps(summary, indent=1))
(ROOT / "output/loan_notch_grid.json").write_text(json.dumps({"summary": summary, "specs": rows}, indent=1))
