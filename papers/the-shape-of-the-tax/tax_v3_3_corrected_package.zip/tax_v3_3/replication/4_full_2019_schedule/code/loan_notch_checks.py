"""v1.12: two checks on the loan-amount pile below the $500,000 recording-tax notch.

1. Lender pricing. Mortgage pricing changes at the conforming loan limits.
   The national baseline limit moved from $417,000 (2016) through $484,350
   (2019) and $510,400 (2020) to $806,500 (2025); the high-cost limit that
   applies in New York City ran from $625,500 to $1,209,750 (FHFA). If the
   pile below $500,000 came from a lending limit, it would track the year in
   which the baseline limit sat near $500,000. The ratio of loans in the
   $1,000 below $500,000 to loans in the $1,000 from it is computed by sale
   year, next to the same ratio at that year's baseline limit.
2. Inheritance from prices. A loan just below $500,000 could follow from a
   price just below a transfer-tax threshold. The share of loans in
   [$499,000, $500,000) whose price lies within $1,000 below $500,000,
   $1,000,000 or $2,000,000 is reported, with the share for loans in
   [$500,000, $501,000).
3. The round amount itself. $500,000 is a round loan amount, so a pile of
   loans just below it could partly be loans that would have been exactly
   $500,000. For $500,000 and untaxed round amounts from $300,000 to $700,000:
   the share of loans in [X - 1,000, X] that sit at exactly X, and loans per
   year at exactly X and in [X - 1,000, X), relative to the $25,000 below.
Same loans as loan_notch.py. Writes output/loan_notch_checks.json.
"""
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
src = (ROOT / "code/loan_notch.py").read_text()
LN = {"__file__": str(ROOT / "code/loan_notch.py")}
exec(compile(src.split("\nBW, WIN, EXCL, DEG")[0], "loan_notch.py", "exec"), LN)
d, obs = LN["d"], LN["obs"]
x = d[obs].copy()
x["year"] = x.date.astype(str).str[:4].astype(int)
expected_loans = json.loads((ROOT / "output/revenue_neutral.json").read_text())["sample"]["financed_loan_observed"]
assert len(x) == expected_loans, (len(x), expected_loans)
BASELINE = {2016: 417_000, 2017: 424_100, 2018: 453_100, 2019: 484_350, 2020: 510_400,
            2021: 548_250, 2022: 647_200, 2023: 726_200, 2024: 766_550, 2025: 806_500}


def ratio(L, X):
    a = int(((L >= X - 1000) & (L < X)).sum()); b = int(((L >= X) & (L < X + 1000)).sum())
    return {"below": a, "from": b, "ratio": a / b if b else None}


out = {"by_year": {}}
for y, g in x.groupby("year"):
    L = g.mort_amt.to_numpy(float)
    out["by_year"][str(y)] = {"loans": int(len(L)), "at_500k": ratio(L, 500_000),
                              "baseline_limit": BASELINE.get(int(y)), "at_baseline_limit": ratio(L, BASELINE[int(y)]) if int(y) in BASELINE else None}
L, P = x.mort_amt.to_numpy(float), x.price.to_numpy(float)
near = np.zeros(len(P), bool)
for X in (500_000, 1_000_000, 2_000_000):
    near |= (P >= X - 1000) & (P < X)
below = (L >= 499_000) & (L < 500_000); above = (L >= 500_000) & (L < 501_000)
out["price_just_below_a_transfer_tax_threshold"] = {"loans_499k_500k": int(below.sum()), "share": float(near[below].mean()),
                                                    "loans_500k_501k": int(above.sum()), "share_above": float(near[above].mean())}
out["round_amounts"] = {}
for X in (300_000, 350_000, 400_000, 450_000, 500_000, 550_000, 600_000, 650_000, 700_000):
    at = int((L == X).sum()); below = int(((L >= X - 1000) & (L < X)).sum()); ref = int(((L >= X - 26_000) & (L < X - 1_000)).sum())
    out["round_amounts"][str(X)] = {"at_X": at, "just_below_1000": below, "share_at_X_of_last_1000": at / (at + below),
                                    "at_X_per_25k_below": at / ref, "just_below_per_25k_below": below / ref}
(ROOT / "output/loan_notch_checks.json").write_text(json.dumps(out, indent=1))
for X, v in out["round_amounts"].items():
    print(X, v)
for y, v in out["by_year"].items():
    b = v["at_baseline_limit"]
    print(f"{y} n {v['loans']:>6,}  500k {v['at_500k']['below']:>4}/{v['at_500k']['from']:<4} = {v['at_500k']['ratio']:.2f}"
          + (f"   baseline {v['baseline_limit']:,}: {b['below']}/{b['from']} = {b['ratio']:.2f}" if b and b["ratio"] is not None else ""))
print(out["price_just_below_a_transfer_tax_threshold"])
