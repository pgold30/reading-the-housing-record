"""Bunching of purchase-mortgage amounts below New York City's $500,000
mortgage-recording-tax notch.

For one- to three-family homes and condominiums the borrower-side rate is
1.80% on loans below $500,000 and 1.925% on the whole loan at or above it
(Tax Law 253; NYC Admin. Code 11-2601), a jump of $625 at the threshold. The
design follows DeFusco and Paciorek (2017), who estimate bunching of loan
amounts at the conforming loan limit: a polynomial counterfactual for the
loan-amount density in $1,000 bins over +/- $100,000, excluding
(-$10,000, +$10,000) around the threshold, with indicators for multiples of
$100k, $50k, $25k, $10k and $5k. The same estimator is applied to round loan
amounts with no tax change as placebos. Intervals: 500-draw bootstrap.

Loans: the 172,725 purchase mortgages costed in revenue_neutral.py (houses from
2_tables/panel2.csv.gz, condominiums from data/condo_loans.csv.gz).
Writes output/loan_notch.json.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
rng = np.random.default_rng(20261010)
panel = ROOT.parent / "2_tables" / "panel2.csv.gz"
# Same loans as the costing in revenue_neutral.py: four ACRIS boroughs, condominium loans
# attached on unique unit/date/price keys, financed with 0.05 < LTV <= 1.05.
d = pd.read_csv(panel, dtype={"bbl": str})
d = d[d["borough"].astype(str).isin(["1", "2", "3", "4"])].copy()
cl = pd.read_csv(ROOT / "data/condo_loans.csv.gz", dtype={"unit_bbl": str, "sale_date": str})
cl["key"] = cl.unit_bbl + "|" + cl.sale_date + "|" + cl.sale_price.astype(float).map(repr)
cl = cl[~cl.key.duplicated(keep=False)].set_index("key")
d["key"] = d.bbl + "|" + d.date.astype(str) + "|" + d.price.astype(float).map(repr)
is_condo = d.src == "condo"
d.loc[is_condo, "mort_amt"] = d.loc[is_condo, "key"].map(cl.mortgage_amount_base).fillna(0.0).astype(float)
ltv = d.mort_amt / d.price
obs = (d.financed_base == 1) & (d.mort_amt > 0) & (ltv > 0.05) & (ltv <= 1.05)
h = d.loc[obs & (d.src == "house"), "mort_amt"].to_numpy(float)
c = d.loc[obs & is_condo, "mort_amt"].to_numpy(float)
LOANS = np.concatenate([h, c])
BW, WIN, EXCL, DEG = 1_000, 100_000, 10_000, 5
X0, RATE_BELOW, JUMP = 500_000, 1.80, 0.125
PLACEBOS = [300_000, 350_000, 400_000, 450_000, 550_000, 600_000, 650_000, 700_000]


def parts(L, X):
    L = L[(L >= X - WIN) & (L < X + WIN)]  # half-open window, so a loan at exactly X + WIN is never counted
    edges = np.arange(X - WIN, X + WIN + BW / 2, BW)
    cnt, _ = np.histogram(L, bins=edges)
    lo = edges[:-1]
    excl = (lo >= X - EXCL) & (lo < X + EXCL)
    fit_out = excl | ((lo >= X0 - EXCL) & (lo < X0 + EXCL))  # placebos also leave the real notch out of the fit
    rd = np.column_stack([(lo % m == 0).astype(float) for m in (100_000, 50_000, 25_000, 10_000, 5_000)])
    Xm = np.column_stack([((lo - X) / WIN) ** k for k in range(DEG + 1)] + [rd])
    beta, *_ = np.linalg.lstsq(Xm[~fit_out], cnt[~fit_out], rcond=None)
    cf = Xm @ beta
    below, above = excl & (lo < X), excl & (lo >= X)
    h0 = float(Xm[lo == X][0, :DEG + 1] @ beta[:DEG + 1] / BW)  # smooth density at X, round-number terms off
    B, M = float((cnt[below] - cf[below]).sum()), float((cf[above] - cnt[above]).sum())
    return {"B": B, "M": M, "h0": h0, "pile_dollars": B / h0, "hole_dollars": M / h0,
            "b_ratio": B / float(cf[below].sum()), "n_window": int(cnt.sum())}


out = {"loans": {"houses": int(len(h)), "condominiums": int(len(c))}, "jump_dollars": JUMP / 100 * X0, "thresholds": {}}
for X in [X0] + PLACEBOS:
    p = parts(LOANS, X)
    w = LOANS[(LOANS >= X - WIN) & (LOANS < X + WIN)]
    dr = np.array([[v["pile_dollars"], v["hole_dollars"], v["b_ratio"]] for v in (parts(rng.choice(w, len(w)), X) for _ in range(500))])
    p["ci"] = {k: np.percentile(dr[:, i], [2.5, 97.5]).tolist() for i, k in enumerate(["pile_dollars", "hole_dollars", "b_ratio"])}
    p["just_below_1000"] = int(((LOANS >= X - 1000) & (LOANS < X)).sum())
    p["from_X_1000"] = int(((LOANS >= X) & (LOANS < X + 1000)).sum())
    p["ratio_below_to_from"] = p["just_below_1000"] / p["from_X_1000"]
    out["thresholds"][str(X)] = p
    print(f"{X:>9,} {'NOTCH  ' if X == X0 else 'placebo'} excess below {p['b_ratio']:+.3f} [{p['ci']['b_ratio'][0]:+.3f},{p['ci']['b_ratio'][1]:+.3f}]"
          f"  pile ${p['pile_dollars']:>8,.0f} [{p['ci']['pile_dollars'][0]:>7,.0f},{p['ci']['pile_dollars'][1]:>7,.0f}]"
          f"  hole ${p['hole_dollars']:>8,.0f} [{p['ci']['hole_dollars'][0]:>7,.0f},{p['ci']['hole_dollars'][1]:>7,.0f}]"
          f"  [X-1000,X)/[X,X+1000) = {p['just_below_1000']}/{p['from_X_1000']} = {p['ratio_below_to_from']:.2f}  n {p['n_window']:,}")
(ROOT / "output/loan_notch.json").write_text(json.dumps(out, indent=1))
