"""v1.1: the full 2019 schedule. Seven reformed thresholds, two pre-existing
ones and never-taxed placebo prices, on the extended (uncapped) price sample.

Windows scale with the threshold so the same design applies from $500k to
$25M; at $2,000,000 every window is identical to the published estimator.
  - KW: Kleven-Waseem share of counterfactual mass missing above X
        (window 0.2X; bins 0.005X snapped down to 10k/25k/50k/100k;
        exclusion (-0.025X, +0.05X); degree 5).
  - R : N[X, 1.05X) / N[0.925X, 0.975X), no counterfactual fitted.
  - S : N[0.99X, X) / N[0.99X, 1.01X), mass just below vs just above.
Pre = sales before 1 Apr 2019; post = from 1 Jan 2020 (grandfathering window
dropped, as in the published tables). Count-based intervals are analytic
(Poisson); KW intervals are bootstrap percentiles.
"""
import gzip, json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
rng = np.random.default_rng(20260923)
# v2.0: the deposited linked file (the same date-price records as
# data/sales_2016_2025_date_price.csv.gz, with borough), one row per deed
# (deeds.py); SHAPE_ALL_ROWS=1 keeps every row of the sales file.
import importlib.util as _ilu
_spec = _ilu.spec_from_file_location("deeds", ROOT / "code" / "deeds.py")
deeds = _ilu.module_from_spec(_spec); _spec.loader.exec_module(deeds)
rows = deeds.linked_rows()
price = np.array([float(r.get("sale_price") or 0) for r in rows])
date = np.array([r["sale_date"][:10] for r in rows])
keep = price > 300_000
price, date = price[keep], date[keep]
PRE, POST = date < "2019-04-01", date >= "2020-01-01"

# Statutory rate increments at each threshold, percentage points of price
# (TSB-M-19(1)R; Tax Law 1402, 1402-a, 1402-b; NYC Admin. Code 11-2102).
T = {  # X: (label, cohort, buyer_pp, seller_pp)
    500_000: ("NYC RPTT", "1989", 0.0, 0.425),
    1_000_000: ("mansion 1402-a", "1989", 1.00, 0.0),
    2_000_000: ("1402-b", "2019", 0.25, 0.0),
    3_000_000: ("1402-b + base", "2019", 0.25, 0.25),
    5_000_000: ("1402-b", "2019", 0.75, 0.0),
    10_000_000: ("1402-b", "2019", 1.00, 0.0),
    15_000_000: ("1402-b", "2019", 0.25, 0.0),
    20_000_000: ("1402-b", "2019", 0.25, 0.0),
    25_000_000: ("1402-b", "2019", 0.15, 0.0),
}
PLACEBO = [1_500_000, 1_750_000, 2_250_000, 2_500_000, 4_000_000, 6_000_000, 7_000_000, 8_000_000, 12_000_000]


def n(p, lo, hi):
    return int(((p >= lo) & (p < hi)).sum())


def ratio(p, X, a):
    return n(p, X, X * (1 + a)), n(p, X * (1 - 1.5 * a), X * (1 - 0.5 * a))


def logdiff(num_pre, den_pre, num_post, den_post):
    if min(num_pre, den_pre, num_post, den_post) == 0:
        return None, None
    est = np.log(num_post / den_post) - np.log(num_pre / den_pre)
    se = np.sqrt(1 / num_pre + 1 / den_pre + 1 / num_post + 1 / den_post)
    return float(est), float(se)


def round_dummies(mid, bw):
    return np.column_stack([((np.round(mid / bw) * bw) % m == 0).astype(float) for m in (100_000, 50_000, 25_000)])


def kw(p, X, deg=5):
    # Bins snap to a round divisor (10k/25k/50k/100k) so the round-number
    # dummies line up with bin edges; at $2M this is the published 10k.
    bw = max(b for b in (10_000, 25_000, 50_000, 100_000) if b <= max(10_000, 0.005 * X))
    window, below, above = 0.2 * X, 0.025 * X, 0.05 * X
    lo, hi = X - window, X + window
    sel = p[(p >= lo) & (p < hi)]
    edges = np.arange(lo, hi + bw / 2, bw)
    cnt, _ = np.histogram(sel, bins=edges)
    mid = edges[:-1] + bw / 2
    excl = (mid > X - below) & (mid < X + above)
    Xm = np.column_stack([((mid - X) / window) ** k for k in range(deg + 1)] + [round_dummies(mid, bw)])
    beta, *_ = np.linalg.lstsq(Xm[~excl], cnt[~excl], rcond=None)
    cf = Xm @ beta
    a = (mid > X) & (mid < X + above)
    ca = cf[a].sum()
    return float((cf[a] - cnt[a]).sum() / ca) if ca > 0 else np.nan, len(sel)


def kw_diff(X, R=500):
    pre, post = price[PRE], price[POST]
    point = kw(post, X)[0] - kw(pre, X)[0]
    wpre = pre[(pre >= 0.8 * X) & (pre < 1.2 * X)]; wpost = post[(post >= 0.8 * X) & (post < 1.2 * X)]
    draws = []
    for _ in range(R):
        a = rng.choice(wpre, len(wpre)); b = rng.choice(wpost, len(wpost))
        v = kw(b, X)[0] - kw(a, X)[0]
        if np.isfinite(v): draws.append(v)
    return float(point), [float(x) for x in np.percentile(draws, [2.5, 97.5])], len(wpre), len(wpost)


out = {}
for X in list(T) + PLACEBO:
    pre, post = price[PRE], price[POST]
    rp, rq = ratio(pre, X, 0.05), ratio(post, X, 0.05)
    R_est, R_se = logdiff(rp[0], rp[1], rq[0], rq[1])
    sp = (n(pre, 0.99 * X, X), n(pre, X, 1.01 * X)); sq = (n(post, 0.99 * X, X), n(post, X, 1.01 * X))
    S_est, S_se = logdiff(sp[0], sp[1], sq[0], sq[1])
    kwd = kw_diff(X)
    ch = [int((pre == X - 1).sum()), int((pre == X).sum()), int((post == X - 1).sum()), int((post == X).sum())]
    lab = T.get(X, ("placebo", "never", 0.0, 0.0))
    out[str(X)] = dict(label=lab[0], cohort=lab[1], buyer_pp=lab[2], seller_pp=lab[3],
                       buyer_dollars=lab[2] / 100 * X, seller_dollars=lab[3] / 100 * X,
                       R_counts_pre=rp, R_counts_post=rq, R_logdiff=R_est, R_se=R_se,
                       S_counts_pre=sp, S_counts_post=sq, S_logdiff=S_est, S_se=S_se,
                       KW_diff=kwd[0], KW_ci=kwd[1], KW_window_n=[kwd[2], kwd[3]],
                       charm_counts_pre_post=ch)
    print(f"{X:>11,} {lab[0]:<15} b={lab[2]:.2f} s={lab[3]:.3f} | R Δ={R_est if R_est is None else round(R_est,3)} ±{R_se if R_se is None else round(1.96*R_se,3)} "
          f"| S Δ={S_est if S_est is None else round(S_est,3)} ±{S_se if S_se is None else round(1.96*S_se,3)} "
          f"| KW Δ={kwd[0]:+.3f} [{kwd[1][0]:+.3f},{kwd[1][1]:+.3f}] nwin={kwd[2]}/{kwd[3]} | charm {ch}", flush=True)

(ROOT / "output/threshold_extension.json").write_text(json.dumps(out, indent=1))
