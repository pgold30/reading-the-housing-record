"""Check the numbers quoted in corrected preprint 3.3 and its Supplemental Appendix against the analysis outputs.

Adapted from version 3.2's 4_full_2019_schedule/code/check_text_against_outputs.py
(17 October 2026). It reads the corrected condominium-panel outputs. Differences from the v3.1 checker:
four quoted phrases follow the v3.2 wording (same numbers), and the generated merge table is
compared under its corrected number, Table A15 (v3.1 had two tables numbered A14).

Every expected value is formatted from an output file, so a change in the data that is not carried
into the text fails a check. Usage:
    python3 check_text_against_outputs.py path/to/manuscript_aejpol.tex [path/to/supplemental_appendix.tex]
"""
import json, os, re, sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]; O = ROOT / "output"; REPO = ROOT.parent

_tex = Path(sys.argv[1] if len(sys.argv) > 1 else os.environ.get("SHAPE_MANUSCRIPT", ""))
if not _tex.is_file():
    raise SystemExit("usage: check_text_against_outputs.py path/to/manuscript_aejpol.tex [path/to/supplemental_appendix.tex]")
_supp = Path(sys.argv[2]) if len(sys.argv) > 2 else _tex.with_name("supplemental_appendix.tex")
MAIN = _tex.read_text(); SUPP = _supp.read_text() if _supp.is_file() else ""
# Version 3.1 wraps two label columns. Normalize only these exact layout
# declarations for literal generated-table checks; every cell stays checked.
for width in ['.30', '.19']:
    wrapped = r'\begin{tabular}{>{\raggedright\arraybackslash}p{' + width + r'\textwidth}ccccc}'
    MAIN = MAIN.replace(wrapped, r'\begin{tabular}{lccccc}')
TEX = MAIN + "\n" + SUPP
flat = re.sub(r"\s+", " ", TEX)
J = lambda f: json.loads((O / f).read_text())
res = []


def check(name, cond):
    res.append(bool(cond)); print(("PASS " if cond else "FAIL ") + name)


def intext(*snips):
    return all(re.sub(r"\s+", " ", s) in flat for s in snips)


def sg(v, d=3):  # signed in math mode, as the text writes it
    return f"$+{v:.{d}f}$" if v >= 0 else f"$-{abs(v):.{d}f}$"


def pc(v):  # signed whole percent in math mode
    k = int(round(100 * v)); return f"$+{k}\\%$" if k > 0 else (f"$-{abs(k)}\\%$" if k < 0 else "$0\\%$")


def money(v, r=0):
    return "\\$" + f"{round(v, r):,.0f}".replace(",", "{,}")


RENUMBERED = {"tab_merge.tex": ("\\textbf{Table A14:}", "\\textbf{Table A15:}")}  # v3.2 numbering


BS=chr(92)
tn=lambda v:f"{int(v):,}".replace(",","{,}")
sgpct=lambda v:"$"+f"{round(100*v):+d}"+BS+"%$"
def generated(f):
    g=(O/f).read_text().rstrip()
    if f in RENUMBERED:g=g.replace(*RENUMBERED[f])
    if g in TEX:return True
    # Preserve the numeric gate when the manuscript keeps its edited caption
    # and scope note. Every substantive generated table row must be present.
    rows=[x.strip() for x in g.splitlines() if " & " in x and not x.lstrip().startswith(("&","Threshold","Schedule","Financed","Price band"," &"))]
    def norm(x):return re.sub(r"\\s+"," ",x).strip()
    return bool(rows) and all(norm(x) in norm(TEX) for x in rows)


# ---------- data and sample ----------
FR = J("focal_robustness.json"); AR = FR["all_rows"]
check("442,497 rows, 434,108 one per deed, 8,389 repeats", AR["rows"] == 442_497 and AR["rows_one_per_deed"] == 434_108 and AR["rows_added"] == 8_389
      and intext("removes 8{,}389 of the 442{,}497 rows above \\$300{,}000, leaving 434{,}108") and intext("Using 434{,}108 sales, I compare"))
TE = {"__file__": str(ROOT / "code/threshold_extension.py")}
exec(compile((ROOT / "code/threshold_extension.py").read_text().split("\nout = {}")[0], "threshold_extension.py", "exec"), TE)
price, date, PRE, POST = TE["price"], TE["date"], TE["PRE"], TE["POST"]
check("pre 142,352 and post 258,647 sales", f"{PRE.sum():,}" == "142,352" and f"{POST.sum():,}" == "258,647" and intext("(142{,}352 sales)", "(258{,}647 sales)"))
dd = TE["deeds"]
allr = dd.linked_rows(all_rows=True); ap = np.array([float(r["sale_price"] or 0) for r in allr])
check("above $25M nearly two-thirds of rows repeat a deed", 0.60 <= 1 - (price >= 25e6).sum() / (ap >= 25e6).sum() < 2 / 3 and intext("nearly two-thirds of the rows repeat a deed"))
s2pre, s2post = (price[PRE] >= 2e6).mean(), (price[POST] >= 2e6).mean()
check("share above $2M 10.2% -> 11.8%", f"{100 * s2pre:.1f}" == "10.2" and f"{100 * s2post:.1f}" == "11.8" and intext("from 10.2\\% before the reform to 11.8\\% after"))
check("abstract at most 100 words", len(MAIN[MAIN.index("\\singlespacing\\noindent", MAIN.index("\\begin{abstract}")) + 23:MAIN.index("\\vspace{2mm}", MAIN.index("\\begin{abstract}"))].split()) <= 100)
check("title", intext(r"Round Prices and Bunching at New York City's\\ 2019 Transfer-Tax Notches"))

# ---------- Table 1 and the price zones ----------
FT = J("focal_table.json")
check("tab_focal.tex in the paper is the generated one", generated("tab_focal.tex"))
sp = lambda X, t: f"{FT[X][t]['spike_ratio']:.1f}"
check("spikes 7.8/7.0/8.3 -> 2.3/2.5/1.8 quoted", intext(f"carried {sp('2000000','pre')}, {sp('3000000','pre')} and {sp('5000000','pre')} times",
      f"the spikes fell to {sp('2000000','post')}, {sp('3000000','post')} and {sp('5000000','post')}"))
c1 = lambda X, t: round(FT[X][t]["at_X_minus_1_per_year"])
check("X-1 a year: about 1 -> 21, 11 and 4; never-taxed 1 or fewer; $1M 48 -> 89", [c1(X, "post") for X in ("2000000", "3000000", "5000000")] == [21, 11, 4]
      and max(c1(X, "pre") for X in ("2000000", "3000000", "5000000")) <= 1 and max(FT[X][t]["at_X_minus_1_per_year"] for X in ("1500000", "2500000") for t in ("pre", "post")) <= 1
      and (c1("1000000", "pre"), c1("1000000", "post")) == (48, 89)
      and intext("from about one a year to 21, 11 and 4 a year", "one a year or fewer", "48 a year before the reform and 89 after"))
check("placebo spikes rose", all(FT[X]["post"]["spike_ratio"] > FT[X]["pre"]["spike_ratio"] for X in ("1500000", "2500000")))
Z = FR["zones"]; spy = lambda X, k: Z[X][k]["sales_per_year"]
check("tab_moved.tex generated", generated("tab_moved.tex"))
check("zones at $2M: +89, +33, -78, -31", [round(spy("2000000", k)) for k in ("within_5k_below", "further_below", "exactly_X", "above_excluding_X")] == [89, 33, -78, -31]
      and intext("added about 89 sales a\nyear in the \\$5{,}000 below the threshold and 33 between", "It removed 78 a year at exactly \\$2{,}000{,}000 and 31 from"))
shx = [round(100 * spy(X, "exactly_X") / (spy(X, "exactly_X") + spy(X, "above_excluding_X"))) for X in ("2000000", "3000000", "5000000")]
check(f"share of missing at the round price {shx}: seven in ten, half, a third", 68 <= shx[0] <= 72 and 48 <= shx[1] <= 52 and 32 <= shx[2] <= 36
      and intext("About seven in ten of the sales missing above the threshold were at the round price itself", "against about half at \\$3{,}000{,}000 and a third at \\$5{,}000{,}000"))
md = [Z[X]["mean_distance_below_X_of_excess"] for X in ("2000000", "3000000", "5000000")]
check("mean distances about $2,400 / $2,200 / $3,000, each below the buyer's saving", [round(v, -2) for v in md] == [2400, 2200, 3000] and md[0] < 5000 and md[1] < 7500 and md[2] < 37500
      and intext("average \\$2{,}400 below\n\\$2{,}000{,}000, \\$2{,}200 below \\$3{,}000{,}000 and \\$3{,}000 below"))
check("control +138 just below, 48 from above", round(spy("1000000", "within_5k_below")) == 138 and round(-spy("1000000", "above_excluding_X")) == 48 and intext("138 a year, partly (48 a year)"))
FI = J("focal_inference.json"); MS = FI["moved_share"]
mv = [round(100 * MS[X]["moved"]) for X in ("2000000", "3000000", "5000000")]
mci = [[round(100 * c) for c in MS[X]["moved_ci"]] for X in ("2000000", "3000000", "5000000")]
check(f"moved shares {mv} with intervals {mci}; equality p", intext(f"fell by {mv[0]}\\% at \\$2{{,}}000{{,}}000, {mv[1]}\\% at \\$3{{,}}000{{,}}000 and {mv[2]}\\% at",
      f"intervals of {mci[0][0]}--{mci[0][1]}\\%, {mci[1][0]}--{mci[1][1]}\\% and {mci[2][0]}--{mci[2][1]}\\%", f"($p={MS['equal_moved_shares']['p']:.2f}$)"))
adj = [round(100 * MS[X]["moved_placebo_adjusted"]) for X in ("2000000", "3000000", "5000000")]
check("placebo spikes grew 6%; adjusted 63-66%", round(100 * (MS["placebo_spike_ratio_post_over_pre"] - 1)) == 6 and min(adj) == 63 and max(adj) == 66
      and intext("grew by 6\\% on average", "63\\% to 66\\%"))

# ---------- difference-in-differences ----------
DD = FI["did"]; D = DD["deeds"]
check("tab_did.tex generated; 24 placebos", generated("tab_did.tex") and len(FI["placebos_100k"]) == 24 and intext("the 24 never-taxed multiples of \\$100{,}000"))
p_ = D["pooled"]
check("pooled: -64% at X, more than triples just below, +9% further below, -17% [11, 23] above; -12% on every row",
      pc(p_["b_z4_at_X"]["pct"]) == "$-64\\%$" and p_["b_z3_just_below"]["pct"] > 2 and round(100 * p_["b_z2_below"]["pct"]) == 9
      and round(100 * p_["b_z5_above"]["pct"]) == -17 and [round(-100 * c) for c in p_["b_z5_above"]["pct_ci"]][::-1] == [11, 23]
      and round(100 * DD["all_rows"]["pooled"]["b_z5_above"]["pct"]) == -12
      and intext("fall by 64\\% relative to the\nouter zones", "more than triple", "rise by\n9\\%", "fall\nby 17\\% (95\\% interval 11\\% to 23\\%), or by 12\\% on every row"))
pt = D["per_threshold"]
a2, a3, a5 = (pt[f"b_z5_above_{m}M"] for m in (2, 3, 5))
check("by threshold above X: -10 [-19, +2], -22, -24/-28 excluding zero",
      [round(100 * a2["pct"]), round(100 * a3["pct"]), round(100 * a5["pct"])] == [-10, -22, -28] and [round(100 * c) for c in a2["pct_ci"]] == [-19, 2]
      and a3["pct_ci"][1] < 0 and a5["pct_ci"][1] < 0 and intext("$-10\\%$ at \\$2{,}000{,}000, with an interval from $-19\\%$ to $+2\\%$, and $-22\\%$\nand $-28\\%$"))
co, po = D["control_only"], D["placebos_only"]
check("control alone / placebos alone", [round(100 * co["b_z4_at_X"]["pct"]), round(100 * po["b_z4_at_X"]["pct"]), round(100 * co["b_z5_above"]["pct"]), round(100 * po["b_z5_above"]["pct"])] == [-54, -64, -9, -18]
      and intext("the change at the round price is $-54\\%$ and the change above it only $-9\\%$", "$-64\\%$ and $-18\\%$"))
PM = D["permutation"]["summary"]
lo, hi = np.expm1(PM["z4_at_X"]["placebo_min"]), np.expm1(PM["z4_at_X"]["placebo_max"])
check("permutation: placebo changes at X -11% to +68%, none as large; above: none for 3M/5M, one for 2M",
      round(100 * lo) == -11 and round(100 * hi) == 68 and PM["z4_at_X"]["pooled_placebos_as_extreme"] == 0
      and all(PM["z4_at_X"]["by_threshold"][m]["placebos_as_extreme_same_sign"] == 0 for m in ("2M", "3M", "5M"))
      and PM["z5_above"]["by_threshold"]["3M"]["placebos_as_extreme_same_sign"] == 0 and PM["z5_above"]["by_threshold"]["5M"]["placebos_as_extreme_same_sign"] == 0
      and PM["z5_above"]["by_threshold"]["2M"]["placebos_as_extreme_same_sign"] == 1
      and intext("between $-11\\%$ and $+68\\%$, none as large in magnitude", "and one exceeds the\n\\$2{,}000{,}000 change"))
Y = D["yearly"]; yr = lambda z, y: round(100 * Y[f"b_{z}_{y}"]["pct"])
post_at = [yr("z4_at_X", y) for y in range(2020, 2026)]; post_ab = [yr("z5_above", y) for y in range(2021, 2026)]
check("yearly at X: +5, -14, +10 before, -43 in 2019, -60 to -69 after", [yr("z4_at_X", y) for y in (2016, 2017, 2018, 2019)] == [5, -14, 10, -43]
      and min(post_at) == -69 and max(post_at) == -60 and intext("$+5\\%$,\n$-14\\%$ and $+10\\%$", "fall by 43\\% in 2019", "between 60\\% and 69\\%"))
check("yearly above X: -6 in 2020, -12 to -24 from 2021", yr("z5_above", 2020) == -6 and min(post_ab) == -24 and max(post_ab) == -12 and intext("$-6\\%$ in 2020 and between $-12\\%$ and $-24\\%$ from 2021"))

# ---------- model ----------
check("tab_aware.tex generated", generated("tab_aware.tex"))
P_ = MS["pooled"]
check("round-price share 0.61/0.64/0.61, 0.62 [0.55, 0.68]", intext(f"0.{mv[0]}, 0.{mv[1]} and 0.{mv[2]}") and f"{P_['moved']:.2f}" == "0.62"
      and [f"{c:.2f}" for c in P_["moved_ci"]] == ["0.55", "0.68"] and intext("0.62 on average (95\\% interval\n0.55 to 0.68)"))
dg = [f"{MS[X]['dominated_gone']:.2f}" for X in ("2000000", "3000000", "5000000")]
check(f"dominated-range share 0.40; difference 22 points [1, 79]; by threshold {dg}",
      f"{P_['dominated_gone']:.2f}" == "0.40" and round(100 * P_["difference"]) == 22 and [round(100 * c) for c in P_["difference_ci"]] == [1, 79]
      and dg == ["0.47", "0.55", "0.17"] and intext("disappeared is 0.40", "22 points, has an interval from 1 to 79 points", "0.47, 0.55 and 0.17"))
MC = J("moved_share_checks.json"); AC = MC["across_notches"]
check("moved shares and seller comparison agree with corrected outputs",
    intext(f"company seller, {MC['company_seller']['average_moved']:.2f} against {MC['no_company_seller']['average_moved']:.2f}",
           f"difference {round(100*MC['seller_difference']['estimate'])} points",
           f"interval {round(100*MC['seller_difference']['ci'][0])} to {round(100*MC['seller_difference']['ci'][1])}"))
check("other notches: loan 0.40 (0.32-0.43), $1M 0.99",
      f"{AC['loan_500000']['moved']:.2f}" == "0.40" and [f"{v:.2f}" for v in AC["loan_500000"]["moved_range"]] == ["0.32", "0.43"] and f"{AC['1000000']['moved']:.2f}" == "0.99"
      and intext("about 0.40 of the loans", "(0.32 to 0.43, depending on", "the share is 0.99", "about 0.4 at the mortgage recording tax's \\$625 loan notch"))
check("tab_focal / tab_aware use the new outputs", generated("tab_focal.tex") and generated("tab_aware.tex"))
check("D covers 5%, 10%, 14% of (X, 1.05X)", [round(100 * MS[X]["dominated_range_dollars"] / (0.05 * int(X))) for X in ("2000000", "3000000", "5000000")] == [5, 10, 14]
      and intext("$D$ covers 5\\%, 10\\% and 14\\% of its width"))
check("third prediction quoted: -10, -22, -28", intext("$-10\\%$, $-22\\%$ and $-28\\%$ for jumps of \\$5{,}000, \\$15{,}000 and\n\\$37{,}500"))

# ---------- bunching across the schedule ----------
E = J("threshold_extension.json")
check("tab_fullschedule rows in the paper, $6M and $12M dropped", all(intext(l.strip()) for l in (O / "tab_fullschedule.tex").read_text().splitlines() if "&" in l and "\\\\" in l)
      and "\\$6{,}000{,}000 & none" not in MAIN and "\\$12{,}000{,}000$^{b}$ & none" not in MAIN)
kw = [f"{E[X]['KW_diff']:.3f}" for X in ("2000000", "3000000", "5000000")]; lr = [f"{-E[X]['R_logdiff']:.3f}" for X in ("2000000", "3000000", "5000000")]
check(f"bunching {kw}, log R {lr}", intext(f"rises by {kw[0]}, {kw[1]} and\n{kw[2]}", f"falls by {lr[0]}, {lr[1]} and {lr[2]}") and E["5000000"]["charm_counts_pre_post"][0] == 0 and E["5000000"]["charm_counts_pre_post"][2] == 26)
thin = [X for X, v in E.items() if v["KW_window_n"][0] < 1000 and v["label"] != "placebo"]
check("thin treated thresholds are 10M, 15M, 20M, 25M", sorted(map(int, thin)) == [10_000_000, 15_000_000, 20_000_000, 25_000_000])
check("every placebo in Table 4 includes zero", all(E[str(X)]["KW_ci"][0] <= 0 <= E[str(X)]["KW_ci"][1] for X in (4_000_000, 7_000_000, 8_000_000)))
check("no thin threshold gives a significant bunching change", all(not (E[X]["KW_ci"][0] > 0 or E[X]["KW_ci"][1] < 0) for X in thin))
CC = J("collapsed_counts.json")
s_ = {X: CC[X]["deeds"]["S_logdiff"] for X in ("10000000", "15000000", "2000000")}
check("simple count +1.97 / +1.32 / +1.74, intervals excluding zero, fewer than 30 pre sales",
      [f"{s_[X]:.2f}" for X in ("10000000", "15000000", "2000000")] == ["1.97", "1.32", "1.74"] and all(CC[X]["deeds"]["ci"][0] > 0 for X in ("10000000", "15000000"))
      and all(max(CC[X]["deeds"]["counts"][:2]) < 30 for X in ("10000000", "15000000")) and intext("$+1.97$\nlog units at \\$10{,}000{,}000 and $+1.32$ at \\$15{,}000{,}000, against $+1.74$"))
Q = J("equality_test.json")
qt = lambda k: f"{sg(Q[k]['estimate'])} [{sg(Q[k]['ci'][0])}, {sg(Q[k]['ci'][1])}]".replace("$-0.000$", "$-0.000$")
check("joint bootstrap: 5M-2M, proportional, 3M-2M, equality",
      intext(qt("5M_minus_2M"), qt("5M_minus_3x2M"), f"($p={Q['5M_minus_3x2M']['p_two_sided']:.3f}$)", f"($p={Q['wald_equal_all_three']['p']:.2f}$)")
      and (intext(qt("3M_minus_2M")) or intext(qt("3M_minus_2M").replace("$+0.000$", "$-0.000$"))))
P = J("placebo_inference.json")["scaled"]; core, sm, ext = P["core"], P["size_matched"], P["extended"]
pk = core["placebo_kw"]
check("placebo mean, sd, max", intext(f"average {sg(pk['mean'])}, with a standard deviation of {pk['sd']:.3f} and a maximum of\n{sg(pk['max'])}")
      and all(round(core[X]["kw_rank_p"] * 17) == 1 and round(core[X]["logR_rank_p"] * 17) == 1 for X in ("2000000", "3000000", "5000000")))
zz = [f"{sm[X]['z']:.1f}" for X in ("2000000", "3000000", "5000000")]
k5 = round(sm["5000000"]["p_draws"] * (sm["5000000"]["draws"] + 1)) - 1
check(f"size-matched z {zz}; {k5} of 800 at $5M", intext(f"lie {zz[0]} and {zz[1]} standard\ndeviations", f"lies {zz[2]} standard deviations out, with\n{100 * k5 / sm['5000000']['draws']:.1f}\\% of draws as large")
      and all(round(sm[X]["p_draws"] * (sm[X]["draws"] + 1)) - 1 == 0 for X in ("2000000", "3000000")))
check("placebo shares for proportionality 11% / 12% / 37% (41 more)", round(100 * sm["5M_minus_3x2M"]["p_two_sided"]) == 11 and round(100 * sm["5M_minus_3x2M"]["disjoint_windows"]["p_two_sided"]) == 12
      and round(100 * ext["5M_minus_3x2M"]["p_two_sided"]) == 37 and ext["n_placebos"] - core["n_placebos"] == 41
      and intext("11\\% of placebo contrasts are at least as\nextreme (12\\% when the two placebo windows must not overlap), and 37\\% against\na wider set of 41"))
check("control log R -0.113 exceeded by one placebo", f"{core['1000000']['logR_change']:+.3f}" == "-0.113" and round(core["1000000"]["logR_rank_p"] * 17) == 2 and intext("$-0.113$, is exceeded by one\nplacebo"))
check("Table 5 rows rebuilt from outputs", all(intext(f"{sg(core[X]['kw_diff'])} & 0 of 16 & 0.06") for X in ("2000000", "3000000", "5000000")))
ES = J("event_study.json"); T_ = ES["thresholds"]
check("event study band counts", (T_["2000000"]["post_years_logR_below_band"], T_["2000000"]["post_years_kw_above_band"], T_["3000000"]["post_years_logR_below_band"], T_["3000000"]["post_years_kw_above_band"],
      T_["5000000"]["post_years_logR_below_band"], T_["5000000"]["post_years_kw_above_band"]) == (6, 5, 6, 6, 5, 1)
      and sum(T_[X]["base_years_kw_outside_band"] for X in ("2000000", "3000000", "5000000")) == 0
      and intext("both statistics are outside the band in all six years", "log $R$ is outside in five and bunching in\none"))
fk = ES["fake_reform_2018"]
check("fake 2018 reform", intext(f"{sg(fk['2000000']['kw_2018_minus_2016_17'])}, {sg(fk['3000000']['kw_2018_minus_2016_17'])} and\n{sg(fk['5000000']['kw_2018_minus_2016_17'])}")
      and round(min(fk[X]["p_two_sided"] for X in ("2000000", "3000000", "5000000")), 2) >= 0.43 and intext("(shares\nof 0.43 or more)"))
rng_ = lambda X: (min(T_[X]["logR"][y] for y in ("2023", "2024", "2025")), max(T_[X]["logR"][y] for y in ("2023", "2024", "2025")))
check("2023-25 log R ranges and control 2020 dip", f"{T_['1000000']['logR']['2020']:.2f}" == "-0.33" and all(intext(f"between $-{abs(rng_(X)[1]):.2f}$ and $-{abs(rng_(X)[0]):.2f}$ at \\${X[0]}{{,}}000{{,}}000") for X in ("2000000", "3000000", "5000000")))

# ---------- beyond the round price ----------
Ed, Ea = FR["estimates"]["drop_X_and_X-1"], FR["estimates"]["all"]
check("tab_beyond.tex generated", generated("tab_beyond.tex"))
check("$2M: 0.223 -> 0.041 [-0.027, +0.110], six placebos; control 0.056",
      f"{Ea['2000000']['kw']:.3f}" == "0.223" and f"{Ed['2000000']['kw']:.3f}" == "0.041" and [f"{c:+.3f}" for c in Ed["2000000"]["kw_ci"]] == ["-0.027", "+0.110"]
      and Ed["2000000"]["kw_placebos_as_large"] == 6 and f"{Ed['1000000']['kw']:.3f}" == "0.056"
      and intext("from 0.223\nto 0.041 [$-0.027$, $+0.110$], exceeded by six of the sixteen placebos and below\nthe control's 0.056"))
check("$3M 0.198 [+0.080, +0.314], $5M 0.179 [+0.028, +0.333], above every placebo",
      [f"{Ed[X]['kw']:.3f}" for X in ("3000000", "5000000")] == ["0.198", "0.179"] and Ed["3000000"]["kw_placebos_as_large"] == 0 and Ed["5000000"]["kw_placebos_as_large"] == 0
      and intext("0.198\n[$+0.080$, $+0.314$] remains and at \\$5{,}000{,}000, 0.179 [$+0.028$,\n$+0.333$]"))
check("about 0.20 and 0.18 with $1k/$5k drops", all(round(FR["estimates"][k]["3000000"]["kw"], 1) == 0.2 and round(FR["estimates"][k]["5000000"]["kw"], 2) in (0.18, 0.19) for k in ("drop_1k", "drop_5k")))
nc = [(Ed[X]["kw_net_of_control"], Ed[X]["kw_net_of_control_ci"]) for X in ("3000000", "5000000")]
check("net of control +0.143 [+0.019, +0.265] and +0.123 [-0.032, +0.283]", intext(f"{sg(nc[0][0])} [{sg(nc[0][1][0])}, {sg(nc[0][1][1])}]", f"{sg(nc[1][0])} [{sg(nc[1][1][0])}, {sg(nc[1][1][1])}]") and nc[0][1][0] > 0)
check("without focal: 3M-2M 0.157 p=0.026, 5M-2M 0.138 p=0.09; proportional to total rate +0.116 p=0.22, +0.056 p=0.67",
      f"{Ed['3M_minus_2M']['estimate']:.3f}" == "0.157" and f"{Ed['3M_minus_2M']['p_two_sided']:.3f}" == "0.026"
      and f"{Ed['5M_minus_2M']['estimate']:.3f}" == "0.138" and f"{Ed['5M_minus_2M']['p_two_sided']:.2f}" == "0.09"
      and f"{Ed['3M_minus_2x2M']['estimate']:+.3f}" == "+0.116" and f"{Ed['3M_minus_2x2M']['p_two_sided']:.2f}" == "0.22"
      and f"{Ed['5M_minus_3x2M']['estimate']:+.3f}" == "+0.056" and f"{Ed['5M_minus_3x2M']['p_two_sided']:.2f}" == "0.67"
      and intext("by 0.157 ($p=0.026$) and 0.138 ($p=0.09$)", "$+0.116$ ($p=0.22$) and $+0.056$ ($p=0.67$)"))
A_ = FR["all_rows"]
check("every row: 0.220, 0.321, 0.219 and 0.044, 0.146, 0.101",
      [f"{A_['all'][X]['kw']:.3f}" for X in ("2000000", "3000000", "5000000")] == ["0.220", "0.321", "0.219"]
      and [f"{A_['drop_X_and_X-1'][X]['kw']:.3f}" for X in ("2000000", "3000000", "5000000")] == ["0.044", "0.146", "0.101"]
      and intext("the bunching changes are 0.220, 0.321 and 0.219 with all sales and 0.044, 0.146 and 0.101"))
ic = FR["indicator_check"]
check("indicator variant moves estimates by at most 0.017", round(max(abs(ic[k][X]["kw"] - FR["estimates"][k][X]["kw"]) for k in ("all", "drop_X_and_X-1") for X in ic["all"]), 3) <= 0.017 and intext("by\nat most 0.017"))
PP = json.loads((REPO / "2_tables/prepost_results.json").read_text())
check("fixed window (every row): 0.220, 0.461, +0.005; pre-period level 0.094",
      [f"{PP['post'][X]['share'] - PP['pre'][X]['share']:.3f}" for X in ("2000000", "3000000")] == ["0.220", "0.461"]
      and f"{PP['post']['1000000']['share'] - PP['pre']['1000000']['share']:+.3f}" == "+0.005" and f"{PP['pre']['2000000']['share']:.3f}" == "0.094"
      and intext("gives changes of 0.220 and 0.461", "$+0.005$ at the control", "missing share of 0.094"))

# ---------- where ----------
MK = J("market_splits.json"); HT = MK["heterogeneity"]
W = (O / "tab_where.tex").read_text(); wrows = [l.strip() for l in W[:W.index("Panel B.")].splitlines() if "&" in l and "\\\\" in l]
check("Table 7 rows are the generated ones", all(intext(l) for l in wrows))
for g, lab in (("houses", "Among houses the changes at the three new\nthresholds are"), ("condominiums", "among condominiums"), ("manhattan", "in Manhattan"), ("other_boroughs", "in the other four boroughs")):
    v = [sg(HT[g][X]["kw_diff"]) for X in ("2000000", "3000000", "5000000")]
    check(f"{g} changes quoted", intext(f"{v[0]}, {v[1]} and {v[2]}") if g != "houses" else intext(f"{v[0]}, {v[1]} and {v[2]}"))
matched = [(g, X) for g in ("houses", "condominiums", "manhattan", "other_boroughs") for X in ("2000000", "3000000", "5000000") if HT[g][X]["placebos_as_large"] > 0]
check("only houses at $2M matched (two)", matched == [("houses", "2000000")] and HT["houses"]["2000000"]["placebos_as_large"] == 2)
check("n pre 1,003 / 299 / 330", (HT["houses"]["3000000"]["window_n_pre"], HT["houses"]["5000000"]["window_n_pre"], HT["other_boroughs"]["5000000"]["window_n_pre"]) == (1003, 299, 330)
      and intext("1{,}003 and 299\npre-reform sales", "estimate on 330"))
check("control: condos +0.151, Manhattan +0.091, houses +0.005 (8)", (sg(HT["condominiums"]["1000000"]["kw_diff"]), sg(HT["manhattan"]["1000000"]["kw_diff"]), sg(HT["houses"]["1000000"]["kw_diff"])) == ("$+0.151$", "$+0.091$", "$+0.005$")
      and HT["houses"]["1000000"]["placebos_as_large"] == 8 and intext("condominiums ($+0.151$) and Manhattan ($+0.091$)", "($+0.005$, with eight placebos as large)"))
cd_ = [f"{HT['condominiums'][X]['kw_diff'] - HT['condominiums']['1000000']['kw_diff']:+.2f}" for X in ("2000000", "3000000", "5000000")]
check(f"condo excess over own control {cd_}", intext(f"by ${cd_[0]}$, ${cd_[1]}$ and ${cd_[2]}$"))
cp = [sg(HT["co-operatives"][X]["kw_diff"]) for X in ("2000000", "3000000", "5000000")]
check("co-operatives quoted", intext(f"{cp[0]}, {cp[1]} and {cp[2]}"))
CS = J("cost_and_sponsors.json"); SPN = CS["sponsor"]
rs = [sg(SPN["all_resale"][X]["kw_diff"]) for X in ("2000000", "3000000", "5000000")]
check("no company seller changes and control match corrected output",
    intext(*rs, sg(SPN["all_resale"]["1000000"]["kw_diff"]))
    and all(SPN["all_resale"][x]["placebos_as_large"] == 0 for x in ("2000000","3000000","5000000")))
check("company seller estimates and placebo counts match corrected output",
    intext(*(sg(SPN["all_sponsor"][x]["kw_diff"]) for x in ("2000000","3000000","5000000")))
    and SPN["all_sponsor"]["3000000"]["placebos_as_large"] == 0
    and intext(str(SPN["all_sponsor"]["2000000"]["placebos_as_large"])+" placebos",
               "and "+str(SPN["all_sponsor"]["5000000"]["placebos_as_large"])+" at"))
FD = MK["foreclosure_and_lender_deeds"]; sh = FD["share_flagged_in_windows"]
an = [100 * sh[X]["any_lender_or_referee"] for X in sh]; dl = [sg(FD["drop_any_lender_or_referee"][X]["kw_diff"]) for X in ("2000000", "3000000", "5000000")]
check("lender/referee 0.2-1.2%; dropping them", f"{min(an):.1f}" == "0.2" and f"{max(an):.1f}" == "1.2" and intext("(0.2--1.2\\% of window sales", f"{dl[0]}, {dl[1]} and {dl[2]}"))

# ---------- size, mechanism, cost, volume, slices ----------
check("tab_size.tex generated", generated("tab_size.tex"))
EL = FR["elasticity_all_taxes"]; W5 = FR["estimates"]["drop_5k"]
check("pile $16,900; without $5k: $5,200 and $400; holes $12,500 and $35,600 no wider than the dominated range",
      round(Ea["2000000"]["pile"], -2) == 16900 and round(W5["2000000"]["pile"], -2) == 5200 and round(W5["2000000"]["hole"], -2) == 400
      and [round(W5[X]["hole"], -2) for X in ("3000000", "5000000")] == [12500, 35600]
      and all(round(W5[X]["hole"], -2) <= round(EL["all"][X]["dominated_range_dollars"], -2) for X in ("3000000", "5000000"))
      and intext("\\$16{,}900 of price", "shrinks to\n\\$5{,}200 and the hole above it to \\$400", "\\$12{,}500 and \\$35{,}600"))
L1 = FR["level_1M"]
check("$1M: three-quarters of the pile width within $5,000", 0.70 <= 1 - L1["drop_5k"]["pile"] / L1["all"]["pile"] <= 0.80 and intext("three-quarters of its\npost-reform pile width"))
NE = J("notch_elasticity.json")["thresholds"]; km = {X: NE[X]["kopczuk_munroe"] for X in NE}
check("local incidence 3.38; Z at $1M -$4,581 and KM-style $26,800", f"{km['2000000']['h_over_T']['est']:.2f}" == "3.38"
      and round(km["1000000"]["Z_dollars"]["est"]) == -4581 and km["1000000"]["Z_dollars"]["ci"][1] < 0
      and all(km[X]["Z_dollars"]["ci"][0] < 0 < km[X]["Z_dollars"]["ci"][1] for X in ("2000000", "3000000", "5000000"))
      and round(J("km_unraveling.json")["closest_to_kopczuk_munroe"]["1000000"]["Z_dollars"], -2) == 26800
      and J("km_unraveling.json")["closest_to_kopczuk_munroe"]["1000000"]["Z_ci"][0] > 0 and intext("is 3.38 at", "($-$\\$4{,}581)", "(\\$26{,}800)"))
new = [EL["all"][X][k] for X in ("2000000", "3000000", "5000000") for k in ("pile", "hole")]
ex5 = [v for X in ("2000000", "3000000", "5000000") for k, v in EL["drop_5k"][X].items() if k in ("pile", "hole") and v == v]
check("elasticities 0.004-0.017 (all sales), 0.04-0.05 at $1M, 0.006 or less without $5k",
      f"{min(new):.3f}" == "0.004" and f"{max(new):.3f}" == "0.017" and 0.035 <= min(NE["1000000"][k]["e_all"] for k in ("pile", "hole")) and max(NE["1000000"][k]["e_all"] for k in ("pile", "hole")) < 0.055
      and max(ex5) <= 0.006 and intext("elasticities of 0.004 to 0.017", "0.04\nto 0.05 at \\$1{,}000{,}000", "fall to 0.006 or less"))
md0 = md[0] / 5000
check("local incidence for movers: about half / under a fifth", 0.4 <= md0 <= 0.55 and md[1] / 15000 < 0.2 and md[2] / 37500 < 0.2)
LA = FI["loan_amounts_near_threshold"]
b2, p2, x2, b3 = LA["2000000_post_just_below"], LA["2000000_pre_just_below"], LA["2000000_post_at_X"], LA["3000000_post_just_below"]
check("loan sizing: 353 / 10% / 43% / 8% of 37 / 71% / 7% and 43% of 156",
      (b2["n"], round(100 * b2["share_of_X"]), round(100 * b2["share_of_P_only"]), p2["n"], round(100 * p2["share_of_X"]), round(100 * x2["share_of_X"]), b3["n"], round(100 * b3["share_of_X"]), round(100 * b3["share_of_P_only"]))
      == (353, 10, 43, 37, 8, 71, 156, 7, 43) and intext("Among 353 financed post-reform", "(8\\% of 37)", "71\\% of loans", "7\\% and\n43\\% of 156"))
RV = CS["revenue"]; bt = RV["by_threshold"]; BM = J("benchmarks_v29.json"); FS = BM["full_schedule"]; AV = FI["avoided_tax"]
check("tab_cost.tex generated", generated("tab_cost.tex"))
ex = [round(bt[X]["excess_sales_per_year"]) for X in ("2000000", "3000000", "5000000")]
check(f"extra sales {ex}, each pile larger than any placebo", ex == [129, 45, 30] and all(bt[X]["placebos_excess_share_as_large"] == 0 for X in ("2000000", "3000000", "5000000"))
      and intext("about 129 extra sales a\nyear sit just below \\$2{,}000{,}000, 45 below \\$3{,}000{,}000 and 30 below"))
ci_ = RV["avoided_total_per_year_ci"]
check("avoided $2.4M [1.9, 3.0]; direct 2.9; every row 2.2; net 1.6; range 1.6-2.9; under 1% of $296M",
      f"{RV['avoided_total_per_year'] / 1e6:.1f}" == "2.4" and [f"{c / 1e6:.1f}" for c in ci_] == ["1.9", "3.0"]
      and [f"{AV[k] / 1e6:.1f}" for k in ("b_direct_counts", "d_all_rows", "c_net_of_control")] == ["2.9", "2.2", "1.6"]
      and AV["max_share_of_revenue"] < 0.01 and round(FS["revenue_per_year"] / 1e6) == 296
      and intext("they avoid \\$2.4 million a year at the jump alone (95\\% interval\n\\$1.9--3.0 million", "directly gives \\$2.9 million, every row of the sales file \\$2.2 million, and\nnetting out the control's own excess \\$1.6 million",
                 "avoid \\$1.6 to \\$2.9 million a year, under 1\\% of", "\\$296 million a year"))
VS = J("volume_shares.json")
v0, v1 = 100 * VS["pre_2016_2019q1"]["share"], 100 * VS["post_2020_2025"]["share"]
check("volume 35.2% -> 32.7%, 2.5 points", f"{v0:.1f}" == "35.2" and f"{v1:.1f}" == "32.7" and f"{v0 - v1:.1f}" == "2.5" and intext("were 35.2\\% of sales", "and 32.7\\% in 2020--2025, a decline of 2.5 points"))
check("tab_slice.tex generated", generated("tab_slice.tex"))
cm = FS["B_cumulative_marginal_rates_pct"]
check("slices: 2.36%, 77%; 0.48% to 6.11%, 7%", f"{FS['A_single_marginal_rate_above_2M_pct']:.2f}" == "2.36" and round(100 * FS["share_paying_more_A"]) == 77
      and f"{cm['above 2M']:.2f}" == "0.48" and f"{cm['above 25M']:.2f}" == "6.11" and round(100 * FS["share_paying_more_B"]) == 7
      and intext("One marginal rate of 2.36\\%", "77\\% of these\nsales would pay more", "from\n0.48\\% above \\$2{,}000{,}000 to 6.11\\%", "and 7\\% of sales would pay more"))
bb = FS["mean_tax_by_band"]
check("slice band pattern", all(bb[k]["A"] > bb[k]["notch"] and bb[k]["B"] < bb[k]["notch"] for k in ("2M-3M", "3M-5M", "5M-10M"))
      and all(bb[k]["A"] < bb[k]["notch"] and bb[k]["B"] > bb[k]["notch"] for k in ("10M-25M", "25M-infM")))
HF = J("headline_figure.json")
check("Figure 1 caption numbers", intext(f"gains {HF['2000000']['change_below_pts']:.1f}, {HF['3000000']['change_below_pts']:.1f} and {HF['5000000']['change_below_pts']:.1f} percentage points",
      f"loses {-HF['2000000']['change_from_X_pts']:.1f}, {-HF['3000000']['change_from_X_pts']:.1f} and {-HF['5000000']['change_from_X_pts']:.1f}"))
DM = J("deed_merge_check.json"); RK = DM["rows_removed_by_kind"]; NEWX = ("2000000", "3000000", "5000000")
sk = lambda k: sum(RK[X].get(k, 0) for X in NEWX)
abv = [DM["rows_removed_by_zone_and_kind"][X]["post"]["above"] for X in ("3000000", "5000000")]
check("deed rule vs ACRIS: 1,354 = 567 + 278 + 386 + 51 + 51 + 21; none wrong above $3M/$5M; $1M 151 of 382",
      sum(sum(RK[X].values()) for X in NEWX) == 1354 and [sk(k) for k in ("one_acris_deed", "same_lot_same_address", "coop_apartments_bulk_price", "separate_acris_deeds", "coop_apartments_unit_price", "not_found")] == [567, 278, 386, 51, 51, 21]
      and all(set(a) <= {"one_acris_deed", "same_lot_same_address", "coop_apartments_bulk_price"} for a in abv)
      and RK["1000000"]["separate_acris_deeds"] == 151 and sum(v for k, v in RK["1000000"].items() if k != "partly_found") == 382
      and generated("tab_merge.tex")
      and intext("it removes 1{,}354 rows", "567 belong to", "278 repeat the same", "and 386 are co-operative", "Only 51 are separate deeds", "another 51 are", "and 21 have no deed", "151 of the 382 rows"))
RP = J("did_round_placebos.json"); pr = lambda b, z: round(100 * b["pooled"][f"b_{z}"]["pct"])
mwc = RP["matched_with_control"]["pooled"]["b_z5_above"]
check("round-matched and no-company DID table cells match current output",
    generated("tab_did.tex") and intext("a company seller the changes are "+sgpct(RP["no_company_seller"]["pooled"]["b_z4_at_X"]["pct"])+" and "+sgpct(RP["no_company_seller"]["pooled"]["b_z5_above"]["pct"])))
check("intro measurement paragraph: 0.223 -> 0.041; $16,900 vs $2,400", intext("rises by 0.223, more than at any never-taxed placebo", "it rises by 0.041, which is within placebo noise", "\\$16{,}900 of price, against an average move of about \\$2{,}400"))
check("introduction: 22% and 28%, about 0.6, 24 placebos", intext("fall by 22\\% at \\$3{,}000{,}000 and 28\\% at \\$5{,}000{,}000", "about 0.6 for jumps from", "24 never-taxed\nround prices"))

# ---------- loan notch ----------
LN = J("loan_notch.json"); LG = J("loan_notch_grid.json")["summary"]; LC = J("loan_notch_checks.json"); RA = LC["round_amounts"]
r5 = LN["thresholds"]["500000"]
check("observed-loan count and exact/near $500k counts match output",
    sum(LN["loans"].values()) == J("revenue_neutral.json")["sample"]["financed_loan_observed"]
    and intext(tn(sum(LN["loans"].values()))+" purchase mortgages",
               tn(RA["500000"]["at_X"])+" are for exactly",
               tn(r5["just_below_1000"])+" lie in"))
oth = [v for X, v in RA.items() if X != "500000"]
check("round-loan shares and relative frequencies match output",
    intext("between "+str(round(100*min(v["share_at_X_of_last_1000"] for v in oth)))+BS+"% and "+str(round(100*max(v["share_at_X_of_last_1000"] for v in oth)))+BS+"%",
           f"({RA['500000']['just_below_per_25k_below']:.3f} against {min(v['just_below_per_25k_below'] for v in oth):.3f} to {max(v['just_below_per_25k_below'] for v in oth):.3f})"))
check("loan excess, uncertainty and specification widths match corrected output",
    intext(f"threshold is {r5['b_ratio']:.2f} (95"+BS+f"% interval {r5['ci']['b_ratio'][0]:.2f} to {r5['ci']['b_ratio'][1]:.2f})",
           "equivalent to "+money(round(r5["pile_dollars"],-2))+" of loan",
           money(round(LG["pile_min"],-2))+" to "+money(round(LG["pile_max"],-2))+" across 27 specifications"))
yr_ = [v["at_500k"]["ratio"] for v in LC["by_year"].values()]; pj = LC["price_just_below_a_transfer_tax_threshold"]
check("annual loan ratios and price-threshold shares match corrected output",
    intext(f"between {min(yr_):.2f} and {max(yr_):.2f} in every year",
           str(round(100*LC["price_just_below_a_transfer_tax_threshold"]["share"]))+BS+"% of the loans just below",
           str(round(100*LC["price_just_below_a_transfer_tax_threshold"]["share_above"]))+BS+"% of those"))

# ---------- recording tax (Supplemental Appendix I) and loan-to-value (G) ----------
V = J("revenue_neutral.json"); r = V["revenue_per_year"]; S = V["schedules"]
check("gross MRT costing, loan counts and sample match corrected output",
    abs(r["borrower_mrt_observed_loans"]+r["borrower_mrt_imputed_houses"]+r["borrower_mrt_imputed_condos"]-r["borrower_mrt_with_imputation"])<1e-5
    and intext("about "+money(round(r["borrower_mrt_with_imputation"]/1e6))+" million a year",
               BS+"textbf{Total} & "+BS+f"textbf{{{r['borrower_mrt_with_imputation']/1e6:.1f}}}",
               f"Total on observed loan amounts only & {r['borrower_mrt_observed_loans']/1e6:.1f}",
               tn(V["sample"]["purchases"])+" purchases between"))
check("replacement schedules match corrected fixed-sample costing",
    intext(f"{S['A_flat']['tau_percent']:.2f}"+BS+"% of the whole price",
           f"{S['B_above_500k']['tau_percent']:.2f}"+BS+"% of the price",
           f"{S['C_two_bracket']['tau_percent']:.2f}"+BS+"% between",
           f"{V['by_property_type_flat_rate_percent']['house']:.2f}"+BS+"% for houses and "+f"{V['by_property_type_flat_rate_percent']['condo']:.2f}"+BS+"% for")
    and all(abs(v["revenue_check_per_year"]-r["borrower_mrt_with_imputation"])<1e-5 for v in S.values()))
T4 = V["table4_burden_on_observed_loans"]
check("observed-loan table counts agree with costing",
    T4["houses"]["loans"]+T4["condominiums"]["loans"]==V["sample"]["financed_loan_observed"]
    and intext(tn(V["sample"]["financed_loan_observed"])+" financed house and condominium purchases",
               BS+"textbf{1.41"+BS+"%}",BS+"textbf{1.28"+BS+"%}"))
MR = BM["mortgage_recording_tax"]; mm = MR["mean_2016_2024"]; rr = [v["ratio_all_levies_to_dof"] for v in MR["by_year"].values()]
check("comparison with DOF matches updated all-levy panel benchmark",
    intext("averaged "+money(round(mm["dof_residential_liability"]))+" million a year",
           money(round(mm["panel_all_levies"]))+" million a year",
           str(round(100*mm["ratio"]))+BS+"% of the city's figure and between "+str(round(100*min(rr)))+BS+"% and "+str(round(100*max(rr)))+BS+"% in each year"))
L = J("ltv_charm.json")["models"]["buyer_paid_1M_2M_3M"]; c_, cse = L["continuous_per_10pts"][0]["ltv10"]; h_, hse = L["ltv_ge_80"][0]["high_ltv"]
check("LTV houses: 627, 0.3 (0.9), 12 less (3.4)", L["continuous_per_10pts"][1] == 627 and round(100 * c_, 1) == 0.3 and round(100 * cse, 1) == 0.9 and round(-100 * h_) == 12 and round(100 * hse, 1) == 3.4
      and intext("Among 627 financed house purchases", "rises by 0.3 percentage points per ten points", "12 points \\emph{less} often (standard error 3.4)"))
LQ = CS["liquidity_with_condos"]; hc = LQ["houses_and_condominiums"]; c10, c10se = hc["per_10pts"][0]["ltv10"]; h80, h80se = hc["ltv_ge_80"][0]["high_ltv"]
check("condo LTV counts, slope and uncertainty match updated output",
    intext("Adding the "+str(LQ["condominiums"]["n"])+" financed condominium purchases",
           f"association of {100*c10:.1f} percentage points",
           f"standard error {100*c10se:.1f}",
           str(round(-100*h80))+" points less often (standard error "+f"{100*h80se:.1f}"))

# ---------- withdrawn wording ----------
check("no replication-version tags or revision history in the paper", "package v1." not in flat and "version 2." not in flat.lower() and "referee\\_v24" not in flat and "referee\\_extensions" not in flat and "through version" not in flat)
for bad in ["more than three times the tax it saves", "by over three times the tax saved", "two to three times as wide", "a third to a tenth",
            "direct evidence that borrowers", "Slow learning does not explain it", "old notches would overstate", "the two notches that have existed for decades",
            "did not fall relative to cheaper sales", "Each new threshold's response is larger", "2--3\\% of schedule-implied revenue", "who pays matters",
            "Incidence matters", "rank $p$-values", "sixteen independent placebos", "fits limited attention better", "collapsing rows that share a sale date, borough and price",
            "large, individually significant values of both signs"]:
    check(f"withdrawn phrase absent: {bad!r}", re.sub(r"\s+", " ", bad) not in flat)
check("corrected panel decomposition sums to 253,288", 166907+86381==V['sample']['purchases'] and intext("166{,}907 houses and 86{,}381 condominiums") and "82{,}488 condominiums" not in flat)
n = sum(res); print(f"{n} of {len(res)} checks pass."); sys.exit(0 if n == len(res) else 1)
