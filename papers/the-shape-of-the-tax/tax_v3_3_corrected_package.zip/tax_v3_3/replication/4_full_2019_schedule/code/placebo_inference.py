"""v1.5: placebo-calibrated inference for the 2019 notch estimates.

The bootstrap intervals in Tables 3 and 5 price sampling error but not
specification error (Section 5.8). This script replaces them as the basis for
inference with a placebo distribution: the same post-minus-pre statistic,
computed with the same estimator at every never-taxed $50,000 multiple whose
estimation window contains no statutory threshold. Each treated estimate is
then reported as a rank within that distribution, and the equality and
proportionality tests of Section 5.6 are redone on the same scale. v1.8: the
ranks and shares are reference comparisons, not calibrated p-values; a
calibrated rank test would need an exchangeability argument this design lacks.

Two estimators, both unchanged:
  - scaled (Table 5, equality_test.py): Kleven-Waseem share in a +/-0.2X window,
    and log R with R = N[X, 1.05X) / N[0.925X, 0.975X);
  - fixed (Table 2, prepost.py): +/-$400,000 window in $10,000 bins, and log R
    with R = N[X, X+100k) / N[X-150k, X-50k).

Placebo sets. Core: $1.2M-$6M, the range used for the main comparisons. Extended: up
to the last eligible price below the $10M threshold's windows. A placebo is
eligible only if no threshold of the city or state schedules ($500k, $1M, $2M,
$3M, $5M, $10M, ...) lies inside its estimation window.

Rank p-values are one-sided in the direction a notch predicts (bunching up,
R down): p = (1 + #placebos at least as extreme) / (1 + #placebos). Tests of
differences between thresholds use the distribution of the same difference
computed between pairs of distinct placebos. Output: output/placebo_inference.json.
"""
import csv, gzip, itertools, json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parent
# The two published estimators, loaded without re-running their scripts.
_te = (ROOT / "code/threshold_extension.py").read_text().split("\nout = {}")[0]
TE = {"__file__": str(ROOT / "code/threshold_extension.py")}
exec(compile(_te, "threshold_extension.py", "exec"), TE)
_pp = (REPO / "2_tables/prepost.py").read_text()
_pp = _pp[_pp.index("def round_dummies"):_pp.index("def boot(")]
PP = {"np": np}
exec(compile(_pp, "prepost.py", "exec"), PP)

price, date = TE["price"], TE["date"]          # every sale above $300,000, 2016-2025
PRE, POST = TE["PRE"], TE["POST"]
pre, post = price[PRE], price[POST]
THRESHOLDS = [500_000, 1_000_000, 2_000_000, 3_000_000, 5_000_000, 10_000_000,
              15_000_000, 20_000_000, 25_000_000]
TREATED = [2_000_000, 3_000_000, 5_000_000]
CONTROL = 1_000_000
BUYER_PP = {2_000_000: 0.25, 3_000_000: 0.25, 5_000_000: 0.75}


def n(p, lo, hi):
    return int(((p >= lo) & (p < hi)).sum())


def eligible(x, lo, hi):
    return x not in THRESHOLDS and not any(lo <= t < hi for t in THRESHOLDS)


def scaled(x):
    kw = TE["kw"](post, x)[0] - TE["kw"](pre, x)[0]
    a, b = n(pre, x, 1.05 * x), n(pre, 0.925 * x, 0.975 * x)
    c, d = n(post, x, 1.05 * x), n(post, 0.925 * x, 0.975 * x)
    r = float(np.log(c / d) - np.log(a / b)) if min(a, b, c, d) > 0 else None
    return {"kw_diff": float(kw), "logR_change": r, "window_n_pre": n(pre, 0.8 * x, 1.2 * x),
            "window_n_post": n(post, 0.8 * x, 1.2 * x)}


def fixed(x):
    bunch = PP["estimate"](post, x)["share"] - PP["estimate"](pre, x)["share"]
    a, b = n(pre, x, x + 100_000), n(pre, x - 150_000, x - 50_000)
    c, d = n(post, x, x + 100_000), n(post, x - 150_000, x - 50_000)
    r = float(np.log(c / d) - np.log(a / b)) if min(a, b, c, d) > 0 else None
    return {"kw_diff": float(bunch), "logR_change": r, "window_n_pre": n(pre, x - 400_000, x + 400_000)}


GRID = [x for x in range(1_200_000, 9_600_001, 50_000)]
SETS = {
    "scaled": (scaled, [x for x in GRID if eligible(x, 0.8 * x, 1.2 * x)]),
    "fixed": (fixed, [x for x in GRID if eligible(x, x - 400_000, x + 400_000)]),
}


def rank_p(v, ref, upper):
    ref = np.asarray([r for r in ref if r is not None])
    k = (ref >= v).sum() if upper else (ref <= v).sum()
    return float((1 + k) / (1 + len(ref))), int(len(ref))


def pair_p(stat, vals, a, b):
    """Two-sided p for H0: d_A = b * d_B, from a*p_i - b*p_j over distinct placebo pairs."""
    ref = np.array([vi - b * vj for (i, vi), (j, vj) in itertools.product(enumerate(vals), repeat=2) if i != j])
    return float(np.mean(np.abs(ref) >= abs(stat))), int(len(ref))


out = {"grid_step": 50_000, "thresholds_excluded_from_windows": THRESHOLDS}
for name, (fn, placebos) in SETS.items():
    core = [x for x in placebos if x <= 6_000_000]
    res = {"placebos_core": core, "placebos_extended": placebos}
    stats = {x: fn(x) for x in placebos + [CONTROL] + TREATED}
    res["values"] = {str(x): v for x, v in stats.items()}
    for label, pl in (("core", core), ("extended", placebos)):
        kw_ref = [stats[x]["kw_diff"] for x in pl]; r_ref = [stats[x]["logR_change"] for x in pl]
        blk = {"n_placebos": len(pl),
               "placebo_kw": {"mean": float(np.mean(kw_ref)), "sd": float(np.std(kw_ref, ddof=1)),
                              "p05": float(np.percentile(kw_ref, 5)), "p95": float(np.percentile(kw_ref, 95)),
                              "max": float(np.max(kw_ref)), "mean_abs": float(np.mean(np.abs(kw_ref)))},
                "placebo_logR": {"p05": float(np.percentile([r for r in r_ref if r is not None], 5)),
                                 "min": float(np.min([r for r in r_ref if r is not None]))}}
        for x in [CONTROL] + TREATED:
            if name == "fixed" and x == 5_000_000:
                continue    # Table 2 covers the thresholds below $5M only
            s = stats[x]
            blk[str(x)] = {"kw_diff": s["kw_diff"], "kw_rank_p": rank_p(s["kw_diff"], kw_ref, True)[0],
                           "kw_z": (s["kw_diff"] - np.mean(kw_ref)) / np.std(kw_ref, ddof=1),
                           "logR_change": s["logR_change"], "logR_rank_p": rank_p(s["logR_change"], r_ref, False)[0]}
        if name == "scaled":
            d = {x: stats[x]["kw_diff"] for x in TREATED}
            for tname, (A, B, mult) in {"5M_minus_2M": (5_000_000, 2_000_000, 1.0),
                                        "5M_minus_3x2M": (5_000_000, 2_000_000, 3.0),
                                        "3M_minus_2M": (3_000_000, 2_000_000, 1.0)}.items():
                st = d[A] - mult * d[B]
                p, m = pair_p(st, kw_ref, 1.0, mult)
                blk[tname] = {"estimate": float(st), "p_two_sided": p, "pairs": m}
        res[label] = blk
    out[name] = res

# Size-matched placebos (scaled estimator). A placebo window with more sales
# than a treated threshold's is resampled, with replacement, to exactly the
# treated window's pre and post counts, K times. v1.5-v1.7 drew without
# replacement; each draw then took up to three-quarters of a placebo window, so
# the draws varied less than repeated samples of that size from the placebo's
# price distribution would. The pooled draws are a reference distribution at
# the treated threshold's own sample size that mixes sampling and specification
# error; they are not an exchangeable null. Placebos with fewer sales than the
# treated window cannot be matched and are not used.
K = 50
rng = np.random.default_rng(20260926)
win = lambda p, x: p[(p >= 0.8 * x) & (p < 1.2 * x)]
kw = TE["kw"]
matched = {}
for T in TREATED:
    a, b = win(pre, T), win(post, T)
    draws, used = [], []
    for x in SETS["scaled"][1]:
        wa, wb = win(pre, x), win(post, x)
        if len(wa) < len(a) or len(wb) < len(b):
            continue
        used.append(x)
        draws.append([kw(rng.choice(wb, len(b), replace=True), x)[0] - kw(rng.choice(wa, len(a), replace=True), x)[0]
                      for _ in range(K)])
    matched[T] = (used, np.array(draws))
sm = {"K_per_placebo": K, "seed": 20260926}
for T in TREATED:
    used, D = matched[T]; flat = D.ravel(); v = out["scaled"]["values"][str(T)]
    sm[str(T)] = {"placebos": used, "n_pre": int(len(win(pre, T))), "n_post": int(len(win(post, T))),
                  "draws": int(flat.size), "null_sd": float(flat.std(ddof=1)), "null_p95": float(np.percentile(flat, 95)),
                  "null_max": float(flat.max()), "kw_diff": v["kw_diff"],
                  "z": float((v["kw_diff"] - flat.mean()) / flat.std(ddof=1)),
                  "p_draws": float((1 + (flat >= v["kw_diff"]).sum()) / (1 + flat.size)),
                  "placebos_with_any_draw_as_large": int((D >= v["kw_diff"]).any(axis=1).sum())}
d = {x: out["scaled"]["values"][str(x)]["kw_diff"] for x in TREATED}
for tname, (A, B, mult) in {"5M_minus_2M": (5_000_000, 2_000_000, 1.0),
                            "5M_minus_3x2M": (5_000_000, 2_000_000, 3.0),
                            "3M_minus_2M": (3_000_000, 2_000_000, 1.0)}.items():
    (uA, DA), (uB, DB) = matched[A], matched[B]
    ref = np.concatenate([DA[i][:, None] - mult * DB[j][None, :]
                          for i, xa in enumerate(uA) for j, xb in enumerate(uB) if xa != xb], axis=None)
    st = d[A] - mult * d[B]
    sm[tname] = {"estimate": float(st), "p_two_sided": float(np.mean(np.abs(ref) >= abs(st))),
                 "null_sd": float(ref.std(ddof=1)), "reference_draws": int(ref.size)}
    # v1.8: the same share over placebo pairs whose +/-20% windows do not overlap.
    dj = [DA[i][:, None] - mult * DB[j][None, :] for i, xa in enumerate(uA) for j, xb in enumerate(uB)
          if not (0.8 * xa < 1.2 * xb and 0.8 * xb < 1.2 * xa)]
    if dj:
        ref = np.concatenate(dj, axis=None)
        sm[tname]["disjoint_windows"] = {"p_two_sided": float(np.mean(np.abs(ref) >= abs(st))),
                                         "location_pairs": len(dj), "reference_draws": int(ref.size)}
out["scaled"]["size_matched"] = sm

(ROOT / "output/placebo_inference.json").write_text(json.dumps(out, indent=1))
print("\n[scaled / size-matched]")
for T in TREATED:
    v = sm[str(T)]
    print(f"  {T:>11,} n={v['n_pre']}/{v['n_post']} placebos={len(v['placebos'])} draws={v['draws']} null sd {v['null_sd']:.3f} "
          f"p95 {v['null_p95']:+.3f} max {v['null_max']:+.3f} | kw {v['kw_diff']:+.3f} z={v['z']:+.1f} p={v['p_draws']:.4f}")
for t in ("5M_minus_2M", "5M_minus_3x2M", "3M_minus_2M"):
    print(f"  {t:<14} {sm[t]['estimate']:+.3f}  p={sm[t]['p_two_sided']:.4f}  null sd {sm[t]['null_sd']:.3f}")
for name in SETS:
    for label in ("core", "extended"):
        b = out[name][label]
        print(f"\n[{name} / {label}] {b['n_placebos']} placebos; placebo kw diff mean {b['placebo_kw']['mean']:+.3f} "
              f"sd {b['placebo_kw']['sd']:.3f} 95th {b['placebo_kw']['p95']:+.3f} max {b['placebo_kw']['max']:+.3f}")
        for x in [CONTROL] + TREATED:
            if str(x) in b:
                v = b[str(x)]
                print(f"  {x:>11,}  kw {v['kw_diff']:+.3f}  p={v['kw_rank_p']:.3f}  z={v['kw_z']:+.1f}   "
                      f"dlogR {v['logR_change']:+.3f}  p={v['logR_rank_p']:.3f}")
        for t in ("5M_minus_2M", "5M_minus_3x2M", "3M_minus_2M"):
            if t in b:
                print(f"  {t:<14} {b[t]['estimate']:+.3f}  p={b[t]['p_two_sided']:.3f}  ({b[t]['pairs']} pairs)")
