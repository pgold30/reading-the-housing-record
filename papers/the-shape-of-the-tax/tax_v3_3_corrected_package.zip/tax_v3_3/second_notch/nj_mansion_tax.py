"""New Jersey's 2004 mansion tax: the round-price test with a before period.

Data: Rutgers MOD IV residential rolls (data_external/new_jersey/; see its SOURCE.md). Each roll
row is a Class 2 parcel with its most recent deed: the 2004 roll supplies deeds dated 1999-2003
(before the fee took effect on 1 August 2004), the 2009 roll deeds dated August 2004 to July 2009.
The files cover parts of Bergen, Essex and Monmouth counties only (500,000 rows per roll).
Prices of at least $100,000. Window [0.9X, 1.1X). Bootstrap: 2,000 draws resampling sales within
each period's window (seed 20261016).

Usage: python3 nj_mansion_tax.py DATA_DIR > nj_mansion_tax.json
"""
import sys, json
import numpy as np, pandas as pd

def load(path, year, a, b):
    d = pd.read_csv(f"{path}/nj_modiv_{year}_residential.csv.gz", usecols=["property_class", "deed_date_MMDDYY", "sale_price"], low_memory=False)
    d["dt"] = pd.to_datetime(d.deed_date_MMDDYY, errors="coerce")
    d = d[(d.dt >= a) & (d.dt <= b) & (d.sale_price >= 100_000) & (d.property_class.astype(str) == "2")]
    return d.sale_price.to_numpy()

def main(path):
    pre, post = load(path, 2004, "1999-01-01", "2003-12-31"), load(path, 2009, "2004-08-01", "2009-07-31")
    win = lambda v, X: v[(v >= 0.9 * X) & (v < 1.1 * X)]
    X = 1_000_000; w0, w1 = win(pre, X), win(post, X)
    s0, s1 = (w0 == X).mean(), (w1 == X).mean()
    rng = np.random.default_rng(20261016)
    bs = [1 - (rng.choice(w1, len(w1)) == X).mean() / (rng.choice(w0, len(w0)) == X).mean() for _ in range(2000)]
    placebos = {}
    for P in [800_000, 900_000, 1_100_000, 1_200_000, 1_250_000, 1_500_000]:
        a, b = win(pre, P), win(post, P); placebos[P] = round(float((b == P).mean() / (a == P).mean()), 3)
    sc = len(w1) / len(w0); landed = {}
    for lo, hi in [(1, 1), (2, 999), (1000, 1000), (1001, 4999), (5000, 5000), (5001, 10000), (10001, 25000)]:
        n0 = int(((pre >= X - hi) & (pre <= X - lo)).sum()); n1 = int(((post >= X - hi) & (post <= X - lo)).sum())
        landed[f"{lo}-{hi} below"] = {"pre": n0, "post": n1, "excess": round(n1 - n0 * sc, 1)}
    out = {"sales_pre": int(len(pre)), "sales_post": int(len(post)), "window_pre": int(len(w0)), "window_post": int(len(w1)),
           "share_at_X": [round(float(s0), 4), round(float(s1), 4)], "sales_at_X": [int((w0 == X).sum()), int((w1 == X).sum())],
           "sales_at_X_minus_1": [int((w0 == X - 1).sum()), int((w1 == X - 1).sum())],
           "moved_share": round(float(1 - s1 / s0), 3), "moved_share_95": [round(float(x), 3) for x in np.percentile(bs, [2.5, 97.5])],
           "placebo_ratio_at_round_price": placebos,
           "moved_share_placebo_adjusted": round(float(1 - (s1 / s0) / np.mean(list(placebos.values()))), 3),
           "share_above_(X,1.05X]": [round(float(((w0 > X) & (w0 <= 1.05 * X)).mean()), 4), round(float(((w1 > X) & (w1 <= 1.05 * X)).mean()), 4)],
           "where_extra_sales_landed": landed}
    print(json.dumps(out, indent=1))

if __name__ == "__main__":
    main(sys.argv[1])
