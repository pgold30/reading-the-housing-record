"""Los Angeles Measure ULA: does the round-price margin follow the statute or the round number?

ULA taxes consideration ABOVE an indexed threshold (Green et al. 2026, Table 1):
  1 Apr 2023 - 30 Jun 2024  > $5,000,000
  1 Jul 2024 - 30 Jun 2025  > $5,150,000
  1 Jul 2025 - 30 Jun 2026  > $5,300,000
So a sale at exactly the threshold is untaxed, unlike New York's 2019 notches, which apply at
the threshold. And from July 2024 the threshold is no longer a round number.

Predictions written before any Los Angeles data were read (16 October 2026):
  P1  Apr 2023 - Jun 2024: sales at exactly $5,000,000 rise relative to January 2018 - September
      2022, and sales at $4,999,999 do not (a sale at the round price is already safe). The
      New York signature, a jump at X-1, should be absent.
  P2  From July 2024: if parties price at the statutory ceiling, sales appear at exactly
      $5,150,000 (then $5,300,000). If round numbers dominate, the extra sales stay at
      $5,000,000 and the band ($5,000,000, $5,150,000] stays thin.
  P3  The missing mass sits just above whichever threshold is in force: (X, 1.05X] falls
      relative to the pre-period, period by period.
Note (16 October 2026): the same prediction failed in New Jersey, where sales left the untaxed
$1,000,000 (nj_mansion_tax.py). P1 should now be read as the hypothesis to reject.
These would be judged against the same counts at never-taxed round prices (default
$4,000,000, $4,500,000, $6,000,000, $7,000,000 and $8,000,000).

Input: CSV with `sale_date` (YYYY-MM-DD) and `price` (whole dollars), one row per deed,
ideally single-family and condominium sales in the City of Los Angeles. Output: JSON of
sales per year at each point and band, by period, with Poisson 95% intervals for the
post/pre ratios. The run between October 2022 (passage) and March 2023 is dropped by default.

  python3 la_ula_test.py sales.csv [--placebos ...]
  python3 la_ula_test.py --selftest
"""
import argparse, csv, json, math, datetime as dt
import numpy as np

PERIODS = [("pre", "2018-01-01", "2022-09-30", None),
           ("ula_5000000", "2023-04-01", "2024-06-30", 5_000_000),
           ("ula_5150000", "2024-07-01", "2025-06-30", 5_150_000),
           ("ula_5300000", "2025-07-01", "2026-06-30", 5_300_000)]
THRESHOLDS = [5_000_000, 5_150_000, 5_300_000]


def load(path):
    out = []
    for r in csv.DictReader(open(path)):
        try:
            out.append((dt.date.fromisoformat(r["sale_date"][:10]), int(round(float(r["price"])))))
        except (ValueError, KeyError):
            pass
    return out


def counts(prices, X):
    p = prices
    return {"exactly_X": int((p == X).sum()), "X_minus_1": int((p == X - 1).sum()),
            "(X-25000, X)": int(((p > X - 25_000) & (p < X)).sum()),
            "(X, 1.05X]": int(((p > X) & (p <= 1.05 * X)).sum()),
            "[0.9X, 1.1X)": int(((p >= 0.9 * X) & (p < 1.1 * X)).sum())}


def ratio_ci(n1, y1, n0, y0):
    """Rate ratio (n1/y1)/(n0/y0) with a log-normal Poisson interval."""
    if n0 == 0 or n1 == 0:
        return None
    r = (n1 / y1) / (n0 / y0); se = math.sqrt(1 / n1 + 1 / n0)
    return [round(r, 3), round(r * math.exp(-1.96 * se), 3), round(r * math.exp(1.96 * se), 3)]


def analyse(rows, placebos):
    res = {}
    by = {}
    for name, a, b, _ in PERIODS:
        a, b = dt.date.fromisoformat(a), dt.date.fromisoformat(b)
        sel = [p for d, p in rows if a <= d <= b]
        last = max([d for d, _ in rows if a <= d <= b], default=a)
        years = max((min(b, last) - a).days + 1, 1) / 365.25
        by[name] = (np.array(sel, dtype=np.int64), years)
    pre, ypre = by["pre"]
    for name, _, _, Xlaw in PERIODS[1:]:
        p, y = by[name]
        if len(p) == 0:
            continue
        block = {"years": round(y, 2), "threshold_in_force": Xlaw, "points": {}}
        for X in THRESHOLDS + placebos:
            c1, c0 = counts(p, X), counts(pre, X)
            block["points"][str(X)] = {k: {"per_year_pre": round(c0[k] / ypre, 1), "per_year_post": round(c1[k] / y, 1),
                                           "ratio_ci": ratio_ci(c1[k], y, c0[k], ypre)} for k in c1}
        # band between the round price and the indexed threshold
        if Xlaw > 5_000_000:
            n1 = int(((p > 5_000_000) & (p <= Xlaw)).sum()); n0 = int(((pre > 5_000_000) & (pre <= Xlaw)).sum())
            block["band_(5000000, threshold]"] = {"per_year_pre": round(n0 / ypre, 1), "per_year_post": round(n1 / y, 1),
                                                  "ratio_ci": ratio_ci(n1, y, n0, ypre)}
        res[name] = block
    res["pre_years"] = round(ypre, 2)
    return res


def selftest():
    """Synthetic market where the plants follow P1-P3; checks the script recovers them."""
    rng = np.random.default_rng(20261016); rows = []
    day = lambda a, b: dt.date.fromisoformat(a) + dt.timedelta(days=int(rng.integers(0, (dt.date.fromisoformat(b) - dt.date.fromisoformat(a)).days)))
    for name, a, b, X in PERIODS:
        n = {"pre": 6000, "ula_5000000": 1500, "ula_5150000": 1200, "ula_5300000": 1200}[name]
        for _ in range(n):
            p = float(np.exp(rng.normal(np.log(3_000_000), 0.5)))
            if rng.random() < 0.3:
                p = round(p, -5)                       # round-price sales
            p = int(p)
            if X and X < p <= 1.05 * X and rng.random() < 0.6:
                p = X if rng.random() < 0.5 else 5_000_000   # moved: half to the ceiling, half to the round price
            rows.append((day(a, b), p))
    r = analyse(rows, [4_500_000, 6_000_000])
    b = r["ula_5150000"]
    assert b["points"]["5000000"]["(X, 1.05X]"]["ratio_ci"] is not None
    assert b["band_(5000000, threshold]"]["ratio_ci"][0] > 1, b["band_(5000000, threshold]"]
    assert r["ula_5000000"]["points"]["5000000"]["exactly_X"]["ratio_ci"][1] > 1
    print("self-test passed"); print(json.dumps(r["ula_5150000"]["band_(5000000, threshold]"]))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", nargs="?"); ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--placebos", type=int, nargs="*", default=[4_000_000, 4_500_000, 6_000_000, 7_000_000, 8_000_000])
    a = ap.parse_args()
    if a.selftest:
        selftest()
    else:
        print(json.dumps(analyse(load(a.csv), a.placebos), indent=1))
