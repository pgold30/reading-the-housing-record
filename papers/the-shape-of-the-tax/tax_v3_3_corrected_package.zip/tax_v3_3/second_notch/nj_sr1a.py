"""New Jersey SR-1A sales: two checks for the tax and deed papers.

  notch       New Jersey's 1% "mansion tax" on Class 2 residential transfers, paid by the buyer,
              took effect on 1 August 2004 and applies when consideration EXCEEDS $1,000,000
              (verify the statutory wording, N.J.S.A. 46:15-7.2, before citing). As in Los Angeles,
              a sale at exactly $1,000,000 is untaxed. Predictions written before the data
              were read (16 October 2026): after August 2004, sales at exactly $1,000,000 rise
              relative to 1999-2003 and to never-taxed round prices; sales at $999,999 do not;
              the band ($1,000,000, $1,050,000] falls.
              RESULT (16 October 2026, nj_mansion_tax.py): the first two predictions failed.
              Sales at exactly $1,000,000 fell (moved share 0.91) and reappeared at
              $999,999, $999,000 and $995,000; the band above fell as predicted.
  coded       New Jersey's public extracts carry no party names (Daniel's Law), so the deed test uses
              the official non-usable codes as labels: sheriff's sales and deeds in lieu (codes 12 and
              18 per N.J.A.C. 18:12-1.1, as reported by Gemini; confirm against the codebook). Reports
              their amounts against assessed value and a 2003-2016 repeat-sales index with and without them.
  classifier  (needs names; not possible with Rutgers MOD IV extracts) Cross-tabulates the deed paper's lender-name classifier (grantor/grantee names)
              against the assessor's usability (non-usable sale) codes, so the codes serve as
              independent labels for sheriff's, lender and related-party transfers. The code
              meanings are printed as found in the file; look them up in N.J.A.C. 18:12-1.1
              before interpreting.

The SR-1A layout differs by source (Rutgers MOD IV extract, OPRA flat file), so column names
are arguments. Defaults are guesses; check them against the file header first:
  python3 nj_sr1a.py header FILE
  python3 nj_sr1a.py notch FILE [--date COL --price COL --cls COL]
  python3 nj_sr1a.py classifier FILE [--grantor COL --grantee COL --code COL --price COL --assessed COL]
Files may be .csv, .csv.gz or .txt (comma, pipe or tab separated; detected automatically).
"""
import argparse, csv, gzip, io, json, math, re, sys, datetime as dt
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "deed" / "analysis"))
from philadelphia_check import LENDER  # same lender-name rule as the Philadelphia check

ROUND = [800_000, 900_000, 1_000_000, 1_100_000, 1_200_000, 1_250_000, 1_500_000]


def reader(path):
    op = gzip.open if str(path).endswith(".gz") else open
    with op(path, "rt", newline="", errors="replace") as fh:
        head = fh.read(20000); fh.seek(0)
        delim = max([",", "|", "\t"], key=head.count)
        yield from csv.DictReader(fh, delimiter=delim)


def num(x):
    try:
        return float(str(x).replace(",", "").replace("$", "").strip())
    except ValueError:
        return None


def date(x):
    x = str(x).strip()
    for f in ("%Y-%m-%d", "%m/%d/%Y", "%Y%m%d", "%m/%d/%y"):
        try:
            return dt.datetime.strptime(x[:10] if "-" in x else x, f).date()
        except ValueError:
            pass
    return None


def rate_ratio(n1, y1, n0, y0):
    if not n0 or not n1:
        return None
    r = (n1 / y1) / (n0 / y0); se = math.sqrt(1 / n1 + 1 / n0)
    return [round(r, 3), round(r * math.exp(-1.96 * se), 3), round(r * math.exp(1.96 * se), 3)]


def notch(a):
    pre, post = [], []
    for r in reader(a.file):
        if a.cls and str(r.get(a.cls, "")).strip().upper() not in ("2", "02"):
            continue
        d, p = date(r.get(a.date, "")), num(r.get(a.price, ""))
        if not d or not p or p < 100_000:
            continue
        p = int(round(p))
        if dt.date(1999, 1, 1) <= d <= dt.date(2003, 12, 31):
            pre.append(p)
        elif dt.date(2004, 8, 1) <= d <= dt.date(2009, 7, 31):
            post.append(p)
    yp, yq = 5.0, 5.0
    out = {"sales_pre_1999_2003": len(pre), "sales_post_aug2004_jul2009": len(post), "points": {}}
    for X in ROUND:
        def c(v):
            return {"exactly_X": sum(x == X for x in v), "X_minus_1": sum(x == X - 1 for x in v),
                    "(X, 1.05X]": sum(X < x <= 1.05 * X for x in v), "[0.9X, 1.1X)": sum(0.9 * X <= x < 1.1 * X for x in v)}
        c0, c1 = c(pre), c(post)
        out["points"][str(X)] = {k: {"pre_per_year": round(c0[k] / yp, 1), "post_per_year": round(c1[k] / yq, 1),
                                     "ratio_ci": rate_ratio(c1[k], yq, c0[k], yp)} for k in c0}
    print(json.dumps(out, indent=1))


def classifier(a):
    tab = defaultdict(Counter); amt = defaultdict(list)
    for r in reader(a.file):
        gr, ge = str(r.get(a.grantor, "")).upper(), str(r.get(a.grantee, "")).upper()
        to_l, from_l = bool(LENDER.search(ge)), bool(LENDER.search(gr))
        sheriff = "SHERIFF" in gr
        lab = ("sheriff_to_lender" if sheriff and to_l else "sheriff_third_party" if sheriff else
               "lender_to_lender" if to_l and from_l else "other_to_lender" if to_l else
               "lender_resale" if from_l else "ordinary")
        code = str(r.get(a.code, "")).strip() or "blank"
        tab[lab][code] += 1
        p, v = num(r.get(a.price, "")), num(r.get(a.assessed, "")) if a.assessed else None
        if p and v and p >= 10_000 and v > 0:
            amt[lab].append(100 * (math.log(p) - math.log(v)))
    out = {lab: {"n": sum(c.values()), "top_codes": c.most_common(8)} for lab, c in tab.items()}
    for lab, v in amt.items():
        v.sort(); out[lab]["median_log_price_minus_log_assessed"] = round(v[len(v) // 2], 1)
    print(json.dumps(out, indent=1))


def coded(a):
    """Deed paper test with official labels: amounts and a repeat-sales index, raw vs without coded legal-rule deeds."""
    import numpy as np, scipy.sparse as sp
    legal = set(a.legal_codes.split(","))
    recs, stats = [], defaultdict(lambda: {"n": 0, "ge10k": 0, "gap": []})
    for r in reader(a.file):
        d, p = date(r.get(a.date, "")), num(r.get(a.price, ""))
        if not d or p is None or not (2003 <= d.year <= 2016):
            continue
        code = str(r.get(a.code, "")).strip().lstrip("0") or "usable"
        lab = "legal_rule" if code in legal else ("usable" if code == "usable" else "other_nonusable")
        s = stats[lab]; s["n"] += 1; s["ge10k"] += p >= 10_000
        v = num(r.get(a.assessed, "")) if a.assessed else None
        if p >= 10_000 and v and v > 0:
            s["gap"].append(100 * (math.log(p) - math.log(v)))
        parcel = "|".join(str(r.get(c, "")).strip() for c in a.parcel.split(","))
        if p >= 10_000 and lab != "other_nonusable":
            recs.append((parcel, d, p, lab == "legal_rule"))
    out = {"codes_treated_as_legal_rule": sorted(legal), "events": {}}
    for k, s in stats.items():
        g = sorted(s["gap"])
        out["events"][k] = {"deeds": s["n"], "share_ge_10000": round(s["ge10k"] / max(s["n"], 1), 3),
                            "median_log_price_minus_log_assessed": round(g[len(g) // 2], 1) if g else None}
    by = defaultdict(list)
    for r in recs:
        by[r[0]].append(r)
    P = []
    for rs in by.values():
        rs.sort(key=lambda x: x[1])
        for x, y in zip(rs, rs[1:]):
            if (y[1] - x[1]).days >= 1096:
                P.append(((x[1].year - 2003) * 4 + (x[1].month - 1) // 3, (y[1].year - 2003) * 4 + (y[1].month - 1) // 3,
                          math.log(y[2]) - math.log(x[2]), x[3] or y[3]))
    T = 56; n = len(P)
    qa, qz, yv, lg = (np.array(c) for c in zip(*P))
    X = sp.csr_matrix((np.r_[np.ones(n), -np.ones(n)], (np.r_[np.arange(n), np.arange(n)], np.r_[qz, qa])), shape=(n, T))[:, 1:].tocsc()
    def idx(w):
        XtW = X.T.multiply(w); return 100 * np.r_[0.0, np.linalg.solve((XtW @ X).toarray(), XtW @ yv)]
    raw, drop = idx(np.ones(n)), idx((~lg).astype(float)); diff = raw - drop
    yrs = np.repeat(np.arange(2003, 2017), 4)
    pk = lambda x: float(x[:24].max() - x[20:].min())
    out["index"] = {"pairs": n, "pairs_with_legal_rule_endpoint": int(lg.sum()),
                    "mean_diff_2008_2010": round(float(diff[(yrs >= 2008) & (yrs <= 2010)].mean()), 2),
                    "mean_diff_2011_2012": round(float(diff[(yrs >= 2011) & (yrs <= 2012)].mean()), 2),
                    "decline_raw": round(pk(raw), 1), "decline_drop": round(pk(drop), 1)}
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
    h = sub.add_parser("header"); h.add_argument("file")
    n = sub.add_parser("notch"); n.add_argument("file")
    n.add_argument("--date", default="deed_date"); n.add_argument("--price", default="sale_price"); n.add_argument("--cls", default="property_class")
    c = sub.add_parser("classifier"); c.add_argument("file")
    c.add_argument("--grantor", default="grantor_name"); c.add_argument("--grantee", default="grantee_name")
    c.add_argument("--code", default="nu_code"); c.add_argument("--price", default="sale_price"); c.add_argument("--assessed", default="assessed_value")
    k = sub.add_parser("coded"); k.add_argument("file")
    k.add_argument("--date", default="deed_date"); k.add_argument("--price", default="sale_price"); k.add_argument("--code", default="nu_code")
    k.add_argument("--assessed", default="assessed_value"); k.add_argument("--parcel", default="county,municipality,block,lot,qualifier")
    k.add_argument("--legal-codes", default="12,18", help="non-usable codes for sheriff's sales and deeds in lieu; check the codebook")
    a = ap.parse_args()
    if a.cmd == "header":
        r = next(reader(a.file)); print(json.dumps(r, indent=1))
    else:
        {"notch": notch, "classifier": classifier, "coded": coded}[a.cmd](a)
