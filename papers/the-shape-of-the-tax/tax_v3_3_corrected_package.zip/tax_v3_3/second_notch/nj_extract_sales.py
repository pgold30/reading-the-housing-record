"""Extract one row per recorded sale from statewide New Jersey MOD IV rolls.

Each roll lists every parcel with its most recent deed. Reading successive roll years and
keeping each distinct (parcel, deed date, price) recovers parcels that sold more than once.
Only the columns the tax and deed analyses use are kept, so the output is small enough to
commit; the raw rolls stay on the machine that downloaded them.

Usage: python3 nj_extract_sales.py ROLLS_DIR OUT.csv.gz
  ROLLS_DIR holds files named nj_modiv_<year>_<county>.csv.gz
Output columns: gis_pin, county, municipality, property_class, deed_date, sale_price,
  sale_assessment, nu_code, first_roll_year
Prints row counts per roll year and the SHA-256 of the output.
"""
import csv, gzip, hashlib, sys
from collections import Counter
from pathlib import Path

KEEP = {"gis_pin": "gis_pin", "mod_iv_county_name": "county", "mod_iv_munis_name": "municipality",
        "property_class": "property_class", "deed_date_MMDDYY": "deed_date", "sale_price": "sale_price",
        "sale_assessment": "sale_assessment", "sale_sr1a_non_usable_code": "nu_code"}


def main(src, out):
    seen, per_year, rows = set(), Counter(), []
    files = sorted(Path(src).glob("nj_modiv_*_*.csv.gz"))
    assert files, "no roll files found"
    for f in files:
        year = int(f.name.split("_")[2])
        with gzip.open(f, "rt", newline="", errors="replace") as fh:
            for r in csv.DictReader(fh):
                d, p = (r.get("deed_date_MMDDYY") or "").strip(), (r.get("sale_price") or "").strip()
                if len(d) < 10 or not d[:4].isdigit() or not (1990 <= int(d[:4]) <= 2012):
                    continue
                try:
                    if float(p) <= 0:
                        continue
                except ValueError:
                    continue
                key = (r.get("gis_pin", ""), d, p)
                if key in seen:
                    continue
                seen.add(key); per_year[year] += 1
                row = {v: (r.get(k) or "").strip() for k, v in KEEP.items()}
                row["first_roll_year"] = year
                rows.append(row)
    rows.sort(key=lambda x: (x["county"], x["gis_pin"], x["deed_date"]))
    cols = list(KEEP.values()) + ["first_roll_year"]
    import io
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=cols); w.writeheader(); w.writerows(rows)
    with open(out, "wb") as raw, gzip.GzipFile(fileobj=raw, mode="wb", mtime=0, filename="") as gz:
        gz.write(buf.getvalue().encode("utf-8"))
    print("new sales by roll year:", dict(sorted(per_year.items())))
    print("distinct sales:", len(rows))
    print("sha256:", hashlib.sha256(Path(out).read_bytes()).hexdigest())


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
