"""Repeat the tax paper's round-price measures at a second transfer-tax notch.

Input: a CSV with at least `sale_date` (YYYY-MM-DD) and `price` (whole dollars), one
row per deed. Arguments name the threshold, the date the notch took effect, a
transition window to drop, and never-taxed round prices to use as placebos.

Measures (as in Tables 1, 2 and 4 of the paper):
  spike   sales at exactly X relative to local density (non-multiples of $10,000
          between $5,000 and $25,000 from X on either side, per $10,000)
  below   sales at X-1 per year
  moved   1 - (post share of window sales at exactly X) / (pre share), window [0.9X, 1.1X)
  zones   change in each price zone's share of window sales, scaled to sales per year
  placebo the same `moved` statistic at each never-taxed round price
Bootstrap: 1,000 draws resampling sales within the window in each period.

Example (Los Angeles ULA, $5 million notch from 1 April 2023):
  python3 second_notch.py sales.csv --threshold 5000000 --start 2023-04-01 \
      --drop-before 2022-10-01 --placebos 4000000 4500000 6000000 7000000
"""
import argparse, csv, json, datetime as dt
import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument("csv"); ap.add_argument("--threshold", type=int, required=True)
ap.add_argument("--start", required=True, help="date the notch took effect")
ap.add_argument("--drop-before", help="drop sales from this date to --start (contracts signed before the change)")
ap.add_argument("--placebos", type=int, nargs="*", default=[])
ap.add_argument("--min-price", type=int, default=0)
ap.add_argument("--seed", type=int, default=20261016)
a = ap.parse_args()

start = dt.date.fromisoformat(a.start); drop = dt.date.fromisoformat(a.drop_before) if a.drop_before else start
rows = []
for r in csv.DictReader(open(a.csv)):
    try:
        d = dt.date.fromisoformat(r["sale_date"][:10]); p = int(round(float(r["price"])))
    except (ValueError, KeyError):
        continue
    if p < a.min_price: continue
    if drop <= d < start: continue
    rows.append((d, p, d >= start))
pre = np.array([p for d, p, post in rows if not post]); post = np.array([p for d, p, post in rows if post])
years = lambda ds: max((max(ds) - min(ds)).days / 365.25, 1e-9)
y_pre = years([d for d, p, s in rows if not s]); y_post = years([d for d, p, s in rows if s])

def window(x, X): return x[(x >= 0.9 * X) & (x < 1.1 * X)]
def spike(x, X):
    near = x[((np.abs(x - X) >= 5000) & (np.abs(x - X) <= 25000)) & (x % 10000 != 0)]
    dens = len(near) / 4.0  # four $10,000 bins
    return float((x == X).sum() / dens) if dens else None
def share_at(x, X):
    w = window(x, X); return (w == X).sum() / len(w) if len(w) else np.nan
def moved(a_, b_, X):
    s0, s1 = share_at(a_, X), share_at(b_, X); return float(1 - s1 / s0) if s0 else None
def zones(a_, b_, X):
    wa, wb = window(a_, X), window(b_, X); out = {}
    Z = {"[0.95X, X-5000)": lambda w: (w >= 0.95 * X) & (w < X - 5000), "[X-5000, X)": lambda w: (w >= X - 5000) & (w < X),
         "exactly X": lambda w: w == X, "(X, 1.05X)": lambda w: (w > X) & (w < 1.05 * X)}
    for k, f in Z.items():
        out[k] = round(float((f(wb).mean() - f(wa).mean()) * len(wb) / y_post), 1)
    return out
def boot(stat, X, B=1000):
    rng = np.random.default_rng(a.seed); wa, wb = window(pre, X), window(post, X); v = []
    for _ in range(B):
        v.append(stat(rng.choice(wa, len(wa)), rng.choice(wb, len(wb)), X))
    v = np.array([x for x in v if x is not None]); return [round(float(np.percentile(v, 2.5)), 3), round(float(np.percentile(v, 97.5)), 3)]

X = a.threshold
res = {"threshold": X, "pre_sales": int(len(pre)), "post_sales": int(len(post)),
       "pre_years": round(y_pre, 2), "post_years": round(y_post, 2),
       "window_sales_pre_post": [int(len(window(pre, X))), int(len(window(post, X)))],
       "spike_pre_post": [spike(pre, X), spike(post, X)],
       "sales_at_X_minus_1_per_year_pre_post": [round(float((pre == X - 1).sum() / y_pre), 1), round(float((post == X - 1).sum() / y_post), 1)],
       "moved_share": moved(pre, post, X), "moved_share_95": boot(moved, X),
       "zone_change_sales_per_year": zones(pre, post, X),
       "placebos": {str(P): {"spike_pre_post": [spike(pre, P), spike(post, P)], "moved_share": moved(pre, post, P)} for P in a.placebos}}
print(json.dumps(res, indent=1))
