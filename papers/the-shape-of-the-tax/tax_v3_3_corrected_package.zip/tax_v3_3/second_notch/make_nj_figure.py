"""Figure: share of sales near $1 million recorded at exactly $1,000,000, New Jersey, by year.

Input: data_external/new_jersey/nj_sales_2000_2010_statewide.csv.gz (see nj_extract_sales.py).
Class 2 sales of at least $100,000. For each deed year, the share of sales in [$900,000, $1,100,000)
recorded at exactly $1,000,000, with a Wilson 95% interval, and the same share at six never-taxed
round prices ($800k, $900k, $1.1M, $1.2M, $1.25M, $1.5M), each in its own +/-10% window, pooled.
The fee applies from 1 August 2004, so 2004 is drawn hollow. Deeds dated after about October 2009 are
not yet in the 2010 roll, so 2009 is partial.

Usage: python3 make_nj_figure.py SALES.csv.gz figures/Figure_9.pdf > second_notch/nj_figure_data.json
"""
import sys, json, math
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

X = 1_000_000; PLAC = [800_000, 900_000, 1_100_000, 1_200_000, 1_250_000, 1_500_000]; YEARS = range(1998, 2010)


def wilson(k, n):
    if n == 0:
        return (np.nan, np.nan, np.nan)
    p = k / n; z = 1.96; d = 1 + z * z / n; c = (p + z * z / (2 * n)) / d; h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (100 * p, 100 * (c - h), 100 * (c + h))


d = pd.read_csv(sys.argv[1], dtype={"property_class": str}, usecols=["property_class", "deed_date", "sale_price"], low_memory=False)
d = d[(d.property_class.str.strip() == "2") & (d.sale_price >= 100_000)]
d["yr"] = pd.to_datetime(d.deed_date, errors="coerce").dt.year
rows = []
for y in YEARS:
    v = d.loc[d.yr == y, "sale_price"].to_numpy()
    w = v[(v >= 0.9 * X) & (v < 1.1 * X)]
    k_p = n_p = 0
    for P in PLAC:
        wp = v[(v >= 0.9 * P) & (v < 1.1 * P)]; k_p += int((wp == P).sum()); n_p += len(wp)
    rows.append({"year": y, "n_window": int(len(w)), "at_1m": int((w == X).sum()), "share": wilson(int((w == X).sum()), len(w)),
                 "placebo_n": n_p, "placebo_at": k_p, "placebo_share": wilson(k_p, n_p)})
print(json.dumps(rows, indent=1))

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10})
fig, ax = plt.subplots(figsize=(7.8, 3.6))
blue, grey = "#1b6fa8", "#8a8f94"
ax.axvspan(2004.5, 2009.5, color="#e9eff5", zorder=0)
ax.axvline(2004 + 7 / 12, color="#9fb3c8", lw=0.8, ls="--", zorder=1)
ys = np.array([r["year"] for r in rows])
for key, col, off, lab in [("placebo_share", grey, 0.12, "Six never-taxed round prices, pooled"), ("share", blue, -0.12, "Exactly $1,000,000")]:
    s = np.array([r[key] for r in rows])
    ax.vlines(ys + off, s[:, 1], s[:, 2], color=col, lw=1.6, zorder=2)
    hollow = ys == 2004
    ax.scatter(ys[~hollow] + off, s[~hollow, 0], color=col, s=34, zorder=3, label=lab)
    ax.scatter(ys[hollow] + off, s[hollow, 0], facecolor="white", edgecolor=col, linewidth=1.5, s=34, zorder=3)
ax.set_ylabel("Share of sales within 10% of the price (%)")
ax.set_xticks(list(YEARS)); ax.set_xticklabels(["1998"] + [f"{y % 100:02d}" for y in list(YEARS)[1:]])
ax.set_ylim(bottom=0); ax.set_xlim(1997.4, 2009.6)
ax.text(2004 + 7 / 12 + 0.1, 9.0, "Fee from\n1 August 2004", fontsize=8.5, color="#4a5a6a", va="center")
for s in ("top", "right"):
    ax.spines[s].set_visible(False)
ax.grid(axis="y", color="#e2e2e2", lw=0.7); ax.set_axisbelow(True)
ax.legend(frameon=False, loc="lower left", bbox_to_anchor=(0, 1.0), ncol=2, fontsize=8.5, handletextpad=0.3, columnspacing=1.5)
fig.tight_layout(); fig.savefig(sys.argv[2])
