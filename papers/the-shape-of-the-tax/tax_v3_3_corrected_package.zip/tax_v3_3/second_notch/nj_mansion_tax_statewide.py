"""New Jersey's 2004 mansion tax, statewide: the round-price test on all 21 counties.

Data: data_external/new_jersey/nj_sales_2000_2010_statewide.csv.gz, one row per recorded sale
extracted from the MOD IV rolls of 2000-2010 by nj_extract_sales.py (SHA-256 in
statewide_SOURCE.md). The 1 percent fee on Class 2 residential transfers took effect on 1 August
2004 and applies when consideration exceeds $1,000,000, so a sale at exactly $1,000,000 is untaxed.

Before: deeds dated 1999-2003. After: August 2004 to July 2009. Class 2, price of at least
$100,000, window [0.9X, 1.1X). The moved share is 1 - (share at X after)/(share at X before).
Bootstrap: 2,000 draws resampling sales within each period's window (seed 20261016).
Also reported: the same with assessor-usable sales only (blank non-usable code), by county
group, and a pre-period placebo (1994-1998 against 1999-2003).

Usage: python3 nj_mansion_tax_statewide.py SALES.csv.gz > nj_mansion_tax_statewide.json
"""
import sys, json
import numpy as np, pandas as pd

X = 1_000_000
win = lambda v, P: v[(v >= 0.9 * P) & (v < 1.1 * P)]


def test(pre, post, seed=20261016, B=2000):
    w0, w1 = win(pre, X), win(post, X)
    s0, s1 = (w0 == X).mean(), (w1 == X).mean()
    rng = np.random.default_rng(seed)
    bs = [1 - (rng.choice(w1, len(w1)) == X).mean() / max((rng.choice(w0, len(w0)) == X).mean(), 1e-12) for _ in range(B)]
    plac = {}
    for P in [800_000, 900_000, 1_100_000, 1_200_000, 1_250_000, 1_500_000]:
        a, b = win(pre, P), win(post, P)
        plac[P] = round(float((b == P).mean() / (a == P).mean()), 3) if (a == P).any() else None
    pv = [v for v in plac.values() if v]
    sc = len(w1) / len(w0); landed = {}
    for lo, hi in [(1, 1), (2, 999), (1000, 1000), (1001, 4999), (5000, 5000), (5001, 10000), (10001, 25000)]:
        n0 = int(((pre >= X - hi) & (pre <= X - lo)).sum()); n1 = int(((post >= X - hi) & (post <= X - lo)).sum())
        landed[f"{lo}-{hi} below"] = {"pre": n0, "post": n1, "excess": round(n1 - n0 * sc, 1)}
    above = lambda w: float(((w > X) & (w <= 1.05 * X)).mean())
    return {"sales_pre": int(len(pre)), "sales_post": int(len(post)), "window_pre": int(len(w0)), "window_post": int(len(w1)),
            "sales_at_X": [int((w0 == X).sum()), int((w1 == X).sum())], "share_at_X": [round(float(s0), 4), round(float(s1), 4)],
            "moved_share": round(float(1 - s1 / s0), 3), "moved_share_95": [round(float(x), 3) for x in np.percentile(bs, [2.5, 97.5])],
            "placebo_ratio_at_round_price": plac, "placebo_mean": round(float(np.mean(pv)), 3),
            "moved_share_placebo_adjusted": round(float(1 - (s1 / s0) / np.mean(pv)), 3),
            "share_in_(X,1.05X]": [round(above(w0), 4), round(above(w1), 4)], "where_extra_sales_landed": landed}


def main(path):
    d = pd.read_csv(path, dtype={"nu_code": str, "property_class": str}, low_memory=False)
    d["dt"] = pd.to_datetime(d.deed_date, errors="coerce")
    d = d[(d.property_class.str.strip() == "2") & (d.sale_price >= 100_000)].copy()
    d["usable"] = d.nu_code.fillna("").str.strip().eq("")
    per = lambda a, b, m=None: d[(d.dt >= a) & (d.dt <= b) & (m if m is not None else True)].sale_price.to_numpy()
    out = {"all_class_2": test(per("1999-01-01", "2003-12-31"), per("2004-08-01", "2009-07-31")),
           "usable_only": test(per("1999-01-01", "2003-12-31", d.usable), per("2004-08-01", "2009-07-31", d.usable))}
    north = d.county.str.upper().isin(["BERGEN", "ESSEX", "HUDSON", "MORRIS", "PASSAIC", "SOMERSET", "UNION", "SUSSEX", "WARREN", "HUNTERDON"])
    out["north_counties"] = test(per("1999-01-01", "2003-12-31", north), per("2004-08-01", "2009-07-31", north))
    out["other_counties"] = test(per("1999-01-01", "2003-12-31", ~north), per("2004-08-01", "2009-07-31", ~north))
    out["placebo_period_1994_98_vs_1999_2003"] = test(per("1994-01-01", "1998-12-31"), per("1999-01-01", "2003-12-31"))
    yr = d[(d.sale_price >= 0.9 * X) & (d.sale_price < 1.1 * X)].groupby(d.dt.dt.year)
    out["share_at_X_by_year"] = {int(y): [int(len(g)), round(float((g.sale_price == X).mean()), 4)] for y, g in yr if 1996 <= y <= 2010}
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    main(sys.argv[1])
