# Tax correction prepared 22 October 2026

The condo unit-lot ceiling is corrected to 6999. The loan sample, recording-charge costing, loan-notch checks and seller/coverage checks are refreshed. The main price sample and reform estimates are unchanged. Earlier files and releases are preserved. This draft has not been uploaded or sent to an editor.

Cold read, 22 October: clarified response similarity, approximate deed grouping and small changes under foreclosure exclusions; narrowed the supplemental loan-to-value interpretation. Numerical results unchanged from the corrected candidate; 118/118 text/output checks pass.
